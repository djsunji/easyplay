# Planung von Fragenblöcken für easyplay

easyplay ist eine Schweizer Lernseite (6 bis 20 Jahre) mit drei Stufen:
- Stufe 1 «Entdecker» (6 bis 9 Jahre): Grundwissen, sehr einfach.
- Stufe 2 «Könner» (10 bis 14 Jahre): Mittelstufe und Sekundarstufe I.
- Stufe 3 «Profi» (15 bis 20 Jahre): Gymnasium, Berufsschule.

Es sollen sehr viele neue Fragen entstehen, in Blöcken zu je 100 Fragen. Jeder Block wird später von einem Helfer geschrieben, der NUR die Angaben aus deiner Zeile bekommt. Deshalb muss jeder Block klar abgegrenzt sein, damit verschiedene Blöcke nicht dieselben Fakten abfragen.

Deine Aufgabe: Schreibe eine Tabelle (TSV, Tabulator getrennt, ohne Kopfzeile) mit genau den verlangten Blöcken. Spalten:
1. slug: eindeutiges Kürzel, nur a-z, 0-9 und _, mit Präfix wie angegeben (z. B. ge1_001)
2. THEMA-ID: eine der erlaubten Themen-IDs
3. STUFE: 1, 2 oder 3
4. Fach-Name (für den Helfer verständlich, z. B. «Geschichte: Antike»)
5. Unterthemen: 8 bis 14 konkrete, eng gefasste Unterthemen, mit Komma getrennt (z. B. «Pyramiden von Gizeh, Hieroglyphen, Pharao Tutanchamun, Mumifizierung, Nil und Überschwemmungen, ...»).

Regeln:
- Kein Unterthema darf in zwei Blöcken derselben Stufe vorkommen. Zwischen den Stufen dürfen sich Themen wiederholen, aber dann mit anderem Fokus und passendem Niveau (Entdecker einfach, Profi vertieft).
- Decke das Fach breit und vollständig ab: alle Kontinente, Epochen, Länder, Strömungen, Institutionen usw., inklusive Schweiz-Bezug wo passend. Lieber viele konkrete Unterthemen (Personen, Ereignisse, Orte, Begriffe) als allgemeine.
- Für Stufe 1 nur kindgerechte Unterthemen (keine grausamen Details, keine Gewalt im Detail; Diktatur, Krieg usw. nur sehr behutsam und allgemein).
- Politisch und religiös neutral, sachlich.
- Die Datei bestand_*.json zeigt, welche Unterthemen es schon gibt und wie viele Fragen. Plane Blöcke so, dass sie vor allem Neues abdecken; bereits stark abgedeckte Unterthemen nur mit neuem Fokus.
- Die Anzahl Blöcke pro THEMA-ID und Stufe steht im Auftrag. Halte sie genau ein.

Prüfe am Ende mit python3, dass die Datei genau die verlangte Zahl Zeilen hat, jede Zeile 5 Spalten, slugs eindeutig, und keine Unterthemen innerhalb derselben Stufe doppelt vorkommen.
