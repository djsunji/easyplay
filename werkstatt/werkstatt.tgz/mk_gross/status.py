import os,subprocess,csv
rows=[r for r in csv.reader(open('/home/claude/mk/gross/bloecke.tsv'),delimiter='\t')]
ok=rev=0; todo_w=[]; todo_r=[]
for s,t,l,_,_ in rows:
    p=f'/home/claude/mk/gross/out/{s}.json'
    if os.path.exists(p):
        r=subprocess.run(['python3','/home/claude/mk/gesch/check_g.py',p,t,l],capture_output=True,text=True).stdout.strip().split('\n')[-1]
        if r=='OK':
            ok+=1
            if os.path.exists(p[:-5]+'.rev'): rev+=1
            else: todo_r.append(s)
        else: todo_w.append(s)
    else: todo_w.append(s)
print(f'geschrieben {ok}/{len(rows)}, geprueft {rev}')
print('SCHREIBEN:',' '.join(todo_w[:40]))
print('PRUEFEN:',' '.join(todo_r[:40]))
