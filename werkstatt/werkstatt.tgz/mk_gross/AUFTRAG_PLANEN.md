# Auftrag: Fragenblöcke planen (easyplay, Schweizer Lernseite 6 bis 20 Jahre)

Du planst Blöcke zu je 100 Quizfragen. Jeder Block ist eine Zeile in einer TSV-Datei (Tabulator-getrennt, 5 Spalten):
slug <TAB> THEMA-ID <TAB> STUFE <TAB> Fach: Blocktitel <TAB> genau 12 Unterthemen, durch Komma getrennt

Stufen: 1 = Entdecker (6 bis 9 Jahre, sehr einfach, Alltag und Staunen), 2 = Könner (10 bis 14, Mittelstufe und Sek I), 3 = Profis (15 bis 20, Gymnasium und Berufsschule).

Regeln:
- Unterthemen sind konkrete, abfragbare Begriffe (möglichst Titel deutscher Wikipedia-Artikel), z. B. «Photosynthese», «Bergahorn», «Ohmsches Gesetz», nicht vage («Allgemeines»).
- Keine Wiederholung: Kein Unterthema darf in zwei Blöcken derselben Stufe vorkommen. Zwischen Stufen nur, wenn die Tiefe klar anders ist.
- Prüfe die bisherigen Unterthemen dieses Themas, um Dopplungen zu vermeiden: python3 -c "import json,glob,collections;c=collections.Counter((q['s'],q['l']) for f in glob.glob('/mnt/user-data/outputs/easyplay/fragen-*.json') for q in json.load(open(f)) if q['t']=='THEMA');print(sorted(c))" (THEMA ersetzen). Plane neue Schwerpunkte, keine Kopien.
- Schweiz-Bezug, wo passend (Schweizer Pflanzen, Forschung an ETH, EPFL, CERN, PSI, Empa, Schweizer Erfinder, Schweizer Alpen usw.).
- Tabu: nichts zu Sexualität, Fortpflanzung des Menschen, Verhütung, Geschlechtsorganen, Pubertät der Geschlechtsorgane, sexuellem Missbrauch, Drogen, Suizid. Bei Pflanzen und Tieren ist Bestäubung, Samen, Keimung erlaubt.
- Schweizer Rechtschreibung (immer «ss», nie «ß»), keine Gedankenstriche (– —).
- Slug-Format: <präfix><stufe>_<dreistellige Nummer>, z. B. na1_001. Präfixe und Anzahl Blöcke stehen in deinem Auftrag.

Schreibe nur in die Datei, die dein Auftrag nennt. Prüfe am Ende mit python3: jede Zeile hat 5 Spalten, genau 12 Unterthemen, Slugs eindeutig, keine doppelten Unterthemen innerhalb einer Stufe, kein «ß», keine Gedankenstriche. Antworte kurz mit der Anzahl Zeilen pro Stufe.
