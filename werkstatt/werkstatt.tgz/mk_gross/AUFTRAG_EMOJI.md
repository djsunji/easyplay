# Auftrag: einen Block Emoji-Bilderrätsel schreiben

1. Suche in /home/claude/mk/gross/bloecke.tsv die Zeile mit deinem slug (Spalten: slug, THEMA-ID, STUFE, Fach, Unterthemen).
2. Lies /home/claude/mk/allg/SCHEMA_ALLG.md und befolge es, mit diesen Zusätzen für Bilderrätsel:
   - Jedes Objekt bekommt ZUSÄTZLICH das Feld "img" mit dem Wert "e:" gefolgt von 2 bis 6 Emojis, z. B. "img":"e:☀️🌻". Das Bild wird gross über der Frage angezeigt.
   - Die Frage bezieht sich auf das Bild und verrät die Lösung NICHT (z. B. «Welches Wort ergeben diese Bilder zusammen?», «Welches Märchen zeigen diese Emojis?», «Welcher Beruf passt zu diesen Bildern?», «Welche Redewendung ist gemeint?»). Die Frage muss mit «?» enden.
   - Das Rätsel muss mit den Emojis eindeutig lösbar sein; Falschantworten sind plausibel, passen aber klar schlechter zu den Emojis.
   - Nur verbreitete Emojis (Unicode-Version 13 oder älter), keine Flaggen-Emojis, keine Hautfarben-Varianten, keine Emojis von Waffen, Alkohol, Zigaretten, Drogen oder mit sexueller Bedeutung.
   - Ein Emoji-Bild darf im Block nur einmal vorkommen, und kein Bild darf eine Lösung einer anderen Frage zeigen.
   - "e" erklärt, wie die Emojis zur Lösung führen (z. B. «Sonne und Blume ergeben zusammen Sonnenblume.»). "m" ist ein ganzer Satz.
   - "s" ist das Unterthema (wie in der Zeile angegeben).
3. Schreibe /home/claude/mk/gross/out/<slug>.json mit genau 100 Fragen, ein Objekt pro Zeile.
4. Prüfe mit: python3 /home/claude/mk/gesch/check_g.py /home/claude/mk/gross/out/<slug>.json bilder <STUFE>  (bis OK). Prüfe zusätzlich mit python3, dass jedes Objekt ein "img" mit "e:" hat und keine zwei "img" gleich sind.
5. Prüfe Doppelungen: python3 /home/claude/mk/gross/dup.py /home/claude/mk/gross/out/<slug>.json und ersetze echte Doppelungen (gleiche Lösung wie eine bestehende Bilderfrage im selben Unterthema).
6. Tabu: keine Inhalte zu Sexualität, Fortpflanzung, Verhütung, sexuellem Missbrauch, Gewalt oder Drogen. Filme, Bücher und Serien nur altersgerecht für die Stufe.
7. Hilfsskripte nur unter eindeutigem Namen (z. B. /tmp/<slug>_hilf.py). Schreibe nie in fremde Dateien.
Antworte nur kurz mit Anzahl und Ergebnis.
