# Auftrag: Fragenblöcke prüfen

Für JEDEN dir genannten slug:
1. Datei: /home/claude/mk/gross/out/<slug>.json (THEMA-ID und STUFE stehen in jedem Objekt als "t" und "l").
2. Lies /home/claude/mk/allg/PRUEFEN_A.md und befolge es genau für diese Datei (Fakten mit WebSearch/WebFetch prüfen, korrigieren, check_g.py muss OK melden).
3. Danach: python3 /home/claude/mk/gross/dup.py /home/claude/mk/gross/out/<slug>.json und echte Doppelungen ersetzen.
4. Wenn fertig: lege die leere Datei /home/claude/mk/gross/out/<slug>.rev an (Zeichen, dass der Block geprüft ist).
Tabu: Fragen zu Sexualität, Sexualkunde, menschlicher Fortpflanzung, Verhütung oder Geschlechtsorganen sowie zu sexuellem Missbrauch (auch Missbrauchsstudien) durch andere Fragen zum Block ersetzen.
Hilfsskripte nur unter eindeutigem Namen (z. B. /tmp/<slug>_rev.py). Antworte nur kurz pro slug: Anzahl geänderter Fragen und Checker-Ergebnis.
Bei Bilderrätseln (Feld "img" mit "e:"): prüfe zusätzlich, dass jedes Emoji-Rätsel eindeutig lösbar ist, die Frage die Lösung nicht verrät, nur verbreitete Emojis (Unicode 13 oder älter, keine Flaggen) vorkommen und jedes "img" im Block nur einmal vorkommt. Unklare Rätsel ersetzen; "img" bei Ersatzfragen nicht vergessen.
