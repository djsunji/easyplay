import json,sys,re,glob,os
f=sys.argv[1]; d=json.load(open(f,encoding='utf-8'))
def w(t): return set(x[:6] for x in re.sub(r'[^a-zäöüéèàç0-9 ]',' ',t.lower()).split() if len(x)>2)
best=json.load(open('/home/claude/mk/gross/bestand.json'))
themen={x['t'] for x in d}
ref=[(b['q'],w(b['q']+' '+b['a'])) for b in best if b['t'] in themen]
for g in glob.glob('/home/claude/mk/gross/out/*.json'):
    if os.path.abspath(g)==os.path.abspath(f): continue
    try:
        for b in json.load(open(g,encoding='utf-8')):
            if b.get('t') in themen: ref.append((b['q'],w(b['q']+' '+b['a'][0])))
    except Exception: pass
n=0
for i,x in enumerate(d):
    a=w(x['q']+' '+x['a'][0])
    for q,b in ref:
        if len(a)>=3 and len(b)>=3 and len(a&b)/min(len(a),len(b))>=0.75:
            print(f'#{i} aehnlich wie bestehende Frage: {x["q"]}  <->  {q}'); n+=1; break
print('DUP-OK' if n==0 else f'{n} moegliche Doppelungen (ersetzen, wenn wirklich derselbe Fakt)')
