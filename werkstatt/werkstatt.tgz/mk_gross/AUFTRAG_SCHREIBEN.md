# Auftrag: einen Fragenblock schreiben

1. Suche in /home/claude/mk/gross/bloecke.tsv die Zeile mit deinem slug (Spalten: slug, THEMA-ID, STUFE, Fach, Unterthemen).
2. Lies /home/claude/mk/allg/SCHEMA_ALLG.md und befolge es genau mit diesen Angaben.
3. Schreibe /home/claude/mk/gross/out/<slug>.json mit genau 100 Fragen.
4. Prüfe mit: python3 /home/claude/mk/gesch/check_g.py /home/claude/mk/gross/out/<slug>.json <THEMA-ID> <STUFE>  (bis OK)
5. Prüfe Doppelungen mit bereits vorhandenen Fragen: python3 /home/claude/mk/gross/dup.py /home/claude/mk/gross/out/<slug>.json
   Gemeldete Fragen, die wirklich denselben Fakt abfragen, durch neue Fragen zu deinen Unterthemen ersetzen. Danach Schritt 4 und 5 wiederholen.
6. Hilfsskripte nur unter eindeutigem Namen, z. B. /tmp/<slug>_hilf.py. Schreibe nie in fremde Dateien.
7. Tabu für alle Blöcke: keine Fragen, Antworten oder Erklärungen zu Sexualität, Sexualkunde, Fortpflanzung und Geschlechtsorganen des Menschen, Verhütung, Pubertätsveränderungen der Geschlechtsorgane oder sexuellen Beziehungen, auch keine Fragen zu sexuellem Missbrauch (z. B. Missbrauchsstudien). Kommt so etwas in einem Unterthema vor, lass es weg und nimm ein anderes Thema.
Antworte nur kurz mit Anzahl und Ergebnis.
