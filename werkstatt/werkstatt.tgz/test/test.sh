#!/bin/bash
curl -s -m 3 -o /dev/null localhost:8765/config.js || { cd /mnt/user-data/outputs/easyplay && setsid nohup python3 -m http.server 8765 </dev/null >/dev/null 2>&1 & sleep 2; }
cd /tmp/claude-0 && NODE_PATH=$(npm root -g) timeout 150 node t_neu.js </dev/null >/tmp/claude-0/tneu.out 2>&1; tail -2 /tmp/claude-0/tneu.out
