const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const url of ['http://localhost:8765/index.html','file:///mnt/user-data/outputs/lernspiel.html']){const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));await p.route(/wikipedia|wikimedia/,r=>r.abort());
 await p.goto(url);await p.waitForTimeout(8000);
 const r=await p.evaluate(()=>({n:FRAGEN.length,g:[1,2,3].map(l=>countThema('geschichte',l)).join('/'),nr:frageNr(FRAGEN.find(f=>f.nr===25000)||{q:'x'})}));
 console.log(url,JSON.stringify(r),errs);await p.close();}
await b.close();})();
