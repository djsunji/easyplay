import sys
def rep(s,a,b):
    assert s.count(a)==1, (s.count(a), a[:90]); return s.replace(a,b)
for fn in sys.argv[1:]:
    s=open(fn,encoding="utf-8").read()
    if "pwHashNeu" in s: print(fn,"schon"); continue
    s=rep(s,'if(!m) return null; const v=decodeURIComponent(m[1]);','if(!m) return null; let v; try{ v=decodeURIComponent(m[1]).slice(0,300); }catch(e){ return null; }')
    s=rep(s,'const r={n:String(d.n||"Anonym").slice(0,30), s:+d.s||0, t:+d.t||t.ids.length, z:+d.z||0, a:String(d.a||""), d:d.d||new Date().toISOString()};\n    if(!t.resultate.some(x=>x.n===r.n && x.d===r.d)) t.resultate.push(r);',
      'const zahl=(v,max)=>Math.max(0,Math.min(+v||0,max));\n    const r={n:String(d.n||"Anonym").slice(0,30), s:zahl(d.s,t.ids.length), t:t.ids.length, z:zahl(d.z,864e5), a:String(d.a||"").slice(0,t.ids.length).replace(/[^0-9-]/g,""), d:String(d.d||new Date().toISOString()).slice(0,30)};\n    if(t.resultate.length<500 && !t.resultate.some(x=>x.n===r.n && x.d===r.d)) t.resultate.push(r);')
    s=rep(s,'const list=(d.q||[]).map(id=>map[id]).filter(Boolean);\n    if(!list.length) return false;',
      'const list=(Array.isArray(d.q)?d.q.slice(0,50):[]).map(id=>map[id]).filter(Boolean);\n    if(!list.length) return false;')
    s=rep(s,'DU.herausf={k:d.k, n:String(d.n||"Jemand").slice(0,30), s:+d.s||0, a:String(d.a||"").split("").map(Number)};',
      'DU.herausf={k:String(d.k||"").slice(0,40), n:String(d.n||"Jemand").slice(0,30), s:Math.max(0,Math.min(+d.s||0,1e5)), a:String(d.a||"").slice(0,50).split("").map(Number)};')
    s=rep(s,'if(t){ t.gegner=t.gegner||[]; if(!t.gegner.some(x=>x.n===d.n&&x.s===d.s)) t.gegner.push({n:String(d.n).slice(0,30), s:+d.s||0}); store.set("ep-duelle",l); }\n    DU.mode="link"; DU.ergebnis={a:{n:String(d.n||"Gegner"), s:+d.s||0}',
      'const gs=Math.max(0,Math.min(+d.s||0,1e5)), gn=String(d.n||"Gegner").slice(0,30);\n    if(t){ t.gegner=t.gegner||[]; if(t.gegner.length<200 && !t.gegner.some(x=>x.n===gn&&x.s===gs)) t.gegner.push({n:gn, s:gs}); store.set("ep-duelle",l); }\n    DU.mode="link"; DU.ergebnis={a:{n:gn, s:gs}')
    # Passwörter: PBKDF2 statt einfachem SHA-256
    s=rep(s,'async function pwHash(pw, salt){',
      '''// Lokale Konten: PBKDF2 mit 600 000 Runden. Alte SHA-256-Hashes werden beim Anmelden ersetzt.
async function pwHashNeu(pw, salt){
  const key=await crypto.subtle.importKey("raw", new TextEncoder().encode(pw), "PBKDF2", false, ["deriveBits"]);
  const bits=await crypto.subtle.deriveBits({name:"PBKDF2", hash:"SHA-256", salt:new TextEncoder().encode(salt), iterations:600000}, key, 256);
  return "p2:"+[...new Uint8Array(bits)].map(b=>b.toString(16).padStart(2,"0")).join("");
}
async function pwPruefen(pw, k){
  if(!k || !k.hash) return false;
  if(String(k.hash).startsWith("p2:")) return (await pwHashNeu(pw,k.salt))===k.hash;
  return (await pwHash(pw,k.salt))===k.hash;
}
async function pwHash(pw, salt){''')
    s=rep(s,'konten[mail]={salt, hash:await pwHash(pw,salt), profil:S.profil};','konten[mail]={salt, hash:await pwHashNeu(pw,salt), profil:S.profil};')
    s=rep(s,'if(!k || await pwHash(pw,k.salt)!==k.hash) throw new Error("E-Mail oder Passwort stimmt nicht.");',
      'if(!(await pwPruefen(pw,k))) throw new Error("E-Mail oder Passwort stimmt nicht.");\n        if(!String(k.hash).startsWith("p2:")){ try{ const alle=lokaleKonten(); k.salt=crypto.getRandomValues(new Uint32Array(4)).join("-"); k.hash=await pwHashNeu(pw,k.salt); alle[mail]=k; store.set("ep-konten",alle); }catch(e){} }')
    open(fn,"w",encoding="utf-8").write(s); print(fn,"ok")
