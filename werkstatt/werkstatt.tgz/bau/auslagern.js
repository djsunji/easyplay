// Lagert grosse Daten-Konstanten aus index.html in eigene .js-Dateien aus
const fs=require('fs');const ts=require(require('child_process').execSync('npm root -g').toString().trim()+'/typescript');
const [,,src,outdir]=process.argv;
let html=fs.readFileSync(src,'utf8');
const m=html.match(/<script>([\s\S]*?)<\/script>/); const code=m[1]; const off=m.index+'<script>'.length;
const sf=ts.createSourceFile('a.js',code,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const gruppen={"daten-fragen-1.js":["FRAGEN_TIERE_PROFI","FRAGEN_GESCHICHTE"],"daten-fragen-2.js":["FRAGEN_FAECHER1","FRAGEN_FAECHER2","FRAGEN_FAECHER3"],"daten-bilder.js":["AVATAR_IMG","WAPPEN_IMG","LOGO_DATEN"],"daten-texte.js":["LESER","EXTRA_EINTRAEGE"]};
const ziel={};for(const [f,ns] of Object.entries(gruppen)) ns.forEach(n=>ziel[n]=f);
const schnitte=[];const inhalt={};
for(const st of sf.statements){ if(!ts.isVariableStatement(st)) continue; const ds=st.declarationList.declarations; if(ds.length!==1) continue; const n=ds[0].name.getText(sf); if(!ziel[n]) continue;
  const a=st.getStart(sf), b=st.getEnd(); (inhalt[ziel[n]]=inhalt[ziel[n]]||[]).push(code.slice(a,b)); schnitte.push([a,b,n]); }
const gefunden=schnitte.map(x=>x[2]); const fehlt=Object.keys(ziel).filter(n=>!gefunden.includes(n)); if(fehlt.length){ console.error('fehlt',fehlt); process.exit(1); }
let neu=code; schnitte.sort((x,y)=>y[0]-x[0]).forEach(([a,b,n])=>{ neu=neu.slice(0,a)+`/* ${n}: ausgelagert nach ${ziel[n]} */`+neu.slice(b); });
for(const [f,teile] of Object.entries(inhalt)) fs.writeFileSync(outdir+'/'+f,'/* easyplay Daten, wird von index.html geladen */\n'+teile.join('\n')+'\n');
const tags=Object.keys(gruppen).map(f=>`<script src="${f}"></script>`).join('\n');
html=html.slice(0,m.index)+tags+'\n<script>'+neu+'</script>'+html.slice(m.index+m[0].length);
fs.writeFileSync(src,html); console.log('ok',gefunden.length);
