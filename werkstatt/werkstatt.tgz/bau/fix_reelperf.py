import sys
CSS='''
/* Qeels: Tempo und Speicher auf dem Handy */
#reels .reel{content-visibility:auto;contain:layout paint style}
#reels .reel:not(.aktiv) *,#reels .reel:not(.aktiv) *::before,#reels .reel:not(.aktiv) *::after{animation-play-state:paused!important}
@media (pointer:coarse),(max-width:760px){
  #reels .reel *{-webkit-backdrop-filter:none!important;backdrop-filter:none!important}
  #reels .rakarte{background:rgba(10,12,24,.74)!important}
}
'''
PRUNE='''
function rlAufraeumen(){
  const feed=$("#rfeed"); if(!feed) return; const akt=rlAktiv(); if(!akt) return;
  const kinder=[...feed.children], pos=kinder.indexOf(akt), weg=pos-6; if(weg<=0) return;
  const h=akt.offsetHeight||feed.clientHeight; let dy=0;
  for(let k=0;k<weg;k++){ const s=kinder[k]; try{ RL.obs && RL.obs.unobserve(s); }catch(e){} s.querySelectorAll("img").forEach(im=>{ im.removeAttribute("srcset"); im.src=""; }); RL.map.delete(+s.dataset.i); dy+=s.offsetHeight||h; s.remove(); }
  const snap=feed.style.scrollSnapType; feed.style.scrollSnapType="none"; feed.scrollTop=Math.max(0,feed.scrollTop-dy); requestAnimationFrame(()=>{ feed.style.scrollSnapType=snap; });
}
'''
for p in sys.argv[1:]:
    h=open(p,encoding='utf-8').read(); n=[]
    a='const it=rlNaechstes(); if(!it) break; const idx=RL.map.size;'
    if a in h: h=h.replace(a,'const it=rlNaechstes(); if(!it) break; if(RL.nextIdx==null || RL.map.size===0) RL.nextIdx=RL.map.size; const idx=RL.nextIdx++;',1); n.append("idx")
    a='rlHinzu(4);\n    }\n  }),{root:'
    if a in h: h=h.replace(a,'rlHinzu(4);\n      setTimeout(rlAufraeumen, 350);\n    }\n  }),{root:',1); n.append("prune-call")
    if 'function rlAufraeumen' not in h: k=h.index('function rlHinzu('); h=h[:k]+PRUNE.lstrip()+h[k:]; n.append("prune")
    if '/* Qeels: Tempo und Speicher auf dem Handy */' not in h: k=h.index('</style>'); h=h[:k]+CSS+h[k:]; n.append("css")
    open(p,'w',encoding='utf-8').write(h); print(p,n)
