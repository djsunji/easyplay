import sys
CSP=("default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net; "
 "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; "
 "img-src 'self' https: data: blob:; connect-src 'self' https://de.wikipedia.org https://commons.wikimedia.org https://*.supabase.co wss://*.supabase.co; "
 "frame-src https://www.openstreetmap.org; media-src 'self' https: data: blob:; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; form-action 'self'")
for fn,csp in [(a, None if "lernspiel" in a else CSP) for a in sys.argv[1:]]:
    s=open(fn,encoding="utf-8").read()
    if "nurHttps" not in s:
        a='const e=s && ix[seiteKey(s)]; if(e && e[0]) return {'
        assert s.count(a)==1, fn
        s=s.replace(a,'const e=s && ix[seiteKey(s)]; if(e && nurHttps(e[0])) return {')
        s=s.replace('dateiUrl:e[4]||"", seite:e[4]||""','dateiUrl:nurHttps(e[4])||"", seite:nurHttps(e[4])||""')
        s=s.replace('let BIDX=null, BIDXP=null;','let BIDX=null, BIDXP=null;\n// Nur echte https-Adressen aus dem Bildindex verwenden\nfunction nurHttps(u){ try{ const x=new URL(String(u||"")); return x.protocol==="https:" ? x.href : ""; }catch(e){ return ""; } }',1)
    if 'name="referrer"' not in s:
        meta='<meta name="referrer" content="strict-origin-when-cross-origin">\n'
        if csp: meta=f'<meta http-equiv="Content-Security-Policy" content="{csp}">\n'+meta
        s=s.replace('<meta charset="utf-8">','<meta charset="utf-8">\n'+meta,1) if '<meta charset="utf-8">' in s else s.replace('<head>','<head>\n'+meta,1)
    open(fn,"w",encoding="utf-8").write(s); print(fn, "nurHttps" in s, 'Content-Security' in s)
