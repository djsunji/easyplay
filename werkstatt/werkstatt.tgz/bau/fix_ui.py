for p in ['/mnt/user-data/outputs/easyplay/index.html','/mnt/user-data/outputs/lernspiel.html']:
    s=open(p,encoding='utf-8').read()
    css='@media (max-width:760px){.hero .ctas .big:last-child:nth-child(odd){grid-column:1 / -1}}'
    add='\n/* Knopfreihe: nie aus der Box ragen */\n@media (min-width:761px){.hero .ctas{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.hero .ctas .big{width:100%;justify-content:center;white-space:normal;line-height:1.2;text-align:center;overflow:hidden}}\n.hero .ctas .big{min-width:0;overflow-wrap:anywhere}\n/* Ruhig: beim erneuten Zeichnen derselben Seite keine Einblend-Animation */\nbody.ruhig .thema,body.ruhig .kanton,body.ruhig .bereich,body.ruhig .level,body.ruhig .mode,body.ruhig .buch{animation:none!important}'
    if 'Knopfreihe: nie aus' not in s:
        assert s.count(css)==1; s=s.replace(css,css+add)
    old='function render(){\n'
    new='function render(){\n  try{ const jetzt=performance.now(); const gleich=S.screen===window.__epLetzteSeite && jetzt-(window.__epLetztesRender||0)<5000 && !["quiz","done","duellplay","check","live"].includes(S.screen); document.body.classList.toggle("ruhig",gleich); window.__epLetzteSeite=S.screen; window.__epLetztesRender=jetzt; }catch(e){}\n'
    if '__epLetzteSeite' not in s:
        assert s.count(old)==1; s=s.replace(old,new)
    old2='if(!matchMedia("(prefers-reduced-motion: reduce)").matches) document.querySelectorAll(".zaehler")'
    new2='if(!window.__epGezaehlt && (window.claude || S.fragenQuelle) && !matchMedia("(prefers-reduced-motion: reduce)").matches && (window.__epGezaehlt=true)) document.querySelectorAll(".zaehler")'
    if '__epGezaehlt' not in s:
        assert s.count(old2)==1; s=s.replace(old2,new2)
    open(p,'w',encoding='utf-8').write(s); print('ok',p)
