# Idempotent: neue LP21-Themen in BEREICHE und EMO eintragen (index.html und lernspiel.html), Mapping in lehrer.js
import re,sys
NUR=set(sys.argv[1:]) or None
NEU = {
 'alltag': [('fremdsprachen', [
   '{id:"englisch", name:"Englisch", emo:"uk", text:"Wörter, Grammatik und Kultur"}',
   '{id:"franzoesisch", name:"Französisch", emo:"croissant", text:"Mots, grammaire et culture"}',
   ]), ('allgemein', ['{id:"ethik", name:"Ethik", emo:"scale", text:"Werte, Gerechtigkeit und Zusammenleben"}'])],
 'natur': [('technik', ['{id:"informatik", name:"Informatik", emo:"laptop", text:"Programmieren, Daten und Netzwerke"}'])],
 'geld': [('beruf', ['{id:"haushalt", name:"Haushalt & Ernährung", emo:"pan", text:"Essen, Konsum und Wohnen"}'])],
}
EMO_ADD = 'uk:"💂",croissant:"🥐",scale:"⚖️",'
for f in ['/mnt/user-data/outputs/easyplay/index.html','/mnt/user-data/outputs/lernspiel.html']:
    s=open(f,encoding='utf-8').read(); n0=len(s)
    for ber,lst in NEU.items():
        for nach,items in lst:
            for it in reversed(items):
                tid=re.search(r'id:"(\w+)"',it).group(1)
                if f'{{id:"{tid}",' in s or (NUR and tid not in NUR): continue
                m=re.search(r'\n(\s*)\{id:"%s", name:[^\n]*?\}(\]\}|\},)?' % nach, s)
                line_end=s.index('\n', m.start()+1)
                line=s[m.start()+1:line_end]; ind=m.group(1)
                r=line.rstrip(); tail=r[r.rindex('"}')+2:]
                if tail.startswith(']'):
                    newline=r[:len(r)-len(tail)]+',\n'+ind+it+tail
                else:
                    newline=line+'\n'+ind+it+','
                s=s[:m.start()+1]+newline+s[line_end:]
    if 'uk:"💂"' not in s: s=s.replace('const EMO = {','const EMO = {'+EMO_ADD,1)
    open(f,'w',encoding='utf-8').write(s); print(f, len(s)-n0)
p='/home/claude/lehrer_dev/lehrer.js'; s=open(p,encoding='utf-8').read()
if 'englisch:[' not in s:
    s=s.replace('fremdsprachen:[','englisch:[["FS1E.5","FS1E.6"],["FS1E.5","FS1E.6"]], franzoesisch:[["FS2F.5","FS2F.6"],["FS2F.5","FS2F.6"]], ethik:[["NMG.11"],["ERG.2","ERG.1","ERG.5"]], informatik:[["MI.2"],["MI.2","MI.AK"]], haushalt:[["NMG.6","NMG.1"],["WAH.4","WAH.3","WAH.5"]],\n  fremdsprachen:[',1)
    open(p,'w',encoding='utf-8').write(s); print('lehrer.js ok')
