import sys
SL="".join(f'<i style="--i:{i}"></i>' for i in range(14))
def fahne(k,n): return f'<button class="fahne" type="button" data-lang="{k}" title="{n} (bald verfügbar)" aria-label="{n} (bald verfügbar)"><span class="mast"></span><span class="tuch" style="--bild:url(flags/{k}.svg)">{SL}</span></button>'
FAHNEN='<div class="fahnen" role="group" aria-label="Sprachen (bald verfügbar)">'+fahne("fr","Français")+fahne("it","Italiano")+fahne("gb","English")+'</div>'
CSS='''
/* Startseite: Logo oben links nur Schrift, gross */
.topbar .logoimg{display:none!important}
.topbar .wmimg{height:62px!important;width:auto}
@media (max-width:760px){.topbar .wmimg{height:44px!important}}
/* Fahnenmasten */
.fahnen{display:flex;gap:30px;align-items:flex-end;height:150px;margin:0 0 14px}
.fahne{position:relative;width:104px;height:150px;background:none;border:0;padding:0;cursor:pointer;flex:none}
.fahne:focus-visible{outline:3px solid var(--accent,#8A3FE0);outline-offset:4px;border-radius:8px}
.fahne .mast{position:absolute;left:6px;bottom:0;width:6px;height:146px;border-radius:3px;background:linear-gradient(90deg,#7d838c,#eef1f4 45%,#8f959e)}
.fahne .mast::before{content:"";position:absolute;top:-9px;left:-3px;width:12px;height:12px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff1b8,#d4a017 70%)}
.fahne .mast::after{content:"";position:absolute;bottom:-3px;left:-9px;width:24px;height:7px;border-radius:4px;background:#6d727a}
.fahne .tuch{position:absolute;left:12px;top:4px;width:84px;height:63px;display:flex;filter:drop-shadow(0 4px 4px rgba(0,0,0,.18))}
.fahne .tuch i{position:relative;flex:none;width:6px;height:100%;background-image:var(--bild);background-size:84px 63px;background-position:calc(var(--i) * -6px) 0;
  animation:fahneWeh 1.7s ease-in-out infinite;animation-delay:calc(var(--i) * -0.11s);--a:calc(var(--i) * .45px)}
.fahne .tuch i::after{content:"";position:absolute;inset:0;background:#000;opacity:0;animation:fahneSchatten 1.7s ease-in-out infinite;animation-delay:inherit}
@keyframes fahneWeh{0%,100%{transform:translateY(calc(var(--a) * -1))}50%{transform:translateY(var(--a))}}
@keyframes fahneSchatten{0%,100%{opacity:0}50%{opacity:.16}}
.fahne:hover .tuch{transform:scale(1.04);transition:transform .2s}
@media (max-width:760px){.fahnen{justify-content:center;gap:18px;height:120px}.fahne{width:84px;height:120px}.fahne .mast{height:116px}.fahne .tuch{width:64px;height:48px}.fahne .tuch i{width:calc(64px / 14);background-size:64px 48px;background-position:calc(var(--i) * -64px / 14) 0}}
@media (prefers-reduced-motion:reduce){.fahne .tuch i,.fahne .tuch i::after{animation:none}}
'''
for p in sys.argv[1:]:
    h=open(p,encoding='utf-8').read(); n=[]
    a='<h1 class="hero-wm2"><img src="${WM_SRC}" alt="easyplay"></h1>'
    if a in h: h=h.replace(a,'<h1 class="sr-only">easyplay</h1>'+FAHNEN,1); n.append("fahnen")
    for a in ['          <button class="big" id="play" type="button"><span class="cicon">🎮</span> Jetzt spielen</button>\n',
              '          <button class="big wettb" id="toLive" type="button"><span class="cicon blitz">⚡</span> Wettbewerb</button>\n']:
        if a in h: h=h.replace(a,'',1); n.append("knopf")
    for a,b in [('$("#play").onclick=()=>$("#bereiche").scrollIntoView({behavior:"smooth"});','$("#play") && ($("#play").onclick=()=>$("#bereiche").scrollIntoView({behavior:"smooth"}));'),
                ('$("#toLive").onclick=()=>go("live");','$("#toLive") && ($("#toLive").onclick=()=>go("live"));'),
                ('if(after==="mode" && S.thema) go("mode"); else go("profil");','if(after==="mode" && S.thema) go("mode"); else if(after==="hardcoreinfo") go("hardcoreinfo"); else go("profil");')]:
        if a in h: h=h.replace(a,b,1); n.append("js")
    if "/* Fahnenmasten */" not in h:
        i=h.index("</style>"); h=h[:i]+CSS+h[i:]; n.append("css")
    if 'src="hardcore.js"' not in h:
        h=h.replace('<script src="lehrer.js"></script>','<script src="lehrer.js"></script>\n<script src="hardcore.js"></script>',1); n.append("script")
    open(p,'w',encoding='utf-8').write(h); print(p,n)
