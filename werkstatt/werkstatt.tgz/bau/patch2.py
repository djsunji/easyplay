import json,re
L=json.load(open('/home/claude/bau/logos.json'))
L['kat']['kaufhaus']='Warenhaus mit Mode und Feinkost'
neu=[]
for f in ['out_personen.json','out_teams.json','out_firmen.json']: neu+=json.load(open('/home/claude/mk/'+f))
OLY=json.load(open('/home/claude/mk/olympia.json'))
FIRMLOGO={'ABB':'abb','Globus':'globus','Sunrise':'sunrise','Digitec Galaxus':'galaxus','SRG SSR':'srgssr','Threema':'threema','Proton AG':'proton','Proton':'proton'}
for e in neu:
    if e['kap']=='x_firmen' and e['titel'] in FIRMLOGO: e['logo']=FIRMLOGO[e['titel']]
print('Firmen mit Logo:',[e['titel'] for e in neu if e.get('logo')])
neu_js=json.dumps(neu,ensure_ascii=False,separators=(',',':'))
JS_LOGO=r'''
/* ================= Logo-Quiz (Logos: Simple Icons, CC0) ================= */
const LOGO_DATEN = __LOGOS__;
const LOGO_MAP = Object.fromEntries(LOGO_DATEN.logos.map(o=>[o.s,o]));
function logoHell(hex){ const n=parseInt(hex,16); const r=(n>>16)&255,g=(n>>8)&255,b=n&255; return (0.299*r+0.587*g+0.114*b)/255>0.78; }
function logoSvg(slug, cls){ const o=LOGO_MAP[slug]; if(!o) return "";
  return `<span class="logobox ${logoHell(o.h)?"dunkel":""} ${cls||""}" role="img" aria-label="Logo"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#${o.h}" d="${o.p}"/></svg></span>`; }
const LOGOFRAGEN = [];
(function(){
  const LL=LOGO_DATEN.logos, K=LOGO_DATEN.kat;
  LL.forEach(o=>{
    const ch=o.ch?" Das ist eine Schweizer Firma.":"";
    if(!o.w){
      const gleich=LL.filter(x=>x.k===o.k && x.n!==o.n).map(x=>x.n);
      const falsch=pick3(gleich,o.n); const andere=shuffle(LL.filter(x=>x.n!==o.n && !falsch.includes(x.n)).map(x=>x.n));
      while(falsch.length<3) falsch.push(andere.pop());
      LOGOFRAGEN.push({t:"logos",l:o.l,img:"l:"+o.s,s:o.n,q:"Zu welcher Marke gehört dieses Logo?",a:[o.n,...falsch],e:`Das ist das Logo von ${o.n} (Bereich: ${K[o.k]}).${ch}`,m:`Dieses Logo gehört zu ${o.n}.`});
    } else {
      const kats=Object.keys(K).filter(x=>x!==o.k).map(x=>K[x]);
      LOGOFRAGEN.push({t:"logos",l:o.l,img:"l:"+o.s,s:o.n,q:"Was bietet diese Firma vor allem an?",a:[K[o.k],...pick3(kats,K[o.k])],e:`Das ist das Logo von ${o.n}. Die Firma gehört zum Bereich ${K[o.k]}.${ch}`,m:`${o.n} gehört zum Bereich ${K[o.k]}.`});
    }
  });
})();
FRAGEN.push(...LOGOFRAGEN);
'''.replace('__LOGOS__',json.dumps(L,ensure_ascii=False,separators=(',',':')))
JS_OLY=r'''
const OLYMPIA = __OLY__;
function olympiaHTML(s){
  const o=s.olympia; if(!o) return "";
  const hat=o.gold!=null;
  return `<div class="olybox"><div class="olykopf"><span class="olyringe" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span><b>Die Schweiz an Olympia</b></div>
    <p class="olyart">${esc(o.olympisch||"")}</p>
    ${hat?`<div class="olymed"><span class="m g">🥇 <b>${o.gold}</b><small>Gold</small></span><span class="m s">🥈 <b>${o.silber}</b><small>Silber</small></span><span class="m b">🥉 <b>${o.bronze}</b><small>Bronze</small></span></div>`:""}
    <p>${esc(o.text||"")}</p>
    ${o.sportler&&o.sportler.length?`<p class="olysp"><b>Bekannte Namen:</b> ${o.sportler.map(esc).join(", ")}</p>`:""}
    ${o.stand?`<p class="olystand">${esc(o.stand)}</p>`:""}</div>`;
}
'''.replace('__OLY__',json.dumps(OLY,ensure_ascii=False,separators=(',',':')))
CSS=r'''
/* ---- Logo-Quiz und Logos ---- */
.logobox{display:inline-grid;place-items:center;background:#fff;border-radius:22px;padding:18px;box-shadow:0 8px 20px -10px rgba(27,34,64,.35);border:2px solid rgba(0,0,0,.06)}
.logobox.dunkel{background:#2A2F45}
.logobox svg{width:100%;height:100%;display:block}
.qimg .logobox.qbig{width:170px;height:170px;max-width:60vw;max-height:60vw}
.bibimg .logobox{width:70px!important;height:70px!important;padding:8px!important}
.ebild .logobox{width:130px;height:130px;position:relative;z-index:2}
/* ---- Olympia-Kasten ---- */
.olybox{margin:14px 0;padding:14px 16px;border-radius:18px;border:2px solid var(--libline);background:linear-gradient(135deg,color-mix(in srgb,#FFC23A 12%,var(--libpaper)),var(--libpaper));color:var(--libink)}
.olykopf{display:flex;align-items:center;gap:10px;font-size:1.1rem}
.olyringe{display:inline-flex;gap:2px}.olyringe i{width:14px;height:14px;border-radius:50%;border:3px solid;display:block}
.olyringe i:nth-child(1){border-color:#0081C8}.olyringe i:nth-child(2){border-color:#222}.olyringe i:nth-child(3){border-color:#EE334E}.olyringe i:nth-child(4){border-color:#FCB131}.olyringe i:nth-child(5){border-color:#00A651}
.olyart{margin:6px 0;font-weight:700;color:var(--libacc)}
.olymed{display:flex;gap:10px;flex-wrap:wrap;margin:8px 0}
.olymed .m{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:14px;background:var(--libpaper);border:2px solid var(--libline);font-size:1.05rem}
.olymed .m b{font-size:1.3rem}.olymed .m small{color:var(--libacc);font-weight:700}
.olymed .g{border-color:#E8B923}.olymed .s{border-color:#B9BCC4}.olymed .b{border-color:#C8814B}
.olysp{font-size:.95rem}.olystand{font-size:.8rem;color:color-mix(in srgb,var(--libink) 60%,transparent);margin:0}
'''
def patch(path):
    h=open(path,encoding='utf-8').read()
    def r(a,b,cnt=1):
        nonlocal h
        n=h.count(a); assert n==cnt,(path,a[:70],n); h=h.replace(a,b)
    # Logo-Quiz
    r('FRAGEN.push(...BILDFRAGEN);','FRAGEN.push(...BILDFRAGEN);\n'+JS_LOGO)
    r('''  if(t==="a") return avatar(k).replace('class="ic av-ic"','class="ic av-ic qbig"');''','''  if(t==="a") return avatar(k).replace('class="ic av-ic"','class="ic av-ic qbig"');
  if(t==="l") return logoSvg(k,"qbig");''')
    r('    {id:"beruf", name:"Berufswahl & Lehre", emo:"toolbox", text:"Welche Lehre passt zu mir?"}]},',
      '    {id:"beruf", name:"Berufswahl & Lehre", emo:"toolbox", text:"Welche Lehre passt zu mir?"},\n    {id:"logos", name:"Logo-Quiz", emo:"image", text:"Marken und Firmen am Logo erkennen"}]},')
    r('if(ok.length){ FRAGEN.length = 0; FRAGEN.push(...ok); render(); }','if(ok.length){ FRAGEN.length = 0; FRAGEN.push(...ok); const da=new Set(ok.map(f=>f.img).filter(Boolean)); FRAGEN.push(...LOGOFRAGEN.filter(f=>!da.has(f.img))); render(); }')
    r('b.themen.filter(t=>t.id!=="bilder")','b.themen.filter(t=>t.id!=="bilder"&&t.id!=="logos")')
    r('id!=="kt_alle" && id!=="bilder"','id!=="kt_alle" && id!=="bilder" && id!=="logos"')
    r('    if(t.id==="bilder") return;','    if(t.id==="bilder"||t.id==="logos") return;')
    # neue Kapitel
    i=h.index('const EXTRA_EINTRAEGE = ['); j=h.index('];\nconst EXTRA_KAP',i)
    h=h[:j]+','+neu_js[1:-1]+h[j:]
    r('''  x_kultur:{titel:"Kultur & Musik", emo:"🎭", buch:"alltag"}''','''  x_kultur:{titel:"Kultur & Musik", emo:"🎭", buch:"alltag"},
  x_teams:{titel:"Schweizer Nationalteams", emo:"🇨🇭", buch:"alltag"},
  x_personen:{titel:"Personen", emo:"🧑", buch:"alltag"},
  x_firmen:{titel:"Schweizer Firmen", emo:"🏢", buch:"geld"}''')
    r('''      return {typ:"fr", titel:e.titel, wiki:e.wiki, emo:e.emo, geo:e.geo||null, fluss:id==="x_fluesse",''','''      return {typ:"fr", titel:e.titel, wiki:e.wiki, emo:e.emo, geo:e.geo||null, fluss:id==="x_fluesse", logo:e.logo||null, olympia:id==="x_sport"?(OLYMPIA[e.titel]||null):null,''')
    r('/* ---------- Bibliothek: neue Sachkapitel', JS_OLY+'\n/* ---------- Bibliothek: neue Sachkapitel')
    r('    inhalt = `${gipfelInfoHTML(s)}${steckHTML(s)}','    inhalt = `${gipfelInfoHTML(s)}${steckHTML(s)}${olympiaHTML(s)}')
    # Firmen: Logo im Bild, Wikipedia-Logo zulassen
    r('''    <span class="ebemo">${emo}</span><span class="ebtitel">''','''    ${s.logo?logoSvg(s.logo):`<span class="ebemo">${emo}</span>`}<span class="ebtitel">''')
    r('''async function wikiBildMehrfach(kandidaten, suche){
  const gut=b=>b && !BILD_SCHLECHT.test(b.datei||b.src||"");''','''async function wikiBildMehrfach(kandidaten, suche, roh){
  const gut=b=>b && (roh || !BILD_SCHLECHT.test(b.datei||b.src||""));''')
    r('''function zeigeWikiBild(titel, nr, kandidaten, suche){
  const fig=$("#wBild"); if(!fig) return;
  (kandidaten ? wikiBildMehrfach(kandidaten, suche) : wikiBild(titel))''','''function zeigeWikiBild(titel, nr, kandidaten, suche, roh){
  const fig=$("#wBild"); if(!fig) return;
  (kandidaten ? wikiBildMehrfach(kandidaten, suche, roh) : wikiBild(titel))''')
    r('''s.titel!=="Allgemeines" ? s.titel+" "+s.kap.titel : s.kap.titel);''','''s.titel!=="Allgemeines" ? s.titel+" "+s.kap.titel : s.kap.titel, s.kap.id==="x_firmen");''')
    r('</style>',CSS+'\n</style>')
    open(path,'w',encoding='utf-8').write(h)
for p in ['/mnt/user-data/outputs/lernspiel.html','/mnt/user-data/outputs/easyplay/index.html']: patch(p)
print('ok')
