import sys
for p in sys.argv[1:]:
    h=open(p,encoding='utf-8').read(); n=0
    a="setTimeout(bibAufwaermen,0);"
    if a in h: h=h.replace(a,"/* Bibliothek wird erst beim Öffnen aufgebaut (Tempo) */",1); n+=1
    if "__epScrollPause" not in h:
        css="body.scrollt *,body.scrollt *::before,body.scrollt *::after{animation-play-state:paused!important}\n.blob{contain:strict}\n"
        i=h.index("</style>"); h=h[:i]+css+h[i:]; n+=1
        js="<script>/*__epScrollPause*/(function(){let t=0;addEventListener('scroll',function(){if(!t)document.body.classList.add('scrollt');clearTimeout(t);t=setTimeout(function(){document.body.classList.remove('scrollt');t=0;},180);},{passive:true});document.addEventListener('visibilitychange',function(){document.body.classList.toggle('scrollt',document.hidden);});})();</script>\n"
        i=h.rindex("</body>"); h=h[:i]+js+h[i:]; n+=1
    open(p,'w',encoding='utf-8').write(h); print(p,n)
