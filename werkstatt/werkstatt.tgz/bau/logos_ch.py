import os,re,base64,json,subprocess,sys
SRC='/home/claude/logos_ch'; OUT='/home/claude/logos_out'
def minify(svg):
    svg=re.sub(r'<\?xml.*?\?>','',svg,flags=re.S); svg=re.sub(r'<!DOCTYPE.*?>','',svg,flags=re.S)
    svg=re.sub(r'<!--.*?-->','',svg,flags=re.S); svg=re.sub(r'<metadata.*?</metadata>','',svg,flags=re.S)
    svg=re.sub(r'<title>.*?</title>|<desc>.*?</desc>','',svg,flags=re.S)
    svg=re.sub(r'\s+',' ',svg).strip(); svg=re.sub(r'>\s+<','><',svg)
    # viewBox ergänzen, falls nur width/height
    m=re.search(r'<svg[^>]*>',svg); tag=m.group(0)
    if 'viewBox' not in tag:
        w=re.search(r'width="([\d.]+)',tag); h=re.search(r'height="([\d.]+)',tag)
        if w and h: svg=svg.replace(tag,tag[:-1]+f' viewBox="0 0 {w.group(1)} {h.group(1)}">',1)
    return svg
gross=[]
daten={}
for f in sorted(os.listdir(SRC)):
    nr=int(f[:3]); p=os.path.join(SRC,f)
    if f.endswith('.svg') and os.path.getsize(p)<40000:
        s=minify(open(p,encoding='utf-8',errors='ignore').read())
        daten[nr]='data:image/svg+xml;base64,'+base64.b64encode(s.encode()).decode()
    else: gross.append((nr,p))
json.dump({'daten':{str(k):v for k,v in daten.items()},'gross':gross},open(OUT+'/zwischen.json','w'))
print(len(daten),'SVG direkt;',len(gross),'zum Umwandeln:',[g[0] for g in gross])
