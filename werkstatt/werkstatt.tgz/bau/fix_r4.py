import sys
CSS='''
/* Runde 4: Logo ohne Umbruch, Überschriften als Abzeichen, Bereich-Karten */
@media (min-width:761px){
  .topbar{flex-wrap:nowrap!important;align-items:center!important}
  .topbar .logo{flex:1 1 auto;min-width:0;padding:0!important}
  .topbar .wmimg{height:auto!important;width:100%!important;max-width:470px;max-height:140px;object-fit:contain;object-position:left center}
  .nav{flex:none!important;width:auto!important}
}
#stufeLbl::before,#bereiche::before,#stufeLbl::after,#bereiche::after{content:none!important}
p#stufeLbl.label,p#bereiche.label{display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;text-align:center;gap:12px!important;margin:46px 0 22px!important;font-size:clamp(1.7rem,3.6vw,2.5rem)!important}
#stufeLbl>span,#bereiche>span{text-decoration:none!important;display:inline-flex;align-items:center;gap:14px;padding:10px 30px 10px 10px;border-radius:999px;color:#fff;
  background:linear-gradient(135deg,#8A3FE0,#3D5AFE);box-shadow:0 7px 0 rgba(0,0,0,.28),0 18px 40px -14px #8A3FE0;position:relative}
#bereiche>span{background:linear-gradient(135deg,#17A35A,#E0A100);box-shadow:0 7px 0 rgba(0,0,0,.28),0 18px 40px -14px #F2A000}
#stufeLbl>span::before,#bereiche>span::before{content:"🎯";display:grid;place-items:center;width:1.7em;height:1.7em;border-radius:50%;background:#fff;font-size:.72em;box-shadow:inset 0 -3px 0 rgba(0,0,0,.12)}
#bereiche>span::before{content:"🧭"}
#stufeLbl>span::after,#bereiche>span::after{content:"✦";position:absolute;right:-22px;top:-12px;font-size:.6em;color:#FFD54A;animation:twinkle 2.4s ease-in-out infinite}
#bereiche small{order:0!important;margin:0!important}
.bereiche .bereich{min-height:0!important;padding:22px 18px 26px!important}
.bereiche .bereich h2{font-size:clamp(1.25rem,2.2vw,1.75rem)!important;line-height:1.15;overflow-wrap:anywhere;hyphens:auto;max-width:100%}
.bereiche .bereich p{font-size:.95rem;max-width:100%}
.bereiche .bereich .emo{transform:none!important;margin:34px 0 12px!important;width:118px;height:118px;padding:0!important;display:grid!important;place-items:center;font-size:4.4rem!important;line-height:1!important;border-radius:34px!important;
  background:radial-gradient(circle at 30% 25%,#fff,rgba(255,255,255,.86) 60%,rgba(255,255,255,.7))!important;border:4px solid rgba(255,255,255,.85);
  box-shadow:0 16px 28px -12px rgba(0,0,0,.5),inset 0 -6px 0 rgba(0,0,0,.06)!important;animation:floaty 5s ease-in-out infinite}
.bereiche .bereich:hover .emo{transform:scale(1.06) rotate(-4deg)!important;transition:transform .2s}
@media (max-width:760px){.bereiche .bereich .emo{width:92px;height:92px;font-size:3.4rem!important;border-radius:28px!important}}
@media (prefers-reduced-motion:reduce){.bereiche .bereich .emo{animation:none}}
.eplegal{display:flex;justify-content:center;gap:18px;flex-wrap:wrap;margin:40px 0 24px;font-size:.9rem}
.eplegal a{color:var(--ink);opacity:.75;text-decoration:none;padding:6px 12px;border-radius:999px;background:color-mix(in srgb,var(--surface) 70%,transparent)}
.eplegal a:hover{opacity:1;text-decoration:underline}
'''
FOOT='  <main id="app"></main>\n  <footer class="eplegal"><a href="impressum.html">Impressum</a><a href="datenschutz.html">Datenschutz</a></footer>\n'
for p in sys.argv[1:]:
    h=open(p,encoding='utf-8').read(); n=[]
    if "/* Runde 4:" not in h: i=h.index("</style>"); h=h[:i]+CSS+h[i:]; n.append("css")
    if 'class="eplegal"' not in h:
        a='  <main id="app"></main>\n'; assert a in h; h=h.replace(a,FOOT,1); n.append("footer")
    open(p,'w',encoding='utf-8').write(h); print(p,n)
