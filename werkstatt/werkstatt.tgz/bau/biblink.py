JS=r'''
/* ---------- Quiz: Verknüpfung zum Bibliothekseintrag ---------- */
const QB = { key:"", map:null };
function qbIndex(){
  const key=FRAGEN.length+"|"+S.extra.length;
  if(QB.key===key && QB.map) return QB.map;
  const map=new Map();
  const prio=(s,f)=> (f.s && String(f.s).toLowerCase()===String(s.titel).toLowerCase() ? 4 : 0) + (s.teile?2:0) + (S.texte[seiteKey(s)]?1:0) + (s.titel==="Allgemeines"?-5:0);
  BUECHER.forEach(B=>buchDaten(B.id).seiten.forEach(s=>{
    if(s.typ!=="fr") return;
    s.fragen.forEach(f=>{ const p=prio(s,f); const alt=map.get(f.q); if(!alt || p>alt.p) map.set(f.q,{b:B.id, nr:s.nr, titel:s.titel, buch:B.titel, kap:s.kap?.titel||"", emo:B.emo, p}); });
    if(s.chlogo) map.set("c:"+s.chlogo,{b:B.id, nr:s.nr, titel:s.titel, buch:B.titel, kap:s.kap?.titel||"", emo:B.emo, p:9});
    if(s.logo) map.set("l:"+s.logo,{b:B.id, nr:s.nr, titel:s.titel, buch:B.titel, kap:s.kap?.titel||"", emo:B.emo, p:9});
    map.set("t:"+String(s.titel).toLowerCase(), map.get("t:"+String(s.titel).toLowerCase()) || {b:B.id, nr:s.nr, titel:s.titel, buch:B.titel, kap:s.kap?.titel||"", emo:B.emo, p:0});
  }));
  QB.map=map; QB.key=key; return map;
}
function qbZiel(f){
  const m=qbIndex();
  return (f.img && m.get(f.img)) || m.get(f.q) || (f.s && m.get("t:"+String(f.s).toLowerCase())) || null;
}
function qbFuellen(f){
  const el=$("#bibLink"); if(!el) return;
  let z=null; try{ z=qbZiel(f); }catch(e){}
  if(!z || !$("#bibLink")) return;
  el.innerHTML=`${ico("book")} In der Bibliothek: <a href="#" id="bibLinkA">${esc(z.titel)}</a> <small>${z.emo} ${esc(z.buch)} · ${esc(z.kap)}</small>`;
  el.hidden=false;
  $("#bibLinkA").onclick=e=>{ e.preventDefault(); stopSpeak&&stopSpeak(); LIB.buch=z.b; LIB.seite=z.nr; LIB.zufall=false; LIB.vonQuiz=true;
    S.libModus=true; document.documentElement.dataset.mode="lib"; go("libseite"); scrollTo(0,0); };
}
'''
CSS=r'''
/* ---- Bibliothekslink im Quiz ---- */
.biblink{margin:12px 0 4px;padding:10px 14px;border-radius:14px;background:color-mix(in srgb,#8A5A2B 10%,transparent);border:2px solid color-mix(in srgb,#8A5A2B 30%,transparent);font-weight:700;display:flex;flex-wrap:wrap;align-items:center;gap:6px}
.biblink a{color:#8A5A2B;text-decoration:underline;text-decoration-thickness:2px;text-underline-offset:3px}
:root[data-theme="dark"] .biblink a{color:#E0B070}
.biblink small{font-weight:600;opacity:.75}
.zurueckquiz{margin:0 0 14px;display:flex;justify-content:center}
'''
for p in ['/mnt/user-data/outputs/lernspiel.html','/mnt/user-data/outputs/easyplay/index.html']:
    h=open(p,encoding='utf-8').read()
    def r(a,b):
        global h
        assert h.count(a)==1,(p,a[:70],h.count(a)); h=h.replace(a,b)
    r('/* ---------- Bibliothek: Querverweise zwischen Artikeln ---------- */', JS+'\n/* ---------- Bibliothek: Querverweise zwischen Artikeln ---------- */')
    r('''        <div class="merke"><small>Merke dir</small>${esc(f.m)}</div>
        ${quelle(f)}''','''        <div class="merke"><small>Merke dir</small>${esc(f.m)}</div>
        <p class="biblink" id="bibLink" hidden></p>
        ${quelle(f)}''')
    r('''  $("#toQuestion") && ($("#toQuestion").onclick=()=>{ Q.tab="frage"; render(); });''','''  $("#toQuestion") && ($("#toQuestion").onclick=()=>{ Q.tab="frage"; render(); });
  if($("#bibLink")) setTimeout(()=>qbFuellen(f),0);''')
    # Zurück zum Quiz in der Bibliothek
    r('''      ${LIB.zufall?`<div class="zufallleiste">''','''      ${LIB.vonQuiz&&S.quiz?`<div class="zurueckquiz"><button class="big gold" id="zumQuiz" type="button">↩️ Zurück zum Quiz (Frage ${S.quiz.i+1} von ${S.quiz.list.length})</button></div>`:""}
      ${LIB.zufall?`<div class="zufallleiste">''')
    r('''  $("#nochZufall") && ($("#nochZufall").onclick=zufallArtikel);''','''  $("#nochZufall") && ($("#nochZufall").onclick=zufallArtikel);
  $("#zumQuiz") && ($("#zumQuiz").onclick=()=>{ LIB.vonQuiz=false; S.libModus=false; document.documentElement.dataset.mode="spiel"; go("quiz"); scrollTo(0,0); });''')
    for fn in ["function renderLibBuch(){\n  LIB.zufall=false;\n","function renderLibKapitel(){\n  LIB.zufall=false;\n","function renderLib(){\n  LIB.zufall=false;\n"]:
        r(fn, fn+"  LIB.vonQuiz=false;\n")
    r('</style>',CSS+'\n</style>')
    open(p,'w',encoding='utf-8').write(h)
print('ok')
