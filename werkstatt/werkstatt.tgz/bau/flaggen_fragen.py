import json,random
random.seed(7)
F=[json.loads(l.rstrip(',\n')) for l in open('/home/claude/mk/gross/flaggen.json') if l.strip().startswith('{')]
by={f['code']:f for f in F}
ALT={'ch','de','fr','it','at','li','nl','be','se','dk','jp'}
KONT=["Europa","Asien","Afrika","Nordamerika","Südamerika","Ozeanien"]
out={1:[],2:[],3:[]}
def falsch(f,feld,n=3,cond=lambda x:True):
    pool=[by[c][feld] for c in f['aehnlich'] if c in by and cond(by[c])]
    same=[x[feld] for x in F if x['kontinent']==f['kontinent'] and x['code']!=f['code'] and cond(x)]
    random.shuffle(same); rest=[x[feld] for x in F if x['code']!=f['code'] and cond(x)]; random.shuffle(rest)
    res=[]
    for v in pool+same+rest:
        if v!=f[feld] and v not in res: res.append(v)
        if len(res)==n: break
    return res
for f in [x for x in F if not x.get('skip')]:
    s=f['stufe']; img='f:'+f['code']; n=f['name']
    if f['code'] not in ALT:
        out[s].append({"t":"bilder","l":s,"s":"Flagge "+n,"img":img,"q":"Zu welchem Land gehört diese Flagge?",
          "a":[n]+falsch(f,'name'),"e":f"Das ist die Flagge von {n}. {f['e']}","m":f"Diese Flagge gehört zu {n}."})
    if f['hs_frage']:
        l=min(s+1,3)
        out[l].append({"t":"bilder","l":l,"s":"Flagge "+n,"img":img,"q":"Wie heisst die Hauptstadt des Landes mit dieser Flagge?",
          "a":[f['hauptstadt']]+falsch(f,'hauptstadt',cond=lambda x:x['hs_frage']),"e":f"Das ist die Flagge von {n}. Die Hauptstadt von {n} ist {f['hauptstadt']}.","m":f"Die Hauptstadt von {n} ist {f['hauptstadt']}."})
    if f['kont_frage']:
        l=1 if s<=2 else 2
        k=f['kontinent']; fa=[x for x in KONT if x!=k]; random.shuffle(fa)
        out[l].append({"t":"bilder","l":l,"s":"Flagge "+n,"img":img,"q":"Auf welchem Kontinent liegt das Land mit dieser Flagge?",
          "a":[k]+fa[:3],"e":f"Das ist die Flagge von {n}. {n} liegt in {'Nord- und Mittelamerika' if k=='Nordamerika' else k}.","m":f"{n} liegt in {k}."})
for l,a in out.items():
    for q in a: assert len(set(q['a']))==4,q
    json.dump(a,open(f'/home/claude/mk/gross/out/bf{l}_flaggen.json','w'),ensure_ascii=False,indent=0)
    print(l,len(a))
