import json,re,unicodedata
liste=json.load(open('/tmp/logoliste.json'))
icons=json.load(open('/home/claude/si/repo/data/simple-icons.json'))
def slugify(t):
    # simple-icons Regel
    rep={'+':'plus','.':'dot','&':'and','đ':'d','ħ':'h','ı':'i','ĸ':'k','ŀ':'l','ł':'l','ß':'ss','ŧ':'t'}
    t=''.join(rep.get(c,c) for c in t.lower())
    t=unicodedata.normalize('NFD',t); t=''.join(c for c in t if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9]','',t)
hexmap={}
for i in icons: hexmap[i.get('slug') or slugify(i['title'])]=i['hex']
WORT={2,19,20,22,23,24,25,26,29,30,31,32,33,34,36,42,44,47,51,52,54,56,58,59,65,66,69,70,80,81,82,83,84,86,88,90,92,93,94,95,97,101,104,110,120,126,130,133,136,138,140,145,146,149}
K={ # Kategorie: Antworttext
 'tech':'Elektronik, Computer und Handys','app':'Apps, soziale Netzwerke und Internetdienste','auto':'Autos','essen':'Essen und Getränke',
 'sport':'Sportschuhe und Sportkleidung','mode':'Kleider und Mode','shop':'Einkaufen in Läden und online','geld':'Bezahlen und Bankgeschäfte',
 'flug':'Flugreisen','reise':'Hotels und Reiseangebote','game':'Videospiele und Spielkonsolen','media':'Filme, Serien und Musik',
 'industrie':'Technik für Industrie und Energie','telekom':'Handy-Abos und Internetanschlüsse','tv':'Fernsehen und Radio','kaufhaus':'Ein Warenhaus mit Mode und Feinkost'}
KAT={}
def setz(kat, namen):
    for n in namen.split('|'): KAT[n]=kat
setz('tech','Apple|Samsung|Intel|AMD|NVIDIA|Dell|HP|Lenovo|Acer|ASUS|Huawei|Xiaomi|OPPO|Sony|LG|Panasonic|Nikon|DJI|Tesla')
setz('app','Google|Meta|Facebook|Instagram|WhatsApp|TikTok|X|Pinterest|Snapchat|Reddit|Discord|Telegram|Twitch|GitHub|Dropbox|Zoom|Notion|Figma|Uber|Airbnb|Shopify|Proton|Threema|Infomaniak')
setz('auto','Toyota|Volkswagen|BMW|Audi|Porsche|Ferrari|Lamborghini|Ford|Chevrolet|Honda|Hyundai|Kia|Nissan|Mazda|Volvo|Renault|Peugeot|Citroën|Fiat|Jeep|Subaru|Mitsubishi|Maserati|Bentley|Bugatti')
setz('essen',"Coca-Cola|Starbucks|McDonald's|Burger King|KFC|Taco Bell|Red Bull|Unilever")
setz('sport','Nike|Adidas|Puma|Reebok|Under Armour|New Balance|The North Face')
setz('mode','H&M|Zara|Uniqlo|Dior')
setz('shop','Target|eBay|Etsy|AliExpress|Alibaba.com|IKEA|Carrefour|Aldi Nord|Aldi Süd|Lidl|Tesco|Galaxus')
setz('geld','Visa|Mastercard|PayPal|Stripe|American Express|Revolut|Klarna|Coinbase|Binance|Wise|Western Union|HSBC|Barclays|Goldman Sachs|Robinhood|Thurgauer Kantonalbank')
setz('flug','Lufthansa|Emirates|Qatar Airways|Ryanair|easyJet|British Airways|Air France|Air Canada|Singapore Airlines|Turkish Airlines|Delta Air Lines|United Airlines|American Airlines')
setz('reise','Booking.com|Expedia|Tripadvisor|Marriott|Hilton')
setz('game','PlayStation|Steam|Epic Games|Electronic Arts|Ubisoft|Activision|Rockstar Games')
setz('media','YouTube|Netflix|Spotify|HBO|Paramount+|Apple TV|SoundCloud|Deezer|Shazam|Vimeo')
setz('industrie','ABB'); setz('telekom','Sunrise'); setz('tv','SRG SSR'); setz('kaufhaus','Globus')
STUFE1=set("Apple|Google|Facebook|Instagram|WhatsApp|YouTube|TikTok|Snapchat|Netflix|Spotify|McDonald's|Coca-Cola|Burger King|Nike|Adidas|Puma|IKEA|Lidl|PlayStation|Red Bull|KFC|Starbucks|Ferrari|Volkswagen|BMW|Audi|Mercedes-Benz|Samsung|H&M|Zara|Lamborghini|Porsche|Toyota|Visa|Aldi Süd|Galaxus|SRG SSR|Discord|Twitch|Pinterest".split('|'))
STUFE3=set("Stripe|Wise|Western Union|HSBC|Barclays|Goldman Sachs|Robinhood|Coinbase|Binance|Klarna|Revolut|Air Canada|Singapore Airlines|Turkish Airlines|Delta Air Lines|United Airlines|American Airlines|Qatar Airways|Emirates|British Airways|Air France|Marriott|Hilton|Expedia|Unilever|Bentley|Bugatti|Maserati|Mitsubishi|Subaru|Alibaba.com|Notion|Figma|GitHub|Dropbox|Infomaniak|Thurgauer Kantonalbank|Proton|Threema|ABB|Taco Bell|Carrefour|Tesco|Target|Etsy|Paramount+|HBO|Deezer|Vimeo|Activision|Ubisoft|Electronic Arts|Rockstar Games|Epic Games|Under Armour|Reebok|New Balance|Uniqlo|Dior|AMD|NVIDIA|Dell|Acer|ASUS|OPPO|Panasonic|Nikon|DJI|Stripe|Shopify|Uber|Airbnb|Tripadvisor|Booking.com".split('|'))
CH={'ABB','Globus','Sunrise','Galaxus','SRG SSR','Proton','Threema','Infomaniak','Thurgauer Kantonalbank'}
out=[]
for k,(n,s) in enumerate(liste):
    svg=open(f'/home/claude/si/repo/icons/{s}.svg').read()
    paths=re.findall(r'<path d="([^"]+)"',svg)
    assert len(paths)==1,(n,len(paths))
    assert n in KAT,n
    l = 1 if n in STUFE1 else 3 if n in STUFE3 else 2
    out.append({'n':n,'s':s,'h':hexmap.get(s,'222222'),'p':paths[0],'k':KAT[n],'w':1 if k in WORT else 0,'l':l,'ch':1 if n in CH else 0})
print(len(out), sum(o['w'] for o in out), sum(len(o['p']) for o in out)//1024,'KB')
json.dump({'logos':out,'kat':K},open('/home/claude/bau/logos.json','w'),ensure_ascii=False)
