/* Reels: Bibliothekstext als Fenster (Bottom Sheet) statt Wechsel in die Bibliothek */
function rlSheetInhalt(B, s){
  if(s.typ==="art") return `<div class="rsartikel">${s.art.html==="__PARTEIEN__" ? parteienHTML() : s.art.html}</div>`;
  const key=seiteKey(s);
  if(s.teile && !S.texte[key]){ const T=s.teile; S.teile[key]=T; S.texte[key]=[T.einleitung,...T.wichtigste,...T.abschnitte.map(a=>a.text),...T.gewusst].join(" ").replace(/\*\*/g,""); }
  const merk=[...new Set((s.fragen||[]).map(f=>f.m).filter(m=>m && !/ = |→|^[^:]{1,45}: /.test(m)))];
  const txt=textHTML(key);
  const karte=f=>`<div class="wk"><span class="bibst">${STUFE_EMO[f.l]||""} ${esc(stufeObj(f.l).name)}</span><p class="wkq">${esc(f.q)}</p><p class="wka">${esc(f.a[0])}</p><p class="wke">${esc(f.e)}</p></div>`;
  const eig=rlEigene(s), fakten=(eig.length?eig:(s.fragen||[])).slice(0,5);
  let extra=""; try{ extra=gipfelInfoHTML(s)+steckHTML(s)+olympiaHTML(s); }catch(e){}
  return `${extra}${!txt&&merk.length?`<div class="aufeinenblick"><b>🗝️ Auf einen Blick</b><ul>${merk.slice(0,5).map(m=>`<li>${esc(m)}</li>`).join("")}</ul></div>`:""}
    ${txt}
    ${fakten.length?`<h3 class="faktkopf">📚 Fakten</h3><div class="wkarten">${fakten.map(karte).join("")}</div>`:""}`;
}
function rlSheetOffen(){ return !!$("#rsheet"); }
function rlSheetZu(){
  const sh=$("#rsheet"), bg=$("#rsheetBg"); if(!sh) return;
  sh.animate([{transform:getComputedStyle(sh).transform==="none"?"translateY(0)":getComputedStyle(sh).transform},{transform:"translateY(100%)"}],{duration:220,easing:"ease-in"}).onfinish=()=>{ sh.remove(); };
  bg && bg.animate([{opacity:1},{opacity:0}],{duration:220}).onfinish=()=>bg.remove();
  stopSpeak();
}
function rlSheet(b, nr){
  const o=$("#reels"); if(!o) return; if(rlSheetOffen()) $("#rsheet").remove(), $("#rsheetBg")?.remove();
  const B=BUECHER.find(x=>x.id===b), s=B && buchDaten(b).seiten.find(x=>x.nr===nr); if(!s) return;
  let inhalt=""; try{ inhalt=rlSheetInhalt(B,s); }catch(e){ console.warn(e); inhalt=`<p class="empty">Dieser Artikel kann hier nicht angezeigt werden.</p>`; }
  o.insertAdjacentHTML("beforeend", `<div class="rsheet-bg" id="rsheetBg"></div>
    <div class="rsheet" id="rsheet" role="dialog" aria-modal="true" aria-label="${esc(s.titel)}" style="--bf:${B.farbe}">
      <div class="rsgriff" id="rsGriff"><i></i>
        <div class="rskopf"><span class="rsbuch">${B.emo} ${esc(B.titel)} · ${esc(s.kap.titel)}</span><button type="button" class="rszu" id="rsZu" aria-label="Schliessen">✕</button></div>
        <h2>${esc(s.titel)}</h2></div>
      <div class="rsinhalt" id="rsInhalt"><article class="libart rsart" style="--bf:${B.farbe}">
        <figure class="wbild ersatz rsbild">${ersatzBildHTML(s,B)}</figure>
        ${inhalt}
      </article></div>
      <div class="rsfuss">${"speechSynthesis" in window?`<button type="button" class="rsknopf alt" id="rsVor">🔊 Vorlesen</button>`:""}<button type="button" class="rsknopf" id="rsGanz">📖 Ganze Seite in der Bibliothek</button></div>
    </div>`);
  const sh=$("#rsheet"), bg=$("#rsheetBg");
  sh.animate([{transform:"translateY(100%)"},{transform:"translateY(0)"}],{duration:280,easing:"cubic-bezier(.2,.9,.3,1)"});
  bg.animate([{opacity:0},{opacity:1}],{duration:280});
  bg.onclick=rlSheetZu; $("#rsZu").onclick=rlSheetZu;
  $("#rsGanz").onclick=()=>{ $("#rsheet")?.remove(); $("#rsheetBg")?.remove(); rlZuArtikel(b, nr); };
  $("#rsVor") && ($("#rsVor").onclick=()=>{ try{ speakText(s.titel+". "+$("#rsInhalt").innerText.replace(/\s+/g," ").slice(0,6000)); }catch(e){} });
  // Nach unten ziehen zum Schliessen
  const g=$("#rsGriff"); let y0=null, dy=0;
  g.addEventListener("touchstart",e=>{ y0=e.touches[0].clientY; dy=0; sh.style.transition="none"; },{passive:true});
  g.addEventListener("touchmove",e=>{ if(y0==null) return; dy=Math.max(0,e.touches[0].clientY-y0); sh.style.transform=`translateY(${dy}px)`; },{passive:true});
  g.addEventListener("touchend",()=>{ if(y0==null) return; y0=null; sh.style.transition=""; if(dy>110) rlSheetZu(); else sh.style.transform=""; });
  if(!window.claude){
    const kand = s.typ==="art" ? [s.art.bild||null, s.titel] : [...[].concat(S.bilder[seiteKey(s)]||[]), s.wiki||null, s.titel];
    wikiBildMehrfach(kand, s.typ==="art"?s.titel+" Schweiz":s.titel+" "+s.kap.titel, s.kap?.id==="x_firmen").then(bi=>{
      const f=sh.querySelector(".rsbild"); if(!bi||!f||!sh.isConnected) return;
      const img=new Image(); img.alt=bi.alt||""; img.onload=()=>{ f.classList.remove("ersatz"); f.innerHTML=""; f.appendChild(img); const c=document.createElement("figcaption"); c.innerHTML=`Bild: ${bi.artist?esc(bi.artist):"Wikimedia Commons"}${bi.lizenz?`, ${esc(bi.lizenz)}`:""}`; f.appendChild(c); }; img.src=bi.src; }).catch(()=>{});
  }
  $("#rsZu").focus({preventScroll:true});
}
