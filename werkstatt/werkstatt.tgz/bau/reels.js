/* ================= Reels: Fragen und Bibliothek im Stil von Shorts und Reels ================= */
const RL = { offen:false, tab:"mix", n:0, seenQ:new Set(), seenA:new Set(), aPool:null, serie:0, likes:store.get("ep-likes",{}), obs:null, map:new Map() };
const RL_TABS = [["mix","Für dich"],["quiz","Quiz"],["wissen","Wissen"]];
function rlLogo(){ const i=document.getElementById("logoImg"); return i&&i.src ? `<img src="${i.src}" alt="">` : "🎓"; }
function rlFarbe(f){ const b=THEMA[f.t]?.bereich; const m={"--welt":["#3D5AFE","#1B1F6B"],"--natur":["#17A35A","#0B3D2A"],"--geld":["#E0312B","#5A0F1F"],"--alltag":["#F2A000","#6B3A00"]}; return m[b?.c]||["#8A3FE0","#2A1052"]; }
function rlArtPool(){
  if(RL.aPool) return RL.aPool;
  const p=[];
  try{ BUECHER.forEach(B=>buchDaten(B.id).seiten.forEach(s=>{ if(s.titel==="Allgemeines") return;
    if(s.typ==="art" || s.teile || S.texte[seiteKey(s)] || (s.fragen||[]).length>=3) p.push([B.id,s.nr]); })); }catch(e){ console.warn(e); }
  return RL.aPool=p;
}
function rlNaechsteFrage(){
  let alle=alleFragen().filter(f=>THEMA[f.t] && f.q && Array.isArray(f.a) && f.a.length===4);
  const st=alle.filter(f=>f.l===S.stufe); if(st.length>50) alle=st;
  for(let k=0;k<40;k++){ const f=alle[Math.floor(Math.random()*alle.length)]; if(f && !RL.seenQ.has(f.q)){ RL.seenQ.add(f.q); return {typ:"q", f}; } }
  RL.seenQ.clear(); const f=alle[Math.floor(Math.random()*alle.length)]; return f?{typ:"q", f}:null;
}
function rlNaechsterArtikel(){
  const p=rlArtPool(); if(!p.length) return null;
  for(let k=0;k<40;k++){ const w=p[Math.floor(Math.random()*p.length)], key=w.join("|"); if(!RL.seenA.has(key)){ RL.seenA.add(key); return {typ:"a", b:w[0], nr:w[1]}; } }
  RL.seenA.clear(); const w=p[Math.floor(Math.random()*p.length)]; return {typ:"a", b:w[0], nr:w[1]};
}
function rlNaechstes(){
  const t=RL.tab; let it=null;
  if(t==="quiz") it=rlNaechsteFrage();
  else if(t==="wissen") it=rlNaechsterArtikel();
  else it = (RL.n%3===2 && RL.n>0) ? (rlNaechsterArtikel()||rlNaechsteFrage()) : rlNaechsteFrage();
  RL.n++; return it;
}
function rlArtInfo(B,s){
  const key=seiteKey(s), T=s.teile||S.teile[key]||null, txt=S.texte[key]||"";
  const saetze=t=>String(t||"").replace(/\*\*/g,"").match(/[^.!?]+[.!?]+/g)||[];
  let intro = T?.einleitung || saetze(txt).slice(0,3).join(" ") || (s.typ==="art" ? saetze(String(s.art.html).replace(/<[^>]+>/g," ").replace(/\s+/g," ")).slice(0,3).join(" ") : "") || (s.fragen||[]).slice(0,2).map(f=>f.e).join(" ");
  intro=String(intro).replace(/\*\*/g,"").trim();
  const merk=[...new Set((s.fragen||[]).map(f=>f.m).filter(m=>m && !/ = |→|^[^:]{1,45}: /.test(m)))];
  const punkte=(T?.wichtigste?.length ? T.wichtigste : merk).slice(0,3).map(x=>String(x).replace(/\*\*/g,""));
  const gewusst=(T?.gewusst?.length ? T.gewusst[Math.floor(Math.random()*T.gewusst.length)] : (s.fragen||[]).length ? s.fragen[Math.floor(Math.random()*s.fragen.length)].e : "") || "";
  return {intro, punkte, gewusst:String(gewusst).replace(/\*\*/g,"")};
}
function rlRail(id, extra){
  const an=!!RL.likes[id];
  return `<aside class="rrail">
    <button type="button" class="rbtn rlike ${an?"an":""}" data-like="${esc(id)}" aria-pressed="${an}"><span class="rbi">${an?"❤️":"🤍"}</span><small>Gefällt mir</small></button>
    ${extra}
    <button type="button" class="rbtn" data-teilen><span class="rbi">↗️</span><small>Teilen</small></button>
    ${"speechSynthesis" in window?`<button type="button" class="rbtn" data-vorlesen><span class="rbi">🔊</span><small>Vorlesen</small></button>`:""}
  </aside>`;
}
function rlMeta(tag, text, ton){
  return `<div class="rmeta"><div class="rkanal"><span class="ravatar">${rlLogo()}</span><b>@easyplay</b><span class="rchip">${tag}</span></div>
    ${text}<p class="rton">🎵 ${ton}</p></div>`;
}
function rlFrageHTML(it, idx){
  const f=it.f, [c1,c2]=rlFarbe(f), th=THEMA[f.t], id="q"+frageNr(f);
  it.opts=shuffle(f.a.map((t,i)=>({t, ok:i===0})));
  it.say=f.q+". "+it.opts.map((o,i)=>"ABCD"[i]+": "+o.t).join(". ");
  it.share=`${f.q}\n${it.opts.map((o,i)=>"ABCD"[i]+") "+o.t).join("\n")}\nWeisst du es? Spiel mit auf easyplay!`;
  return `<section class="reel rq" data-i="${idx}" style="--r1:${c1};--r2:${c2}">
    <div class="rbg" aria-hidden="true"><span>${themaIcon(th)}</span><span>${themaIcon(th)}</span><span>${themaIcon(th)}</span></div>
    <div class="rinhalt">
      <span class="rtag">${themaIcon(th)} ${esc(th.name)} · ${STUFE_EMO[f.l]} ${esc(stufeObj(f.l).name)}</span>
      ${f.img?`<div class="rimg">${imgSvg(f.img)}</div>`:""}
      <h2 class="rfrage">${esc(f.q)}</h2>
      <div class="ropts">${it.opts.map((o,i)=>`<button type="button" class="ropt" data-o="${i}"><span class="rk">${"ABCD"[i]}</span><span>${esc(o.t)}</span></button>`).join("")}</div>
      <div class="rerkl" hidden></div>
    </div>
    ${rlRail(id, `<button type="button" class="rbtn" data-erkl><span class="rbi">💡</span><small>Erklärung</small></button><button type="button" class="rbtn" data-qart><span class="rbi">📖</span><small>Artikel</small></button>`)}
    ${rlMeta("Quiz", `<p class="rcap">Tippe auf die richtige Antwort! <span class="rnr">Nr. ${frageNr(f)}</span></p>`, `${esc(th.bereich.name)} · ${esc(th.name)}`)}
    <div class="rprog"><i></i></div>
  </section>`;
}
function rlArtikelHTML(it, idx){
  const B=BUECHER.find(x=>x.id===it.b), s=buchDaten(it.b).seiten.find(x=>x.nr===it.nr);
  if(!B||!s) return "";
  it.B=B; it.s=s; const I=rlArtInfo(B,s), id="a"+B.id+"-"+seiteKey(s);
  it.say=s.titel+". "+I.intro+" "+I.punkte.join(" ");
  it.share=`${s.titel}: ${I.intro}\nMehr dazu in der easyplay-Bibliothek!`;
  return `<section class="reel ra" data-i="${idx}" style="--r1:${B.farbe};--r2:${B.farbe2}">
    <div class="rbild">${ersatzBildHTML(s,B)}</div>
    <div class="rschatten" aria-hidden="true"></div>
    ${I.gewusst?`<div class="rsticker"><b>💡 Wusstest du?</b><p>${esc(I.gewusst)}</p></div>`:""}
    ${rlRail(id, `<button type="button" class="rbtn" data-lesen><span class="rbi">📖</span><small>Lesen</small></button>${(s.fragen||[]).length?`<button type="button" class="rbtn" data-dazu><span class="rbi">🎮</span><small>Frage dazu</small></button>`:""}`)}
    ${rlMeta(`${B.emo} Bibliothek`, `<h2 class="rtitel">${esc(s.titel)}</h2>
      <div class="rtext"><p>${esc(I.intro)}</p>${I.punkte.length?`<ul>${I.punkte.map(p=>`<li>${esc(p)}</li>`).join("")}</ul>`:""}</div>
      <button type="button" class="rmehr" data-mehr>mehr</button>`, `${esc(B.titel)} · ${esc(s.kap.titel)}`)}
    <div class="rprog"><i></i></div>
  </section>`;
}
function rlHinzu(n){
  const feed=$("#rfeed"); if(!feed) return;
  for(let k=0;k<n;k++){
    const it=rlNaechstes(); if(!it) break; const idx=RL.map.size;
    let html=""; try{ html = it.typ==="q" ? rlFrageHTML(it, idx) : rlArtikelHTML(it, idx); }catch(e){ console.warn(e); }
    if(!html) continue;
    RL.map.set(idx, it); feed.insertAdjacentHTML("beforeend", html);
    const sec=feed.lastElementChild; rlBinde(sec, it); RL.obs && RL.obs.observe(sec);
  }
}
function rlToast(t){ const o=$("#reels"); if(!o) return; const d=document.createElement("div"); d.className="rtoast"; d.textContent=t; o.appendChild(d); setTimeout(()=>d.remove(),1900); }
function rlHerz(sec, x, y){ const h=document.createElement("span"); h.className="rherz"; h.textContent="❤️"; const r=sec.getBoundingClientRect(); h.style.left=(x-r.left)+"px"; h.style.top=(y-r.top)+"px"; sec.appendChild(h); setTimeout(()=>h.remove(),900); }
function rlLike(sec, an){
  const b=sec.querySelector("[data-like]"); if(!b) return; const id=b.dataset.like;
  const neu = an==null ? !RL.likes[id] : an; if(neu) RL.likes[id]=1; else delete RL.likes[id]; store.set("ep-likes", RL.likes);
  b.classList.toggle("an", neu); b.setAttribute("aria-pressed", neu); b.querySelector(".rbi").textContent = neu?"❤️":"🤍";
  if(neu) b.querySelector(".rbi").animate([{transform:"scale(1)"},{transform:"scale(1.45)"},{transform:"scale(1)"}],{duration:380});
}
function rlZuArtikel(b, nr){
  schliesseReels(); LIB.buch=b; LIB.seite=nr; LIB.zufall=false; LIB.vonQuiz=false;
  S.libModus=true; document.documentElement.dataset.mode="lib"; go("libseite"); scrollTo(0,0);
}
function rlAntwort(sec, it, i){
  if(it.done) return; it.done=true; const ok=it.opts[i].ok, f=it.f;
  sec.querySelectorAll(".ropt").forEach((b,k)=>{ b.disabled=true; if(it.opts[k].ok) b.classList.add("richtig"); else if(k===i) b.classList.add("falsch"); });
  RL.serie = ok ? RL.serie+1 : 0; rlSerie();
  const e=sec.querySelector(".rerkl");
  e.innerHTML=`<p class="rres ${ok?"ok":"no"}">${ok?(RL.serie>=3?`🔥 ${RL.serie} richtig in Folge!`:"✅ Richtig!"):"❌ Nicht ganz."}</p><p>${esc(f.e)}</p>${f.m?`<p class="rmerk">🗝️ ${esc(f.m)}</p>`:""}<p class="rweiter">Wische nach oben für mehr <span>⌃</span></p>`;
  e.hidden=false; e.animate([{opacity:0,transform:"translateY(12px)"},{opacity:1,transform:"none"}],{duration:300});
  if(ok) rlHerz(sec, sec.getBoundingClientRect().left+sec.clientWidth/2, sec.getBoundingClientRect().top+sec.clientHeight*.42);
}
function rlSerie(){ const s=$("#rserie"); if(!s) return; s.hidden=RL.serie<2; s.textContent=`🔥 ${RL.serie}`; }
function rlBinde(sec, it){
  let tapT=0;
  sec.addEventListener("click", e=>{
    if(e.target.closest("button")) return;
    const t=Date.now(); if(t-tapT<320){ rlLike(sec,true); rlHerz(sec,e.clientX,e.clientY); tapT=0; } else tapT=t;
  });
  sec.querySelectorAll(".ropt").forEach(b=>b.onclick=()=>rlAntwort(sec,it,+b.dataset.o));
  sec.querySelector("[data-like]").onclick=()=>rlLike(sec);
  const v=sec.querySelector("[data-vorlesen]"); v && (v.onclick=()=>{ try{ speakText(it.say); }catch(e){} });
  sec.querySelector("[data-teilen]").onclick=async()=>{
    try{ if(navigator.share){ await navigator.share({title:"easyplay", text:it.share}); return; } }catch(e){ return; }
    try{ await navigator.clipboard.writeText(it.share); rlToast("📋 Kopiert, jetzt kannst du es einfügen"); }catch(e){ rlToast("Teilen ist hier nicht möglich"); }
  };
  const er=sec.querySelector("[data-erkl]"); er && (er.onclick=()=>{ const e=sec.querySelector(".rerkl"); if(!it.done){ e.innerHTML=`<p>${esc(it.f.e)}</p>${it.f.m?`<p class="rmerk">🗝️ ${esc(it.f.m)}</p>`:""}`; } e.hidden=!e.hidden; });
  const qa=sec.querySelector("[data-qart]"); qa && (qa.onclick=()=>{ let z=null; try{ z=qbZiel(it.f); }catch(e){} if(z) rlZuArtikel(z.b, z.nr); else rlToast("Zu dieser Frage gibt es noch keinen Artikel"); });
  const le=sec.querySelector("[data-lesen]"); le && (le.onclick=()=>rlZuArtikel(it.b, it.nr));
  const me=sec.querySelector("[data-mehr]"); me && (me.onclick=()=>{ const m=sec.querySelector(".rmeta"); m.classList.toggle("offen"); me.textContent=m.classList.contains("offen")?"weniger":"mehr"; });
  const dz=sec.querySelector("[data-dazu]"); dz && (dz.onclick=()=>{
    const fr=it.s.fragen.filter(f=>f.a?.length===4); if(!fr.length) return; const f=fr[Math.floor(Math.random()*fr.length)];
    const neu={typ:"q", f}, idx=RL.map.size; RL.map.set(idx, neu);
    sec.insertAdjacentHTML("afterend", rlFrageHTML(neu, idx)); const ns=sec.nextElementSibling; rlBinde(ns, neu); RL.obs&&RL.obs.observe(ns);
    ns.scrollIntoView({behavior:"smooth"});
  });
  if(it.typ==="a" && !window.claude){
    const s=it.s, kand = s.typ==="art" ? [s.art.bild||null, s.titel] : [...[].concat(S.bilder[seiteKey(s)]||[]), s.wiki||null, s.titel];
    const laden=()=>wikiBildMehrfach(kand, s.typ==="art"?s.titel+" Schweiz":s.titel+" "+s.kap.titel, s.kap?.id==="x_firmen").then(b=>{
      if(!b || !sec.isConnected) return; const box=sec.querySelector(".rbild"); const img=new Image(); img.alt=b.alt||""; img.onload=()=>{ box.innerHTML=""; box.appendChild(img); box.classList.add("foto"); img.animate([{opacity:0},{opacity:1}],{duration:400}); }; img.src=b.src; }).catch(()=>{});
    it.laden=laden;
  }
}
function rlAktiv(){ const f=$("#rfeed"); if(!f) return null; const h=f.clientHeight; return [...f.children].find(s=>Math.abs(s.offsetTop-f.scrollTop)<h/2)||null; }
function rlGehe(d){ const f=$("#rfeed"); if(!f) return; f.scrollBy({top:d*f.clientHeight, behavior:"smooth"}); }
function rlTab(t){
  RL.tab=t; RL.n=0; RL.map.clear(); RL.serie=0; rlSerie(); stopSpeak();
  document.querySelectorAll("#reels [data-rtab]").forEach(b=>b.setAttribute("aria-selected", b.dataset.rtab===t));
  const f=$("#rfeed"); f.innerHTML=""; f.scrollTop=0; rlHinzu(5);
}
function rlTaste(e){
  if(!RL.offen || e.ctrlKey||e.metaKey||e.altKey) return;
  const t=e.target; if(t&&(/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
  const k=e.key;
  if(k==="Escape"){ e.preventDefault(); schliesseReels(); return; }
  if(k==="ArrowDown"||k==="PageDown"||k==="j"){ e.preventDefault(); rlGehe(1); return; }
  if(k==="ArrowUp"||k==="PageUp"||k==="k"){ e.preventDefault(); rlGehe(-1); return; }
  const sec=rlAktiv(); if(!sec) return; const it=RL.map.get(+sec.dataset.i);
  const i="abcd".indexOf(k.toLowerCase());
  if(i>=0 && it?.typ==="q" && !e.shiftKey){ e.preventDefault(); rlAntwort(sec,it,i); return; }
  if(k.toLowerCase()==="l"){ e.preventDefault(); rlLike(sec); }
}
function oeffneReels(tab){
  if(RL.offen) return; RL.offen=true; stopSpeak();
  document.body.classList.add("reelsauf");
  const o=document.createElement("div"); o.id="reels"; o.setAttribute("role","dialog"); o.setAttribute("aria-modal","true"); o.setAttribute("aria-label","easyplay Reels");
  o.innerHTML=`<div class="rkopf">
      <span class="rmarke"><span class="rplay">▶</span> Reels</span>
      <div class="rtabs" role="tablist">${RL_TABS.map(([id,n])=>`<button type="button" role="tab" data-rtab="${id}" aria-selected="${id===(tab||RL.tab)}">${n}</button>`).join("")}</div>
      <span class="rserie" id="rserie" hidden></span>
      <button type="button" class="rzu" id="rZu" title="Zurück zur Website">🌐 <span>Website</span></button>
    </div>
    <div class="rfeed" id="rfeed"></div>
    <div class="rpfeile"><button type="button" id="rHoch" aria-label="Vorheriges Reel">⌃</button><button type="button" id="rRunter" aria-label="Nächstes Reel">⌄</button></div>`;
  document.body.appendChild(o);
  RL.obs=new IntersectionObserver(es=>es.forEach(en=>{
    const sec=en.target; if(en.isIntersecting && en.intersectionRatio>.6){
      document.querySelectorAll("#rfeed .reel.aktiv").forEach(x=>x!==sec&&x.classList.remove("aktiv")); sec.classList.add("aktiv"); stopSpeak();
      const i=+sec.dataset.i, it=RL.map.get(i); if(it?.laden){ it.laden(); it.laden=null; }
      const nx=sec.nextElementSibling; const itn=nx&&RL.map.get(+nx.dataset.i); if(itn?.laden){ itn.laden(); itn.laden=null; }
      if(!sec.nextElementSibling || !sec.nextElementSibling.nextElementSibling || !sec.nextElementSibling.nextElementSibling.nextElementSibling) rlHinzu(4);
    }
  }),{root:o.querySelector("#rfeed"), threshold:[.6]});
  o.querySelectorAll("[data-rtab]").forEach(b=>b.onclick=()=>rlTab(b.dataset.rtab));
  $("#rZu").onclick=schliesseReels;
  $("#rHoch").onclick=()=>rlGehe(-1); $("#rRunter").onclick=()=>rlGehe(1);
  document.addEventListener("keydown", rlTaste);
  rlTab(tab||RL.tab);
  o.animate([{opacity:0,transform:"scale(.98)"},{opacity:1,transform:"none"}],{duration:220});
  setTimeout(()=>{ try{ rlArtPool(); }catch(e){} },400);
}
function schliesseReels(){
  if(!RL.offen) return; RL.offen=false; stopSpeak();
  document.removeEventListener("keydown", rlTaste); RL.obs&&RL.obs.disconnect(); RL.obs=null;
  $("#reels")?.remove(); document.body.classList.remove("reelsauf");
}
