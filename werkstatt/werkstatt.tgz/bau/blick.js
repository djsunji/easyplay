/* Auf einen Blick: doppelte Aussagen entfernen (auch gegen «Das Wichtigste» und die Einleitung) */
const BLICK_STOP=new Set("der die das den dem des ein eine einer eines einem einen und oder aber auch als wie mit von vom zum zur zu im in ins am an auf aus bei bis für gegen nach ohne über unter vor durch um ist sind war waren wird werden wurde wurden hat haben hatte hatten kann können konnte muss müssen darf soll sollte man sich sie er es wir ihr ich du sein seine seiner seinen seinem ihre ihren ihrem ihrer nicht noch nur schon sehr mehr viel viele vielen etwa rund heute dass weil wenn dann denn doch so auch diese dieser dieses diesen diesem jede jeder jedes jeden alle allen allem welche welcher welches was wer wo wie gibt geben gilt heisst nennt nennen genannt besonders oft immer meist meisten".split(" "));
function blickWorte(t){ return new Set(String(t).toLowerCase().replace(/\*\*/g,"").replace(/[^a-zäöüéèàç0-9]+/g," ").split(" ").filter(w=>w.length>2&&!BLICK_STOP.has(w)).map(w=>/^\d+$/.test(w)?w:w.slice(0,6))); }
function blickAehnlich(a,b){ if(a.size<2||b.size<2) return 0; let n=0; for(const w of a) if(b.has(w)) n++; return n/Math.min(a.size,b.size); }
function blickListe(merk,key){
  const T=key&&S.teile[key]; const vergleich=[];
  if(T){ if(T.einleitung) satzListe(T.einleitung).forEach(x=>vergleich.push(blickWorte(x))); (T.wichtigste||[]).forEach(w=>vergleich.push(blickWorte(w))); }
  const behalten=[], bw=[];
  for(const m of merk){ const w=blickWorte(m);
    if(bw.some(x=>blickAehnlich(w,x)>=0.5)) continue;
    if(vergleich.some(x=>blickAehnlich(w,x)>=0.6)) continue;
    behalten.push(m); bw.push(w); if(behalten.length>=5) break; }
  return behalten;
}
