# Neue Fragen einbauen: GitHub (fragen-N.json, fragen-N.csv) und claude.ai (daten-gNN.js als Zusatzdatei)
import json,csv,sys,os,re,glob
O='/mnt/user-data/outputs/'; E=O+'easyplay/'
slugs=sys.argv[1].split(','); quelle=sys.argv[2] if len(sys.argv)>2 else '/home/claude/mk/gross/out'
neu=[]
for s in slugs:
    assert os.path.exists(f'{quelle}/{s}.rev'), 'nicht geprueft: '+s
    neu+=json.load(open(f'{quelle}/{s}.json',encoding='utf-8'))
neu=[{k:f[k] for k in ["t","l","s","q","a","e","m"]+(["img"] if f.get("img") else [])} for f in neu]
bad=[f for f in neu if re.search('[ß–—]',json.dumps({k:v for k,v in f.items() if k!='img'},ensure_ascii=False))]
assert not bad, bad[:2]
teile=sorted(glob.glob(E+'fragen-*.json'),key=lambda p:int(re.search(r'fragen-(\d+)',p).group(1)))
alle=[]
for p in teile: alle+=json.load(open(p,encoding='utf-8'))
key=lambda f:(f['q'].strip().lower()+'|'+f.get('img','')) if f.get('img') else f['q'].strip().lower()
alt={key(f) for f in alle}
n2=[];seen=set()
for f in neu:
    k=key(f)
    if k in alt or k in seen: continue
    seen.add(k); n2.append(f)
start=max(f['nr'] for f in alle)+1
n2=[{"nr":start+i,**f} for i,f in enumerate(n2)]
# an letzte Datei anhängen bis 3.2 MB, dann neue Datei
def schreib(p,arr): open(p,'w',encoding='utf-8').write("[\n"+",\n".join(json.dumps(x,ensure_ascii=False) for x in arr)+"\n]\n")
letzte=teile[-1]; nr=int(re.search(r'fragen-(\d+)',letzte).group(1))
cur=json.load(open(letzte,encoding='utf-8')); rest=list(n2)
LIM=3_200_000
while rest:
    groesse=len(json.dumps(cur,ensure_ascii=False).encode())
    while rest and groesse<LIM:
        x=rest.pop(0); cur.append(x); groesse+=len(json.dumps(x,ensure_ascii=False).encode())+2
    schreib(E+f'fragen-{nr}.json',cur)
    if rest: nr+=1; cur=[]
anz=nr
# CSV: eigene Dateien fragen-csv mit gleicher Nummer wie neue Einträge (einfach anhängen an letzte csv bis 3.2 MB)
csvs=sorted(glob.glob(E+'fragen-*.csv'),key=lambda p:int(re.search(r'fragen-(\d+)',p).group(1)))
cn=int(re.search(r'fragen-(\d+)',csvs[-1]).group(1)); cp=csvs[-1]
for f in n2:
    if os.path.getsize(cp)>3_200_000:
        cn+=1; cp=E+f'fragen-{cn}.csv'
        with open(cp,'w',encoding='utf-8',newline='') as fh: csv.writer(fh).writerow(["thema","stufe","frage","antworten","erklaerung","merksatz","quelle","bild","status"])
    with open(cp,'a',encoding='utf-8',newline='') as fh:
        csv.writer(fh).writerow([f['t'],f['l'],f['q'],json.dumps(f['a'],ensure_ascii=False),f['e'],f['m'],f['s'],f.get('img',''),'ok'])
# config.js Liste
c=open(E+'config.js',encoding='utf-8').read()
liste=', '.join(f'"fragen-{i}.json"' for i in range(1,anz+1))
c=re.sub(r'fragenDateien: \[[^\]]*\]',f'fragenDateien: [{liste}]',c); open(E+'config.js','w',encoding='utf-8').write(c)
# claude.ai: daten-gNN.js
gs=sorted(glob.glob(O+'daten-g*.js')); gn=len(gs)+1
gp=O+f'daten-g{gn:02d}.js'
open(gp,'w',encoding='utf-8').write('/* easyplay: neue Fragen */\n(window.EP_NEU=window.EP_NEU||[]).push(\n'+",\n".join(json.dumps(x,ensure_ascii=False) for x in n2)+'\n);\n')
h=open(O+'lernspiel.html',encoding='utf-8').read()
tag=f'<script src="daten-g{gn:02d}.js"></script>'
if 'EP_NEU' not in h:
    a='/* ENDE-NEUE-FRAGEN */'; j=h.rfind(a); assert j>0
    h=h[:j]+'if(window.EP_NEU) FRAGEN.push(...window.EP_NEU);\n'+h[j:]
i=h.find('<script>'); h=h[:i]+tag+'\n'+h[i:]
open(O+'lernspiel.html','w',encoding='utf-8').write(h)
print(f'neu {len(n2)} von {len(neu)}, Nr {start} bis {start+len(n2)-1}, fragen-Dateien {anz}, {os.path.basename(gp)} {os.path.getsize(gp)//1000} KB')
