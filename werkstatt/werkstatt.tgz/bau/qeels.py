import sys
JS_NEU = r'''
/* ---------- Qeels: Likes zählen (gemeinsam über Datenbank) ---------- */
const LK={cache:{}, warte:{}};
function lkSupa(){ const c=window.EP_CONFIG||{}; return (!window.claude && c.supabaseUrl && c.supabaseKey) ? {u:c.supabaseUrl.replace(/\/$/,""), h:{apikey:c.supabaseKey, Authorization:`Bearer ${c.supabaseKey}`, "Content-Type":"application/json"}} : null; }
async function likeZahl(id){
  if(id in LK.cache) return LK.cache[id];
  if(LK.warte[id]) return LK.warte[id];
  return LK.warte[id]=(async()=>{ try{
    if(S.db){ const d=await S.db.doc("likes/"+id).get(); return LK.cache[id]=(d.exists ? Math.max(0,+(d.data().n)||0) : 0); }
    const sp=lkSupa(); if(sp){ const r=await fetch(`${sp.u}/rest/v1/likes?id=eq.${encodeURIComponent(id)}&select=n`,{headers:sp.h}); if(r.ok){ const j=await r.json(); return LK.cache[id]=(j[0]?.n||0); } }
  }catch(e){} return null; })();
}
async function likeAendern(id, d){
  try{
    if(S.db){ const ref=S.db.doc("likes/"+id); const s=await ref.get(); const n=Math.max(0,(s.exists?(+(s.data().n)||0):0)+d); await ref.set({n, geaendert:new Date().toISOString()}); LK.cache[id]=n; return n; }
    const sp=lkSupa(); if(sp){ const r=await fetch(`${sp.u}/rest/v1/rpc/like_aendern`,{method:"POST",headers:sp.h,body:JSON.stringify({p_id:id,p_delta:d})}); if(r.ok){ const n=await r.json(); LK.cache[id]=+n||0; return LK.cache[id]; } }
  }catch(e){}
  if(typeof LK.cache[id]==="number"){ LK.cache[id]=Math.max(0,LK.cache[id]+d); return LK.cache[id]; }
  return null;
}
function zahlKurz(n){ return n>=1e6 ? (n/1e6).toFixed(1).replace(".0","")+" Mio." : n>=1e4 ? Math.round(n/1e3)+"k" : n>=1000 ? (n/1e3).toFixed(1).replace(".0","")+"k" : String(n); }
function rlLikeAnzeigen(sec, n){ const sm=sec.querySelector("[data-like] small"); if(!sm) return; sm.textContent = (n==null) ? "Gefällt mir" : zahlKurz(n); }
async function rlLikeLaden(sec){ const b=sec.querySelector("[data-like]"); if(!b||b.dataset.geladen) return; b.dataset.geladen="1"; const n=await likeZahl(b.dataset.like); rlLikeAnzeigen(sec, n); }

/* ---------- Qeels: Teilen über WhatsApp, Telegram usw. oder als Link ---------- */
function qeelBasis(){ const c=window.EP_CONFIG||{}; if(c.teilenUrl) return c.teilenUrl; if(window.claude || !/^https?:/.test(location.protocol)) return "https://djsunji.github.io/easyplay/"; return location.origin+location.pathname; }
function qeelLink(it){
  if(it.typ==="q") return qeelBasis()+"#qeel=q"+frageNr(it.f);
  const s=it.s||buchDaten(it.b).seiten.find(x=>x.nr===it.nr); return qeelBasis()+"#qeel=a"+encodeURIComponent(it.b)+"~"+(s?seiteKey(s):"");
}
function rlTeilenZu(){ $("#rteilen")?.remove(); $("#rteilenBg")?.remove(); }
function rlTeilen(it){
  const o=$("#reels"); if(!o) return; rlTeilenZu();
  const link=qeelLink(it), text=it.share, voll=text+"\n"+link, e=encodeURIComponent;
  const ziele=[
    ["WhatsApp","🟢",`https://wa.me/?text=${e(voll)}`],
    ["Telegram","✈️",`https://t.me/share/url?url=${e(link)}&text=${e(text)}`],
    ["Facebook","📘",`https://www.facebook.com/sharer/sharer.php?u=${e(link)}`],
    ["X","✖️",`https://twitter.com/intent/tweet?text=${e(text.split("\n")[0])}&url=${e(link)}`],
    ["E-Mail","✉️",`mailto:?subject=${e("easyplay Qeel")}&body=${e(voll)}`],
    ["SMS","💬",`sms:?&body=${e(voll)}`]
  ];
  o.insertAdjacentHTML("beforeend",`<div class="rsheet-bg" id="rteilenBg"></div>
    <div class="rteilen" id="rteilen" role="dialog" aria-modal="true" aria-label="Teilen">
      <div class="rtkopf"><b>Teilen</b><button type="button" class="rszu" id="rtZu" aria-label="Schliessen">✕</button></div>
      <div class="rtziele">${ziele.map(([n,i,u])=>`<a class="rtziel" href="${esc(u)}" target="_blank" rel="noopener"><span class="rti">${i}</span><small>${n}</small></a>`).join("")}
        ${navigator.share?`<button type="button" class="rtziel" id="rtMehr"><span class="rti">⋯</span><small>Mehr</small></button>`:""}</div>
      <div class="rtlink"><input type="text" readonly value="${esc(link)}" id="rtLinkFeld" aria-label="Link"><button type="button" id="rtKopier">🔗 Link kopieren</button></div>
    </div>`);
  const sh=$("#rteilen"); sh.animate([{transform:"translateY(100%)"},{transform:"none"}],{duration:240,easing:"cubic-bezier(.2,.9,.3,1)"});
  $("#rteilenBg").onclick=rlTeilenZu; $("#rtZu").onclick=rlTeilenZu;
  sh.querySelectorAll("a.rtziel").forEach(a=>a.addEventListener("click",()=>setTimeout(rlTeilenZu,200)));
  $("#rtMehr") && ($("#rtMehr").onclick=async()=>{ try{ await navigator.share({title:"easyplay", text, url:link}); rlTeilenZu(); }catch(e){} });
  $("#rtKopier").onclick=async()=>{ const f=$("#rtLinkFeld"); try{ await navigator.clipboard.writeText(link); }catch(e){ try{ f.select(); document.execCommand("copy"); }catch(_){} } $("#rtKopier").textContent="✅ Kopiert"; rlToast("🔗 Link kopiert"); };
}

/* ---------- Qeels: geteilten Link öffnen (#qeel=...) ---------- */
function qeelStartAusLink(h){
  const m=/#qeel=([^&]+)/.exec(h||""); if(!m) return null; const v=decodeURIComponent(m[1]);
  if(v[0]==="q"){ const nr=+v.slice(1); const f=alleFragen().find(x=>frageNr(x)===nr); return f?{typ:"q", f}:null; }
  if(v[0]==="a"){ const [b,k]=v.slice(1).split("~"); try{ const s=buchDaten(b).seiten.find(x=>x.typ!=="art"&&seiteKey(x)===k); return s?{typ:"a", b, nr:s.nr}:null; }catch(e){ return null; } }
  return null;
}
function oeffneQeelLink(versuch){
  const st=qeelStartAusLink(location.hash); if(!st){ if(/#qeel=/.test(location.hash) && (versuch||0)<4) setTimeout(()=>oeffneQeelLink((versuch||0)+1),1500); return; }
  RL.start=st;
  if(RL.offen){ rlTab(RL.tab); } else { const alt=$("#reels"); if(alt){ alt.remove(); RL.map.clear(); } oeffneReels("mix"); }
  try{ history.replaceState(null,"",location.pathname+location.search); }catch(e){}
}
addEventListener("hashchange",()=>{ if(/#qeel=/.test(location.hash)) oeffneQeelLink(); });
setTimeout(()=>{ if(/#qeel=/.test(location.hash)) oeffneQeelLink(); }, 1200);
'''

CSS_NEU = r'''
/* Qeels: Zurück-Knopf, Wusstest-du im Textblock, mehr direkt unter dem Text, Teilen-Fenster */
#reels .rzu span{display:inline!important}
#reels .rplay{font-weight:900;font-size:.85rem;font-family:"Bricolage Grotesque",system-ui,sans-serif}
#reels .rmeta .rsticker{position:static;left:auto;right:auto;top:auto;transform:rotate(-1.5deg);margin:0 0 12px;max-width:94%;max-height:30vh;overflow:auto}
#reels .rmeta.offen .rsticker{display:none}
#reels .rmehr{display:inline-block;width:auto;margin:2px 0 0;text-align:left;font-size:.9rem;opacity:.95;text-decoration:underline;text-underline-offset:3px}
#reels .rtext{margin-bottom:0}
#reels .rteilen{position:absolute;z-index:12;left:50%;bottom:0;transform:none;translate:-50% 0;width:min(100vw,480px);background:#fff;color:#1B2240;border-radius:22px 22px 0 0;padding:14px 16px calc(18px + env(safe-area-inset-bottom));box-shadow:0 -10px 40px rgba(0,0,0,.4)}
#reels .rtkopf{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
#reels .rtkopf b{font-size:1.1rem}
#reels .rtziele{display:grid;grid-template-columns:repeat(4,1fr);gap:10px 6px;margin-bottom:14px}
#reels .rtziel{display:flex;flex-direction:column;align-items:center;gap:5px;text-decoration:none;color:#1B2240;background:none;border:0;cursor:pointer;font:inherit}
#reels .rtziel .rti{width:52px;height:52px;border-radius:50%;display:grid;place-items:center;font-size:1.5rem;background:#F1F2F8;font-family:"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif}
#reels .rtziel small{font-size:.75rem;font-weight:700}
#reels .rtlink{display:flex;gap:8px}
#reels .rtlink input{flex:1;min-width:0;border:2px solid #E3E5EF;border-radius:12px;padding:9px 10px;font-size:.85rem;color:#1B2240;background:#F8F9FC}
#reels .rtlink button{border:0;border-radius:12px;padding:9px 12px;font-weight:800;background:linear-gradient(45deg,#FA7E1E,#D62976 50%,#962FBF);color:#fff;cursor:pointer;white-space:nowrap}
#reels .rteilen .rszu{background:#F1F2F8;color:#1B2240}
'''

def patch(fn):
    h=open(fn,encoding='utf-8').read()
    R=[
     # Namen
     ('title="Zu den Reels wechseln"><span class="rnico">▶</span> <span class="tlab">Reels</span>','title="Zu den Qeels wechseln"><span class="rnico">Q</span> <span class="tlab">Qeels</span>'),
     ('data-m="reels">▶️ Reels</button>','data-m="reels">🅠 Qeels</button>'),
     ('o.setAttribute("aria-label","easyplay Reels");','o.setAttribute("aria-label","easyplay Qeels");'),
     ('<span class="rmarke"><span class="rplay">▶</span> Reels</span>','<span class="rmarke"><span class="rplay">Q</span> Qeels</span>'),
     ('aria-label="Vorheriges Reel"','aria-label="Vorheriges Qeel"'),
     ('aria-label="Nächstes Reel"','aria-label="Nächstes Qeel"'),
     # Zurück
     ('<button type="button" class="rzu" id="rZu" title="Zurück zur Website">🌐 <span>Website</span></button>','<button type="button" class="rzu" id="rZu" title="Zurück">← <span>Zurück</span></button>'),
     # Wusstest du in den Textblock
     ('    ${I.gewusst?`<div class="rsticker"><b>💡 Wusstest du?</b><p>${esc(I.gewusst)}</p></div>`:""}\n    ${rlRail(id, `<button type="button" class="rbtn" data-lesen>','    ${rlRail(id, `<button type="button" class="rbtn" data-lesen>'),
     ('      <button type="button" class="rmehr" data-mehr>mehr</button>`, `${esc(B.titel)} · ${esc(s.kap.titel)}`)}','      <button type="button" class="rmehr" data-mehr>… mehr</button>`, `${esc(B.titel)} · ${esc(s.kap.titel)}`, I.gewusst?`<div class="rsticker"><b>💡 Wusstest du schon?</b><p>${esc(I.gewusst)}</p></div>`:"")}'),
     ('function rlMeta(tag, text, ton){\n  return `<div class="rmeta"><div class="rkanal">','function rlMeta(tag, text, ton, oben){\n  return `<div class="rmeta">${oben||""}<div class="rkanal">'),
     ('me.textContent=m.classList.contains("offen")?"weniger":"mehr"; });','me.textContent=m.classList.contains("offen")?"weniger":"… mehr"; });'),
     # Teilen
     ('''  sec.querySelector("[data-teilen]").onclick=async()=>{
    try{ if(navigator.share){ await navigator.share({title:"easyplay", text:it.share}); return; } }catch(e){ return; }
    try{ await navigator.clipboard.writeText(it.share); rlToast("📋 Kopiert, jetzt kannst du es einfügen"); }catch(e){ rlToast("Teilen ist hier nicht möglich"); }
  };''','''  sec.querySelector("[data-teilen]").onclick=()=>rlTeilen(it);'''),
     # Likes zählen
     ('''  const neu = an==null ? !RL.likes[id] : an; if(neu) RL.likes[id]=1; else delete RL.likes[id]; store.set("ep-likes", RL.likes);''','''  const war=!!RL.likes[id]; const neu = an==null ? !RL.likes[id] : an; if(neu) RL.likes[id]=1; else delete RL.likes[id]; store.set("ep-likes", RL.likes);
  if(neu!==war){ const vorher=LK.cache[id]; if(typeof vorher==="number") rlLikeAnzeigen(sec, Math.max(0,vorher+(neu?1:-1))); likeAendern(id, neu?1:-1).then(n=>{ if(n!=null) rlLikeAnzeigen(sec,n); }); }'''),
     ('      document.querySelectorAll("#rfeed .reel.aktiv").forEach(x=>x!==sec&&x.classList.remove("aktiv")); sec.classList.add("aktiv"); stopSpeak();','      document.querySelectorAll("#rfeed .reel.aktiv").forEach(x=>x!==sec&&x.classList.remove("aktiv")); sec.classList.add("aktiv"); stopSpeak(); rlLikeLaden(sec); const nx2=sec.nextElementSibling; nx2&&rlLikeLaden(nx2);'),
     # Startelement aus Link
     ('function rlNaechstes(){\n  const t=RL.tab; let it=null;','function rlNaechstes(){\n  if(RL.start){ const s=RL.start; RL.start=null; RL.n++; return s; }\n  const t=RL.tab; let it=null;'),
     # Esc schliesst Teilen
     ('  if(rlSheetOffen()){ if(k==="Escape"){ e.preventDefault(); rlSheetZu(); } return; }','  if($("#rteilen")){ if(k==="Escape"){ e.preventDefault(); rlTeilenZu(); } return; }\n  if(rlSheetOffen()){ if(k==="Escape"){ e.preventDefault(); rlSheetZu(); } return; }'),
     ('  $("#rsheet")?.remove(); $("#rsheetBg")?.remove();\n  document.removeEventListener("keydown", rlTaste);','  $("#rsheet")?.remove(); $("#rsheetBg")?.remove(); rlTeilenZu();\n  document.removeEventListener("keydown", rlTaste);'),
    ]
    for a,b in R:
        c=h.count(a); assert c==1,(fn,c,a[:80]); h=h.replace(a,b)
    # JS am Ende des Reels-Moduls einsetzen (vor Tastatur im Quiz)
    m='/* ---------- Tastatur im Quiz: A bis D antworten, Pfeile vor und zurück ---------- */'
    assert h.count(m)==1; h=h.replace(m, JS_NEU+'\n'+m)
    c='.navbtn.reelsnav{background:linear-gradient(45deg,#FA7E1E,#D62976 50%,#962FBF);color:#fff;border-color:transparent}'
    assert h.count(c)==1; h=h.replace(c,c+CSS_NEU)
    open(fn,'w',encoding='utf-8').write(h)
for fn in sys.argv[1:]: patch(fn)
print('ok')
