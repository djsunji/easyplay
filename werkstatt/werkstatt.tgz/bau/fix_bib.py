import sys,re
HELP=r'''/* Tempo: schnelle Suche über alle Fragen in einem grossen Text */
const RXB={};
function rxBlob(text){ const key=FRAGEN.length+"|"+S.extra.length+"|"+(text===fTextM?"m":"t"); let b=RXB[key]; if(b) return b;
  for(const k in RXB) delete RXB[k];
  const seen=new Set(), uniq=[]; for(const f of [...FRAGEN,...S.extra]){ if(seen.has(f.q)) continue; seen.add(f.q); uniq.push(f); }
  const offs=new Int32Array(uniq.length), parts=new Array(uniq.length); let pos=0;
  for(let i=0;i<uniq.length;i++){ const t=String(text(uniq[i])).replace(/\n/g," "); offs[i]=pos; parts[i]=t; pos+=t.length+3; }
  return RXB[key]={uniq, offs, big:parts.join(" .\n")}; }
function rxTreffer(uniq,text,re,max,ok){ const {uniq:U,offs,big}=rxBlob(text);
  const g=new RegExp(re.source, re.flags.replace(/[gy]/g,"")+"g"); const out=[]; let m;
  while(out.length<max && (m=g.exec(big))){ let lo=0,hi=offs.length-1; const p=m.index; while(lo<hi){ const mid=(lo+hi+1)>>1; if(offs[mid]<=p) lo=mid; else hi=mid-1; }
    const f=U[lo]; if(!ok||ok(f)) out.push(f); g.lastIndex = lo+1<offs.length ? Math.max(g.lastIndex+(m[0].length?0:1), offs[lo+1]) : big.length; }
  return out; }
'''
for p in sys.argv[1:]:
    h=open(p,encoding='utf-8').read()
    if "function rxTreffer" in h: print(p,"schon"); continue
    i=h.index("function gipfelSeiten("); h=h[:i]+HELP+h[i:]
    h,n1=re.subn(r'uniq\.filter\(f=>(.+?)\.test\(text\(f\)\)\)\.slice\(0,(\d+)\)', r'rxTreffer(uniq,text,\1,\2)', h)
    a='uniq.filter(f=>re.test(text(f)) && !eigene.some(x=>x.q===f.q)).slice(0,13)'
    n2=h.count(a); h=h.replace(a,'rxTreffer(uniq,text,re,13,f=>!eigene.some(x=>x.q===f.q))')
    b='const re=new RegExp("(^|[^A-Za-zÄÖÜäöü])"+w.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")+"(?![a-zäöü])"); return {test:s=>s.includes(w) && re.test(s)}; };'
    n3=h.count(b); h=h.replace(b,'return new RegExp("(?<![A-Za-zÄÖÜäöü])"+w.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")+"(?![a-zäöü])"); };')
    open(p,'w',encoding='utf-8').write(h); print(p,n1,n2,n3)
