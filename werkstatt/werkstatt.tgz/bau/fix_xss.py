import sys
def rep(s,a,b,n=1):
    c=s.count(a)
    if c<n: raise SystemExit(f"nicht gefunden ({c}): {a[:80]}")
    return s.replace(a,b)
for fn in sys.argv[1:]:
    s=open(fn,encoding="utf-8").read()
    if "function spielerSauber" in s: print(fn,"schon"); continue
    s=rep(s,'· ${p.tests||0} Tests</span>','· ${+p.tests||0} Tests</span>')
    s=rep(s,'data-ok="${f.id}" type="button">','data-ok="${esc(f.id)}" type="button">')
    s=rep(s,'data-del="${f.id}" type="button">','data-del="${esc(f.id)}" type="button">')
    s=rep(s,'if(f._nr) return f._nr;','if(f._nr) return +f._nr||0;')
    s=rep(s,'filter(p=>p.pin===DU.pin && p.rolle && p.rolle!==DU.rolle); return ps[0]||null; }',
      'filter(p=>p.pin===DU.pin && p.rolle && p.rolle!==DU.rolle); const g=ps[0]; return g?{...g, name:String(g.name||"Gegner").slice(0,40), score:+g.score||0, i:Math.max(0,+g.i||0), fertig:!!g.fertig}:null; }')
    s=rep(s,'const stripHtml = h => { const d=document.createElement("div"); d.innerHTML=String(h||""); return (d.textContent||"").replace(/\\s+/g," ").trim(); };',
      'const stripHtml = h => { const d=new DOMParser().parseFromString(String(h||""),"text/html"); return ((d.body&&d.body.textContent)||"").replace(/\\s+/g," ").trim(); };')
    # renderLivePlay: Zahlen erzwingen
    s=rep(s,'function renderLivePlay(){\n  const hp=liveHostPeer(); const st=hp?.presence; const me=L.me;',
      'function renderLivePlay(){\n  const hp=liveHostPeer(); const st=liveStand(hp?.presence); const me=L.me;')
    s=rep(s,'function renderLivePlay(){',
      '''function liveStand(p){
  if(!p) return p;
  const zahl=v=>{ const n=+v; return isFinite(n)?n:0; };
  const zahlen=o=>{ const r={}; if(o&&typeof o==="object") for(const k of Object.keys(o)) r[k]=zahl(o[k]); return r; };
  const q=p.q&&typeof p.q==="object"?{...p.q, text:String(p.q.text||""), opts:Array.isArray(p.q.opts)?p.q.opts.map(String):[]}:p.q;
  return {...p, qi:zahl(p.qi), total:zahl(p.total), c:p.c==null?p.c:zahl(p.c), scores:zahlen(p.scores), last:zahlen(p.last), q};
}
function renderLivePlay(){''')
    # öffentliches Profil: nur Ranglistenfelder
    s=rep(s,'const {vorname, nachname, ...oeffentlich}=S.profil; await S.db.doc(`spieler/${S.uid}`).set(oeffentlich);',
      'await S.db.doc(`spieler/${S.uid}`).set(oeffentlichesProfil(S.profil));')
    s=rep(s,'      const {vorname, nachname, ...oeffentlich} = S.profil;\n      await S.db.doc(`spieler/${S.uid}`).set(oeffentlich);',
      '      await S.db.doc(`spieler/${S.uid}`).set(oeffentlichesProfil(S.profil));')
    s=rep(s,'S.spieler = snap.docs.map(d=>({id:d.id, ...(d.data()||{})})).filter(p=>p.name);',
      'S.spieler = snap.docs.map(d=>spielerSauber(d.id, d.data())).filter(p=>p.name);')
    s=rep(s,'function totalPts(p){','''// Nur diese Felder sind öffentlich in der Rangliste (keine E-Mail, keine Namen)
function oeffentlichesProfil(p){
  p=p||{}; const o={name:String(p.name||"").slice(0,40), avatar:p.avatar||null, stufe:+p.stufe||1, kanton:String(p.kanton||"").slice(0,4), best:p.best||{}, saison:p.saison||{}, tests:+p.tests||0};
  if(p.hc) o.hc=p.hc; if(p.erstellt) o.erstellt=p.erstellt; return o;
}
// Fremde Profile aus der Datenbank: nur erwartete Felder und Typen übernehmen
function spielerSauber(id, d){
  d=d||{}; const zahlen=o=>{ const r={}; if(o&&typeof o==="object") for(const k of Object.keys(o).slice(0,400)) { const n=+o[k]; if(isFinite(n)) r[String(k).slice(0,60)]=Math.max(0,Math.min(n,1e6)); } return r; };
  const saison={}; if(d.saison&&typeof d.saison==="object") for(const k of Object.keys(d.saison).slice(0,60)) saison[String(k).slice(0,40)]=zahlen(d.saison[k]);
  const hc=d.hc&&typeof d.hc==="object"?{best:Math.max(0,Math.min(+d.hc.best||0,100000)), zeit:+d.hc.zeit||0, datum:String(d.hc.datum||"").slice(0,30), spiele:+d.hc.spiele||0}:undefined;
  return {id:String(id), name:String(d.name||"").slice(0,40), avatar:typeof d.avatar==="string"?d.avatar.slice(0,40):null, stufe:[1,2,3].includes(+d.stufe)?+d.stufe:1,
    kanton:typeof d.kanton==="string"?d.kanton.slice(0,4):"", best:zahlen(d.best), saison, tests:Math.max(0,+d.tests||0), hc, erstellt:d.erstellt};
}
function totalPts(p){''')
    open(fn,"w",encoding="utf-8").write(s); print(fn,"ok")
