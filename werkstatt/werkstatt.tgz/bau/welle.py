import os,sys
G='/home/claude/mk/gross/'
q=[l.strip() for l in open(G+'queue_nw.txt') if l.strip()]
ein={l.strip() for l in open(G+'eingebaut.txt')}
nr=int(sys.argv[1]) if len(sys.argv)>1 else 10; nw=int(sys.argv[2]) if len(sys.argv)>2 else 10
rev=[s for s in q if os.path.exists(G+f'out/{s}.json') and not os.path.exists(G+f'out/{s}.rev')][:2*nr]
wr=[s for s in q if not os.path.exists(G+f'out/{s}.json')][:2*nw]
fertig=[s for s in q if os.path.exists(G+f'out/{s}.rev') and s not in ein]
print('REV',' '.join(rev)); print('WR',' '.join(wr)); print('EINBAU',','.join(fertig))
print('stand: geschrieben',sum(os.path.exists(G+f'out/{s}.json') for s in q),'geprueft',sum(os.path.exists(G+f'out/{s}.rev') for s in q),'von',len(q))
