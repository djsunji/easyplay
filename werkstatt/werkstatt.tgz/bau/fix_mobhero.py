import sys,base64
w=base64.b64encode(open('/tmp/claude-0/-home-claude-easyplay/3659680d-7d06-598e-9384-c9c658a65ab8/scratchpad/icon_wink.webp','rb').read()).decode()
CSS='''
/* Handy: Logo mittig, Kinder leuchten, Fragezeichen zwinkert */
.mobiconwrap{display:none}
@media (max-width:760px){
  .topbar .logo{display:flex!important;justify-content:center!important;width:100%!important;flex:1 1 100%!important;margin:0 auto}
  .topbar .wmimg{margin:0 auto!important;object-position:center!important}
  .mobiconwrap{display:inline-block;position:relative;line-height:0;margin:0 -8px;animation:fzHuepf 4.2s ease-in-out infinite}
  .mobiconwrap .mobicon{margin:0!important}
  .mobiconwrap .wink{position:absolute;left:0;top:0;width:100%!important;height:100%!important;opacity:0;animation:fzZwinkern 4.2s steps(1,end) infinite}
  .mobkids .kid{position:relative!important;isolation:isolate;animation:kidHuepf 3.4s ease-in-out infinite!important;transform-origin:50% 100%}
  .mobkids .kid.boy{animation-name:kidHuepf2!important;animation-delay:-1.7s!important}
  .mobkids .kid::before{content:"";position:absolute;z-index:-1;left:-18%;right:-18%;top:12%;bottom:0;border-radius:50%;background:radial-gradient(closest-side,rgba(224,67,184,.55),rgba(224,67,184,0));animation:kidGlow 3.4s ease-in-out infinite}
  .mobkids .kid.boy::before{background:radial-gradient(closest-side,rgba(61,90,254,.55),rgba(61,90,254,0));animation-delay:-1.7s}
  .mobkids .kid.girl img{filter:drop-shadow(0 0 8px rgba(255,140,220,.85)) drop-shadow(0 6px 10px rgba(27,34,64,.25))!important}
  .mobkids .kid.boy img{filter:drop-shadow(0 0 8px rgba(120,160,255,.85)) drop-shadow(0 6px 10px rgba(27,34,64,.25))!important}
}
@keyframes kidHuepf{0%,100%{transform:translateY(0) rotate(-2deg)}45%{transform:translateY(-12px) rotate(2deg)}55%{transform:translateY(-12px) rotate(2deg)}}
@keyframes kidHuepf2{0%,100%{transform:translateY(0) rotate(2deg)}45%{transform:translateY(-10px) rotate(-2deg)}55%{transform:translateY(-10px) rotate(-2deg)}}
@keyframes kidGlow{0%,100%{opacity:.55;transform:scale(.92)}50%{opacity:1;transform:scale(1.06)}}
@keyframes fzHuepf{0%,70%,100%{transform:rotate(-3deg) translateY(0)}78%{transform:rotate(4deg) translateY(-6px)}86%{transform:rotate(-3deg) translateY(0)}}
@keyframes fzZwinkern{0%{opacity:0}74%{opacity:1}88%{opacity:0}}
@media (prefers-reduced-motion:reduce){.mobiconwrap,.mobiconwrap .wink,.mobkids .kid,.mobkids .kid::before{animation:none!important}}
'''
for p in sys.argv[1:]:
    h=open(p,encoding='utf-8').read(); n=[]
    a='<img class="mobicon" src="${ICON_SRC}" alt="">'
    if a in h: h=h.replace(a,'<span class="mobiconwrap"><img class="mobicon" src="${ICON_SRC}" alt=""><img class="mobicon wink" src="${ICON_WINK}" alt="" aria-hidden="true"></span>',1); n.append("html")
    if 'const ICON_WINK' not in h:
        k=h.index('const ICON_SRC'); h=h[:k]+'const ICON_WINK = "data:image/webp;base64,'+w+'";\n'+h[k:]; n.append("bild")
    if '/* Handy: Logo mittig' not in h: k=h.index('</style>'); h=h[:k]+CSS+h[k:]; n.append("css")
    open(p,'w',encoding='utf-8').write(h); print(p,n)
