import sys
KOMM=r'''/* ---------- Qeels: Kanal und Kommentare ---------- */
function rlKanal(s){ return String(s||"").toLowerCase().replace(/ä/g,"ae").replace(/ö/g,"oe").replace(/ü/g,"ue").split(/[\s,&·]+/).filter(Boolean)[0]?.replace(/[^a-z0-9]/g,"")||""; }
const KM={cache:{}, gemeldet:store.get("ep-km-gemeldet",{})||{}};
const KM_WORTE=["scheiss","scheiß","arsch","fick","fuck","hure","wichser","spast","missgeburt","bitch","schlampe","nutte","fotze","penner","kacke","idiot","depp","trottel","hurensohn","schwuchtel","nazi","opfer","behindert","neger","kanake"];
function kmPruefen(t){
  const s=String(t||"").trim(); if(s.length<2) return "Der Kommentar ist zu kurz.";
  if(s.length>200) return "Höchstens 200 Zeichen.";
  if(/(https?:\/\/|www\.|\.(ch|com|de|net|org|io)\b)/i.test(s)) return "Links sind in Kommentaren nicht erlaubt.";
  if(/[\w.+-]+@[\w-]+\.[a-z]{2,}/i.test(s)) return "E-Mail-Adressen sind nicht erlaubt.";
  if(/(\+?\d[\d\s\/.-]{7,}\d)/.test(s)) return "Telefonnummern sind nicht erlaubt.";
  const k=s.toLowerCase().replace(/[^a-zäöü]/g,""); if(KM_WORTE.some(w=>k.includes(w))) return "Bitte bleib freundlich. Dieser Kommentar enthält ein Wort, das hier nicht erlaubt ist.";
  return "";
}
function kmLokal(){ return store.get("ep-kommentare",{})||{}; }
async function kmLaden(id){
  try{
    if(S.db){ const sn=await S.db.doc("kommentare/"+id).collection("liste").orderBy("zeit","desc").limit(100).get(); return KM.cache[id]=sn.docs.map(d=>({id:d.id, ...(d.data()||{})})); }
    const sp=lkSupa(); if(sp){ const r=await fetch(`${sp.u}/rest/v1/kommentare?qeel=eq.${encodeURIComponent(id)}&select=id,name,avatar,text,zeit:erstellt,gemeldet&order=erstellt.desc&limit=100`,{headers:sp.h}); if(r.ok) return KM.cache[id]=await r.json(); }
  }catch(e){ console.warn("kommentare", e); }
  return KM.cache[id]=(kmLokal()[id]||[]).slice().reverse();
}
async function kmSenden(id, text){
  const p=S.profil; const k={name:String(p.name||"").slice(0,30), avatar:p.avatar||"", text:String(text).trim(), zeit:new Date().toISOString(), uid:S.uid||"lokal", gemeldet:0};
  if(S.db){ await S.db.doc("kommentare/"+id).collection("liste").add(k); return; }
  const sp=lkSupa(); if(sp){ const r=await fetch(`${sp.u}/rest/v1/kommentare`,{method:"POST",headers:{...sp.h,Prefer:"return=minimal"},body:JSON.stringify({qeel:id,name:k.name,avatar:k.avatar,text:k.text})}); if(!r.ok) throw new Error("senden"); return; }
  const all=kmLokal(); (all[id]=all[id]||[]).push({...k, id:"l"+Date.now()}); store.set("ep-kommentare", all);
}
async function kmMelden(id, k){
  KM.gemeldet[k.id]=1; store.set("ep-km-gemeldet", KM.gemeldet);
  try{ if(S.db) await S.db.doc("kommentare/"+id).collection("liste").doc(k.id).update({gemeldet:(+k.gemeldet||0)+1});
    else { const sp=lkSupa(); if(sp) await fetch(`${sp.u}/rest/v1/rpc/kommentar_melden`,{method:"POST",headers:sp.h,body:JSON.stringify({p_id:+k.id})}); } }catch(e){}
}
async function kmLoeschen(id, k){
  try{ if(S.db){ await S.db.doc("kommentare/"+id).collection("liste").doc(k.id).delete(); return; } }catch(e){ throw e; }
  const all=kmLokal(); all[id]=(all[id]||[]).filter(x=>x.id!==k.id); store.set("ep-kommentare", all);
}
function kmZeit(z){ const d=(Date.now()-new Date(z).getTime())/1000; if(!(d>=0)) return ""; if(d<60) return "gerade eben"; if(d<3600) return `vor ${Math.floor(d/60)} Min.`; if(d<86400) return `vor ${Math.floor(d/3600)} Std.`; const t=Math.floor(d/86400); return t===1?"gestern":`vor ${t} Tagen`; }
function kmAnzeigen(sec, n){ const sm=sec&&sec.querySelector("[data-komm] small"); if(sm) sm.textContent = n ? zahlKurz(n) : "Kommentare"; }
function kmSichtbar(l){ return (l||[]).filter(k=>!KM.gemeldet[k.id] && (+k.gemeldet||0)<3); }
async function kmZaehlen(sec){ const b=sec.querySelector("[data-komm]"); if(!b||b.dataset.geladen) return; b.dataset.geladen="1"; const l=await kmLaden(b.dataset.komm); kmAnzeigen(sec, kmSichtbar(l).length); }
async function kmOeffnen(sec, id){
  const o=$("#reels"); if(!o) return; $("#rkomm")?.remove();
  const d=document.createElement("div"); d.id="rkomm"; d.className="rsheet rkomm"; d.setAttribute("role","dialog"); d.setAttribute("aria-label","Kommentare");
  o.appendChild(d);
  const zeichne=(liste, fehler)=>{
    const l=kmSichtbar(liste), meinId=S.uid||"lokal";
    d.innerHTML=`<div class="rkkopf"><b>💬 ${l.length} ${l.length===1?"Kommentar":"Kommentare"}</b><button type="button" class="rkzu" aria-label="Schliessen">✕</button></div>
      <div class="rkliste">${l.length? l.map(k=>`<div class="rkitem"><span class="rkav" aria-hidden="true">${avatar(k.avatar)}</span><div class="rktext"><b>${esc(k.name||"Jemand")}</b> <small>${kmZeit(k.zeit)}</small><p>${esc(k.text)}</p>
        <span class="rkakt">${(k.uid&&k.uid===meinId)||S.canEdit?`<button type="button" data-kdel="${esc(k.id)}">Löschen</button>`:""}<button type="button" data-kmeld="${esc(k.id)}">Melden</button></span></div></div>`).join("") : `<p class="rkleer">Noch keine Kommentare. Schreib den ersten!</p>`}</div>
      ${S.profil ? `<form class="rkform"><span class="rkav" aria-hidden="true">${avatar(S.profil.avatar)}</span><label class="sr-only" for="rkInput">Kommentar</label><input id="rkInput" maxlength="200" placeholder="Schreib etwas Nettes …" autocomplete="off"><button type="submit" class="rksend">Senden</button></form>
        <p class="rkregel">${fehler?`<b class="rkfehler">${esc(fehler)}</b>`:"Sei freundlich. Keine Links, Telefonnummern oder E-Mail-Adressen."}</p>`
        : `<div class="rkform rkgast"><p>Melde dich an, um zu kommentieren.</p><button type="button" class="rksend" data-kreg>Anmelden</button></div>`}`;
    d.querySelector(".rkzu").onclick=()=>d.remove();
    d.querySelector("[data-kreg]")?.addEventListener("click",()=>{ try{ schliesseReels(); }catch(e){} go("register"); });
    d.querySelectorAll("[data-kmeld]").forEach(b=>b.onclick=async()=>{ const k=liste.find(x=>x.id===b.dataset.kmeld); if(!k) return; await kmMelden(id,k); rlToast("Danke! Der Kommentar wurde gemeldet."); zeichne(liste); kmAnzeigen(sec, kmSichtbar(liste).length); });
    d.querySelectorAll("[data-kdel]").forEach(b=>b.onclick=async()=>{ const k=liste.find(x=>x.id===b.dataset.kdel); if(!k) return; try{ await kmLoeschen(id,k); }catch(e){ rlToast("Löschen hat nicht geklappt"); return; } liste=await kmLaden(id); zeichne(liste); kmAnzeigen(sec, kmSichtbar(liste).length); });
    const f=d.querySelector("form.rkform"); if(f){ const inp=f.querySelector("input"); f.onsubmit=async e=>{ e.preventDefault(); const t=inp.value; const fe=kmPruefen(t); if(fe){ zeichne(liste, fe); const n=d.querySelector("#rkInput"); n.value=t; n.focus(); return; }
      f.querySelector(".rksend").disabled=true; try{ await kmSenden(id,t); }catch(x){ zeichne(liste,"Senden hat nicht geklappt. Versuche es nochmals."); return; } liste=await kmLaden(id); zeichne(liste); kmAnzeigen(sec, kmSichtbar(liste).length); }; }
  };
  let liste=KM.cache[id]||[]; zeichne(liste); liste=await kmLaden(id); if(document.body.contains(d)) zeichne(liste);
}
'''
CSS='''
/* Qeels: Kanal und Kommentare */
.rkanal b .rkslash{opacity:.8;font-weight:600}
.rkomm{z-index:22}
.rkomm .rkkopf{display:flex;justify-content:space-between;align-items:center;padding:14px 18px;border-bottom:1px solid rgba(0,0,0,.1)}
.rkomm .rkzu{background:none;border:0;font-size:1.3rem;cursor:pointer;color:inherit}
.rkomm .rkliste{overflow:auto;padding:8px 18px;flex:1 1 auto;min-height:120px;max-height:52dvh}
.rkomm .rkitem{display:flex;gap:10px;padding:10px 0;border-bottom:1px solid rgba(0,0,0,.06)}
.rkomm .rkav{width:34px;height:34px;flex:none;display:grid;place-items:center;font-size:1.4rem;border-radius:50%;background:rgba(0,0,0,.06);overflow:hidden}
.rkomm .rkav svg,.rkomm .rkav img{width:100%;height:100%}
.rkomm .rktext{flex:1;min-width:0}.rkomm .rktext p{margin:2px 0 4px;overflow-wrap:anywhere}
.rkomm .rktext small{opacity:.6}
.rkomm .rkakt{display:flex;gap:12px}.rkomm .rkakt button{background:none;border:0;padding:0;font-size:.8rem;opacity:.6;cursor:pointer;color:inherit}
.rkomm .rkakt button:hover{opacity:1;text-decoration:underline}
.rkomm .rkleer{text-align:center;opacity:.7;padding:24px 0}
.rkomm .rkform{display:flex;gap:8px;align-items:center;padding:12px 18px 4px;border-top:1px solid rgba(0,0,0,.1)}
.rkomm .rkform input{flex:1;min-width:0;padding:12px 16px;border-radius:999px;border:2px solid rgba(0,0,0,.15);font:inherit;background:#fff;color:#111}
.rkomm .rksend{border:0;border-radius:999px;padding:12px 18px;font-weight:700;cursor:pointer;color:#fff;background:linear-gradient(135deg,#8A3FE0,#3D5AFE)}
.rkomm .rksend:disabled{opacity:.5}
.rkomm .rkregel{margin:4px 18px 14px;font-size:.78rem;opacity:.7}.rkomm .rkfehler{color:#C62828;opacity:1}
.rkomm .rkgast{justify-content:space-between;padding-bottom:16px}.rkomm .rkgast p{margin:0}
'''
SQL='''
-- Qeels: Kommentare
create table if not exists kommentare (
  id bigserial primary key,
  qeel text not null,
  name text not null check (char_length(name) between 1 and 30),
  avatar text,
  text text not null check (char_length(text) between 2 and 200),
  gemeldet int not null default 0,
  erstellt timestamptz not null default now()
);
create index if not exists kommentare_qeel on kommentare(qeel, erstellt desc);
alter table kommentare enable row level security;
create policy "kommentare lesen" on kommentare for select using (gemeldet < 3);
create policy "kommentare schreiben" on kommentare for insert with check (gemeldet = 0);
create or replace function kommentar_melden(p_id bigint) returns void language sql security definer as $$
  update kommentare set gemeldet = gemeldet + 1 where id = p_id;
$$;
grant execute on function kommentar_melden(bigint) to anon, authenticated;
'''
for p in sys.argv[1:]:
    h=open(p,encoding='utf-8').read(); n=[]
    a='<b>@easyplay</b><span class="rchip">${tag}</span>'
    if a in h:
        h=h.replace('function rlMeta(tag, text, ton, oben){','function rlMeta(tag, text, ton, oben, kanal){',1)
        h=h.replace(a,'<b>@easyplay${kanal?`<span class="rkslash">/${esc(kanal)}</span>`:""}</b><span class="rchip">${tag}</span>',1); n.append("kanal")
        h=h.replace('`${esc(th.bereich.name)} · ${esc(th.name)}`)}','`${esc(th.bereich.name)} · ${esc(th.name)}`, "", rlKanal(th.bereich.name))}',1)
        h=h.replace('`${esc(B.titel)} · ${esc(s.kap.titel)}`)}','`${esc(B.titel)} · ${esc(s.kap.titel)}`, "", rlKanal(B.titel))}',1)
    a='''    ${extra}
    <button type="button" class="rbtn" data-teilen>'''
    if a in h: h=h.replace(a,'''    <button type="button" class="rbtn" data-komm="${esc(id)}"><span class="rbi">💬</span><small>Kommentare</small></button>
    ${extra}
    <button type="button" class="rbtn" data-teilen>''',1); n.append("rail")
    a='  sec.querySelector("[data-teilen]").onclick=()=>rlTeilen(it);'
    if a in h and 'data-komm]")' not in h: h=h.replace(a,a+'\n  const kb=sec.querySelector("[data-komm]"); kb && (kb.onclick=()=>kmOeffnen(sec, kb.dataset.komm));',1); n.append("bind")
    a='rlLikeLaden(sec);'
    if 'kmZaehlen(sec)' not in h: h=h.replace(a,'rlLikeLaden(sec); kmZaehlen(sec);',1); n.append("zaehlen")
    if 'function kmOeffnen' not in h: k=h.index('function zahlKurz('); h=h[:k]+KOMM+h[k:]; n.append("js")
    if '/* Qeels: Kanal und Kommentare */' not in h: k=h.index('</style>'); h=h[:k]+CSS+h[k:]; n.append("css")
    open(p,'w',encoding='utf-8').write(h); print(p,n)
s='/mnt/user-data/outputs/easyplay/supabase/schema.sql'; t=open(s,encoding='utf-8').read()
if 'create table if not exists kommentare' not in t: open(s,'a',encoding='utf-8').write(SQL); print("sql")
