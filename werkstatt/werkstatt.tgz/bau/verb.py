JS=r'''
/* ---------- Bibliothek: Querverweise zwischen Artikeln ---------- */
const VL = { key:"", alias:null, re:null, rueck:{} };
function vlSeitenAlle(){ return BUECHER.flatMap(B=>buchDaten(B.id).seiten.map(s=>({s,B}))); }
function vlAlias(t){ return String(t).replace(/\s*\([^)]*\)\s*$/,"").trim(); }
function vlEsc(t){ return t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"); }
function vlIndex(){
  const key=FRAGEN.length+"|"+S.extra.length;
  if(VL.key===key && VL.re) return VL;
  const map=new Map();
  const score=s=>(s.teile||s.typ==="art"?5:0)+(S.texte[seiteKey(s)]?3:0)+Math.min((s.fragen||[]).length,20)/10;
  vlSeitenAlle().forEach(({s,B})=>{
    if(s.titel==="Allgemeines") return;
    const a=vlAlias(s.titel); if(a.length<4 || /^\d+$/.test(a)) return;
    const alt=map.get(a); const sc=score(s);
    if(!alt || sc>alt.sc) map.set(a,{b:B.id, nr:s.nr, titel:s.titel, emo:B.emo, buch:B.titel, kap:s.kap?.titel||"", sc});
  });
  const namen=[...map.keys()].sort((x,y)=>y.length-x.length);
  VL.alias=map; VL.key=key; VL.rueck={};
  VL.re = namen.length ? new RegExp("(?<![A-Za-zÄÖÜäöüß])("+namen.map(vlEsc).join("|")+")(?:s|es)?(?![A-Za-zäöüß])","g") : null;
  return VL;
}
const VL_SKIP="a,button,h1,figure,.skopf,.blaettern,.libnav,.zufallleiste,.kframe,.kfuss,.verbindungen,.adminleiste,.stkopf,dt,.bibst,.flusstabs,.kkopf,.kinfo,.wikilink,.speak,svg,script,style";
function verlinkeSeite(s, B){
  const root=$(".buchseite"); if(!root) return;
  let V; try{ V=vlIndex(); }catch(e){ return; }
  if(!V.re) return;
  const selbst=vlAlias(s.titel); const gefunden=new Map();
  const walker=document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode:n=> n.nodeValue.trim().length<4 || n.parentElement.closest(VL_SKIP) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
  const knoten=[]; while(walker.nextNode()) knoten.push(walker.currentNode);
  for(const n of knoten){
    const txt=n.nodeValue; V.re.lastIndex=0; let m, pos=0; const frag=document.createDocumentFragment(); let geaendert=false;
    while((m=V.re.exec(txt))){
      const ziel=V.alias.get(m[1]); if(!ziel || m[1]===selbst || (ziel.b===B.id && ziel.nr===s.nr)) continue;
      const k=ziel.b+"|"+ziel.nr; if(gefunden.has(k) || gefunden.size>=40) continue;
      gefunden.set(k,ziel);
      frag.append(txt.slice(pos,m.index));
      const a=document.createElement("a"); a.href="#"; a.className="vlink"; a.dataset.sb=ziel.b; a.dataset.sn=ziel.nr; a.title=`Zum Artikel «${ziel.titel}»`; a.textContent=m[0];
      frag.append(a); pos=m.index+m[0].length; geaendert=true;
    }
    if(geaendert){ frag.append(txt.slice(pos)); n.parentNode.replaceChild(frag,n); }
  }
  root.querySelectorAll(".vlink").forEach(a=>a.onclick=e=>{ e.preventDefault(); vlOeffnen(a.dataset.sb, +a.dataset.sn); });
  const box=$("#verbBox"); if(!box) return;
  const chip=z=>`<button type="button" class="vchip" data-sb="${z.b}" data-sn="${z.nr}"><span class="vemo">${z.emo}</span><span class="vt"><b>${esc(z.titel)}</b><small>${esc(z.buch)} · ${esc(z.kap)}</small></span></button>`;
  const raus=[...gefunden.values()];
  const zeichne=rein=>{
    if(!$("#verbBox")) return;
    if(!raus.length && !rein.length){ box.hidden=true; return; }
    box.innerHTML=`<h3>🔗 Verbindungen</h3>
      ${raus.length?`<div class="vgruppe"><p class="vkopf">➡️ In diesem Artikel erwähnt</p><div class="vchips">${raus.map(chip).join("")}</div></div>`:""}
      ${rein.length?`<div class="vgruppe"><p class="vkopf">⬅️ «${esc(s.titel)}» wird erwähnt in</p><div class="vchips">${rein.map(chip).join("")}</div></div>`:""}`;
    box.hidden=false;
    box.querySelectorAll(".vchip").forEach(b=>b.onclick=()=>vlOeffnen(b.dataset.sb, +b.dataset.sn));
  };
  zeichne([]);
  const rk=B.id+"|"+s.nr;
  if(VL.rueck[rk]){ zeichne(VL.rueck[rk]); return; }
  if(selbst.length<4){ return; }
  setTimeout(()=>{
    if(LIB.seite!==s.nr) return;
    const re=new RegExp("(?<![A-Za-zÄÖÜäöüß])"+vlEsc(selbst)+"(?:s|es)?(?![A-Za-zäöüß])");
    const rein=[];
    for(const {s:x,B:XB} of vlSeitenAlle()){
      if(x===s || x.titel==="Allgemeines" || vlAlias(x.titel)===selbst) continue;
      const t = x.typ==="art" ? String(x.art.html||"").replace(/<[^>]+>/g," ") :
        (x.fragen||[]).map(f=>f.q+" "+f.a[0]+" "+f.e+" "+(f.m||"")).join(" ")+" "+(S.texte[seiteKey(x)]||"")+" "+(x.teile?[x.teile.einleitung,...(x.teile.wichtigste||[]),...(x.teile.abschnitte||[]).map(a=>a.text),...(x.teile.gewusst||[])].join(" "):"")+" "+(x.steck?.zeilen||[]).map(z=>z[1]).join(" ");
      if(re.test(t)) rein.push({b:XB.id, nr:x.nr, titel:x.titel, emo:XB.emo, buch:XB.titel, kap:x.kap?.titel||""});
      if(rein.length>=24) break;
    }
    VL.rueck[rk]=rein; zeichne(rein);
  },60);
}
function vlOeffnen(b, nr){ LIB.buch=b; LIB.seite=nr; LIB.zufall=false; go("libseite"); scrollTo(0,0); }
'''
CSS=r'''
/* ---- Querverweise ---- */
a.vlink{color:var(--bf,#3D5AFE);font-weight:700;text-decoration:underline;text-decoration-style:dotted;text-decoration-thickness:2px;text-underline-offset:3px;cursor:pointer;border-radius:4px;transition:background .15s}
a.vlink:hover,a.vlink:focus-visible{background:rgba(61,90,254,.12);text-decoration-style:solid}
.verbindungen{margin:26px 0 10px;padding:16px;border-radius:18px;background:linear-gradient(135deg,rgba(61,90,254,.07),rgba(224,67,184,.07));border:2px solid rgba(61,90,254,.18)}
.verbindungen h3{margin:0 0 10px}
.vgruppe+.vgruppe{margin-top:14px}
.vkopf{margin:0 0 8px;font-weight:800;color:var(--soft)}
.vchips{display:flex;flex-wrap:wrap;gap:8px}
.vchip{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border-radius:14px;border:2px solid rgba(0,0,0,.08);background:var(--surface,#fff);cursor:pointer;text-align:left;font:inherit;box-shadow:0 3px 0 rgba(0,0,0,.08);transition:transform .12s}
.vchip:hover{transform:translateY(-2px);border-color:var(--bf,#3D5AFE)}
.vemo{font-size:1.3rem;font-family:"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif}
.vt{display:grid;line-height:1.15}.vt b{font-size:.95rem}.vt small{font-size:.75rem;color:var(--soft)}
@media (max-width:560px){.vchip{flex:1 1 100%}}
'''
for p in ['/mnt/user-data/outputs/lernspiel.html','/mnt/user-data/outputs/easyplay/index.html']:
    h=open(p,encoding='utf-8').read()
    def r(a,b):
        global h
        assert h.count(a)==1,(p,a[:60],h.count(a)); h=h.replace(a,b)
    r("/* ---------- Bibliothek: Kapitel «Die Schweizer Alpen» ---------- */", JS+"\n/* ---------- Bibliothek: Kapitel «Die Schweizer Alpen» ---------- */")
    r('''      ${inhalt}
      <div class="blaettern">''','''      ${inhalt}
      <section class="verbindungen" id="verbBox" hidden></section>
      <div class="blaettern">''')
    r('''  $("#nochZufall") && ($("#nochZufall").onclick=zufallArtikel);''','''  $("#nochZufall") && ($("#nochZufall").onclick=zufallArtikel);
  try{ verlinkeSeite(s, B); }catch(e){ console.warn(e); }''')
    r("</style>", CSS+"\n</style>")
    open(p,'w',encoding='utf-8').write(h)
print("ok")
