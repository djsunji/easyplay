// Erzeugt bibidx.js: vorberechnete Treffer der Bibliotheks-Sonderseiten. node bibidx.js URL ZIELDATEI
const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const p=await b.newPage();
await p.goto(process.argv[2],{waitUntil:'load',timeout:180000});await p.waitForTimeout(5000);
const out=await p.evaluate(()=>{window.EP_BIBIDX=null;const R={};const orig=window.rxTreffer;
 window.rxTreffer=function(uniq,text,re,max,ok){const r=orig(uniq,text,re,max,ok);R[re.source+"/"+re.flags+"/"+max+"/"+(text===fTextM?"m":"t")+(ok?"/o":"")]=r.map(f=>f.nr!=null?f.nr:"q:"+f.q);return r};
 for(const k in BUCHCACHE) delete BUCHCACHE[k]; BUECHER.forEach(B=>buchDaten(B.id)); window.rxTreffer=orig;
 const bad=Object.values(R).some(a=>a.some(x=>x==null)); return {n:FRAGEN.length,r:R,bad}});
if(out.bad) console.log('WARNUNG: Treffer ohne nr');
fs.writeFileSync(process.argv[3],'/* easyplay Bibliothek-Index (automatisch) */window.EP_BIBIDX='+JSON.stringify({n:out.n,r:out.r})+';\n');
console.log('bibidx',Object.keys(out.r).length,'Einträge',fs.statSync(process.argv[3]).size,'Bytes');await b.close();})();
