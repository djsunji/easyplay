import re,json,sys
M=json.load(open('/home/claude/mk/merk_map.json'))
EXTRA=open('/home/claude/bau/extra.js').read()
def patch(path):
    h=open(path,encoding='utf-8').read()
    def r(a,b,cnt=1):
        nonlocal h
        n=h.count(a); assert n==cnt,(path,a[:80],n); h=h.replace(a,b)
    # 1 Merksätze
    zahl=[0]
    def rep(m):
        try: alt=json.loads('"'+m.group(2)+'"')
        except Exception: return m.group(0)
        if alt in M and M[alt]!=alt:
            zahl[0]+=1; return m.group(1)+json.dumps(M[alt],ensure_ascii=False)
        return m.group(0)
    h=re.sub(r'(["\']?\bm["\']?\s*:\s*)"((?:[^"\\\n]|\\.)*)"',rep,h)
    print(path,'Merksätze ersetzt:',zahl[0])
    # 2 Tippfehler
    r("Primarschule 1. 3. Klasse","Primarschule 1. bis 3. Klasse")
    r("Primar- bis Oberstufe 4. 8. Klasse","Primar- bis Oberstufe 4. bis 8. Klasse")
    r("Verteilung <b>2 bis 2, 2 bis 1</b>","Verteilung <b>2 + 2 + 2 + 1</b>")
    r('?"die ersten 150 werden angezeigt"','?" (die ersten 150 werden angezeigt)"')
    r('?"die ersten 200 werden angezeigt"','?" (die ersten 200 werden angezeigt)"')
    r("bei den SBB, damit ist sie einer der grössten Arbeitgeber","bei den SBB, damit sind sie einer der grössten Arbeitgeber")
    r("als pünktlich gilt bei der SBB eine","als pünktlich gilt bei den SBB eine")
    # 3 Modul
    r("/* ---------- Bibliothek: Kapitel «Die Schweizer Alpen» ---------- */", EXTRA+"\n/* ---------- Bibliothek: Kapitel «Die Schweizer Alpen» ---------- */")
    # 4 buchDaten
    r("""{id:"jura", titel:"Der Jura", emo:"🌲", seiten:juraKapitel()}); }
  kap=kap.filter(k=>k.seiten.length);""","""{id:"jura", titel:"Der Jura", emo:"🌲", seiten:juraKapitel()}); }
  { const xk=extraKapitel(bid); if(xk.length){ const ji=kap.findIndex(x=>x.id==="jura"); kap.splice(ji>=0?ji+1:kap.length,0,...xk); } }
  kap=kap.filter(k=>k.seiten.length);""")
    r('''const rub=id=> id==="kt_alle"||id==="alpen"||id==="jura"||id.startsWith("geo_") ? R.o''','''const rub=id=> id==="kt_alle"||id==="alpen"||id==="jura"||id.startsWith("geo_")||id.startsWith("x_") ? R.o''')
    # 5 Quiz-Knöpfe
    r('''$("#libQuiz").onclick=()=> ["alpen","jura","ch_behoerden","ch_sicherheit","ch_betriebe"].includes(k.id) ?''','''$("#libQuiz").onclick=()=> istSonderKapitel(k.id) ?''')
    r('''$("#libQuiz").onclick=()=> ["alpen","jura","ch_behoerden","ch_sicherheit","ch_betriebe"].includes(s.kap.id) ?''','''$("#libQuiz").onclick=()=> istSonderKapitel(s.kap.id) ?''')
    # Suche berücksichtigt Einleitungen
    r('''.join(" ")+" "+(S.texte[seiteKey(s)]||"");''','''.join(" ")+" "+(S.texte[seiteKey(s)]||(s.teile?s.teile.einleitung:""));''')
    # 6 Auf einen Blick: nur ganze Sätze
    r('''const merk=[...new Set(s.fragen.map(f=>f.m).filter(Boolean))];''','''const merk=[...new Set(s.fragen.map(f=>f.m).filter(m=>m && !/ = |→|^[^:]{1,45}: /.test(m)))];''')
    # 7 Bild immer (Ersatzbild), Zufallsknopf
    r('''      <header><h1>${esc(s.titel)}</h1></header>
      ${s.typ==="fr" || s.art?.bild ? `<figure class="wbild" id="wBild" hidden></figure>` : ""}''','''      <header><h1>${esc(s.titel)}</h1></header>
      ${LIB.zufall?`<div class="zufallleiste"><span>🎲 Zufallsartikel aus «${esc(B.titel)}»</span><button class="big zufallart" id="nochZufall" type="button"><span class="wuerfel">🎲</span> Noch ein zufälliger Artikel</button></div>`:""}
      <figure class="wbild ersatz" id="wBild">${ersatzBildHTML(s,B)}</figure>''')
    r('''  if(s.typ==="art") zeigeWikiBild(s.art.bild, s.nr);
  else zeigeKarte(s.wiki||s.titel, s.nr, s.kap.id);''','''  if(s.typ==="art") zeigeWikiBild(null, s.nr, [s.art.bild||null, s.titel], s.titel+" Schweiz");
  else zeigeKarte(s.wiki||s.titel, s.nr, s.kap.id, s);
  $("#nochZufall") && ($("#nochZufall").onclick=zufallArtikel);''')
    r('''    const img=f.querySelector("img"); img.onerror=()=>{ f.hidden=true; };''','''    const img=f.querySelector("img"); img.onerror=()=>{ f.innerHTML=ersatz; f.classList.add("ersatz"); };''')
    r('''    if(!b || LIB.seite!==nr || !$("#wBild")) return;
    const f=$("#wBild");''','''    if(!b || LIB.seite!==nr || !$("#wBild")) return;
    const f=$("#wBild"); const ersatz=f.innerHTML; f.classList.remove("ersatz");''')
    # Zufall-Flag zurücksetzen
    for fn in ["function renderLibBuch(){\n","function renderLibKapitel(){\n","function renderLib(){\n"]:
        r(fn, fn+"  LIB.zufall=false;\n")
    # 8 Karte
    a=h.index("function zeigeKarte(titel, nr, kapId){"); b=h.index("/* ================= Seasons:")
    h=h[:a]+KARTE+"\n"+h[b:]
    # 9 Startseite
    r('''        <div class="kennzahlen">
          <div class="kzk kzk-fragen"><span class="kzicon">❓</span><span class="kztext"><b class="zaehler" data-ziel="${allCount()}">${allCount().toLocaleString("de-CH")}</b><span>Fragen zum Knobeln</span></span><i class="kzf a">✦</i><i class="kzf b">✧</i></div>
          <div class="kzk kzk-themen"><span class="kzicon">📚</span><span class="kztext"><b class="zaehler" data-ziel="${themen}">${themen}</b><span>spannende Themen</span></span><i class="kzf a">★</i><i class="kzf b">✦</i></div>
        </div>''','''        <div class="kennzahlen kz2">
          <div class="kzk kzk-fragen"><span class="kzicon">❓</span><span class="kztext"><b class="zaehler" data-ziel="${allCount()}">${allCount().toLocaleString("de-CH")}</b><span>Fragen zum Knobeln</span><em class="kzchips"><i>🌱</i><i>🚀</i><i>🏅</i> in 3 Stufen</em></span><i class="kzf a">✦</i><i class="kzf b">✧</i></div>
          <div class="kzk kzk-themen"><span class="kzicon">📚</span><span class="kztext"><b class="zaehler" data-ziel="${themen}">${themen}</b><span>spannende Themen</span><em class="kzchips"><i>🌍</i><i>🔬</i><i>🇨🇭</i><i>🚲</i> in 4 Bereichen</em></span><i class="kzf a">★</i><i class="kzf b">✦</i></div>
        </div>''')
    r('''          <button class="big bibl" id="toLib" type="button"><span class="cicon buchsym">📖</span> Bibliothek</button>
        </div>''','''          <button class="big bibl" id="toLib" type="button"><span class="cicon buchsym">📖</span> Bibliothek</button>
          <button class="big zartikel" id="zufallArt" type="button"><span class="cicon wuerfel">🔮</span> Zufälliger Artikel</button>
        </div>''')
    r('''  $("#toLib") && ($("#toLib").onclick=()=>{ setLibModus(true); scrollTo(0,0); });''','''  $("#toLib") && ($("#toLib").onclick=()=>{ setLibModus(true); scrollTo(0,0); });
  $("#zufallArt") && ($("#zufallArt").onclick=zufallArtikel);''')
    # 10 CSS
    r("</style>", CSS+"\n</style>")
    open(path,'w',encoding='utf-8').write(h)

KARTE=r'''function osmSrc(lat,lon,sp,mlat,mlon){
  const lonSp=sp/Math.max(.3,Math.cos(lat*Math.PI/180));
  const bbox=[lon-lonSp,lat-sp*.62,lon+lonSp,lat+sp*.62].map(v=>v.toFixed(4)).join(",");
  return `https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${(+mlat).toFixed(5)},${(+mlon).toFixed(5)}`;
}
function osmZoom(sp){ return sp>20?3:sp>5?5:sp>2?6:sp>0.8?8:sp>0.3?10:sp>0.2?11:13; }
function karteFuss(lat,lon,sp){ return `<div class="kfuss"><span>Karte: © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap-Mitwirkende</a></span>
      <a href="https://www.openstreetmap.org/?mlat=${lat.toFixed(5)}&mlon=${lon.toFixed(5)}#map=${osmZoom(sp)}/${lat.toFixed(4)}/${lon.toFixed(4)}" target="_blank" rel="noopener">🔍 Grössere Karte</a></div>`; }
function karteEinblenden(b){ b.hidden=false; b.animate([{opacity:0,transform:"translateY(8px)"},{opacity:1,transform:"none"}],{duration:400}); }
function zeigeKarte(titel, nr, kapId, s){
  const box=$("#kartenBox"); if(!box) return;
  const g=s?.geo;
  if(g && !window.claude){
    if(g.quelle && g.muendung){
      const [qa,qo]=g.quelle, [ma,mo]=g.muendung; const lat=(qa+ma)/2, lon=(qo+mo)/2;
      const sp=Math.max(Math.abs(qa-ma)*0.62, Math.abs(qo-mo)*0.62*Math.cos(lat*Math.PI/180), 0.35);
      const qz=s.steck?.zeilen||[]; const wert=n=>(qz.find(z=>z[0]===n)||[])[1]||"";
      const ansichten={ganz:{lat,lon,sp,m:[qa,qo],t:"Der ganze Fluss (Markierung: Quelle)"}, quelle:{lat:qa,lon:qo,sp:.12,m:[qa,qo],t:"📍 Quelle: "+wert("Quelle")}, muendung:{lat:ma,lon:mo,sp:.25,m:[ma,mo],t:"🌊 Mündung: "+wert("Mündung")}};
      box.innerHTML=`<div class="kkopf">🗺️ <b>Wo fliesst ${esc(s.titel)}?</b></div>
        <div class="segs flusstabs" role="group" aria-label="Kartenansicht"><button type="button" class="seg" data-fk="ganz" aria-pressed="true">🌊 Ganzer Fluss</button><button type="button" class="seg" data-fk="quelle" aria-pressed="false">📍 Quelle</button><button type="button" class="seg" data-fk="muendung" aria-pressed="false">🏁 Mündung</button></div>
        <p class="kinfo" id="fkInfo">${esc(ansichten.ganz.t)}</p>
        <div class="kframe"><iframe id="fkFrame" title="Karte von ${esc(s.titel)}" loading="lazy" referrerpolicy="no-referrer" src="${osmSrc(lat,lon,sp,qa,qo)}"></iframe></div>
        <div id="fkFuss">${karteFuss(lat,lon,sp)}</div>`;
      box.querySelectorAll("[data-fk]").forEach(bt=>bt.onclick=()=>{ const v=ansichten[bt.dataset.fk];
        box.querySelectorAll("[data-fk]").forEach(x=>x.setAttribute("aria-pressed",x===bt));
        $("#fkFrame").src=osmSrc(v.lat,v.lon,v.sp,v.m[0],v.m[1]); $("#fkInfo").textContent=v.t; $("#fkFuss").innerHTML=karteFuss(v.lat,v.lon,v.sp); });
      karteEinblenden(box); return;
    }
    const sp=g.sp||0.3;
    box.innerHTML=`<div class="kkopf">🗺️ <b>Wo liegt ${esc(s.titel)}?</b></div>
      <div class="kframe"><iframe title="Karte von ${esc(s.titel)}" loading="lazy" referrerpolicy="no-referrer" src="${osmSrc(g.lat,g.lon,sp,g.lat,g.lon)}"></iframe></div>${karteFuss(g.lat,g.lon,sp)}`;
    karteEinblenden(box); return;
  }
  wikiKoord(titel).then(k=>{
    if(!k || LIB.seite!==nr || !$("#kartenBox")) return;
    const sp=kartenSpanne(k,kapId); const b=$("#kartenBox");
    b.innerHTML=`<div class="kkopf">🗺️ <b>Wo liegt ${esc(k.titel)}?</b></div>
      <div class="kframe"><iframe title="Karte von ${esc(k.titel)}" loading="lazy" referrerpolicy="no-referrer" src="${osmSrc(k.lat,k.lon,sp,k.lat,k.lon)}"></iframe></div>${karteFuss(k.lat,k.lon,sp)}`;
    karteEinblenden(b);
  });
}
function ersatzBildHTML(s,B){
  const g=s.gipfel;
  const emo = s.emo || s.steck?.emo || (g ? (g.art==="pass"?"🛣️":g.art==="jura"?"🌲":"🏔️") : s.bahn ? "🚡" : s.typ==="art" ? "📜" : s.kap?.emo || "📖");
  const berg = g ? `<svg class="ebberg" viewBox="0 0 400 120" preserveAspectRatio="none" aria-hidden="true"><path d="M0 120 L70 70 L110 88 L180 18 L215 44 L250 30 L320 82 L360 64 L400 90 L400 120Z" fill="rgba(255,255,255,.28)"/><path d="M180 18 L198 34 L188 36 L176 30Z M250 30 L262 40 L246 42Z" fill="#fff" opacity=".8"/></svg>` : "";
  return `<div class="ebild" style="--bf:${B?.farbe||"#3D5AFE"};--bf2:${B?.farbe2||"#1B2E99"}" role="img" aria-label="${esc(s.titel)}">
    <i class="ebk k1"></i><i class="ebk k2"></i><i class="ebk k3"></i>${berg}
    <span class="ebemo">${emo}</span><span class="ebtitel">${esc(s.titel)}</span>${g?`<span class="ebhoehe">${g.h.toLocaleString("de-CH")} m ü. M.</span>`:""}</div>`;
}
'''
CSS=r'''
/* ---- Ersatzbild, Zufallsartikel, Flusskarte, Kennzahlen v2 ---- */
.wbild.ersatz{padding:0;background:none;border:0}
.ebild{position:relative;overflow:hidden;height:190px;border-radius:20px;background:radial-gradient(circle at 25% 20%,rgba(255,255,255,.35),transparent 45%),linear-gradient(135deg,var(--bf),var(--bf2));display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;color:#fff;box-shadow:0 10px 24px -14px rgba(0,0,0,.5)}
.ebemo{font-size:4.6rem;line-height:1;filter:drop-shadow(0 6px 8px rgba(0,0,0,.25));animation:ebschweb 4s ease-in-out infinite;font-family:"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif;position:relative;z-index:2}
.ebtitel{font-family:"Bricolage Grotesque",system-ui,sans-serif;font-weight:800;font-size:1.35rem;text-shadow:0 2px 6px rgba(0,0,0,.3);position:relative;z-index:2;text-align:center;padding:0 12px}
.ebhoehe{font-weight:700;font-size:.9rem;background:rgba(0,0,0,.22);padding:2px 10px;border-radius:99px;position:relative;z-index:2}
.ebk{position:absolute;border-radius:50%;background:rgba(255,255,255,.12)}
.ebk.k1{width:180px;height:180px;left:-50px;top:-60px}.ebk.k2{width:120px;height:120px;right:-30px;bottom:-40px}.ebk.k3{width:46px;height:46px;right:22%;top:14px;background:rgba(255,255,255,.2)}
.ebberg{position:absolute;left:0;right:0;bottom:0;width:100%;height:70%;z-index:1}
@keyframes ebschweb{0%,100%{transform:translateY(0) rotate(-3deg)}50%{transform:translateY(-8px) rotate(3deg)}}
@media (prefers-reduced-motion:reduce){.ebemo{animation:none}}
.zufallleiste{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin:0 0 14px;padding:10px 12px;border-radius:16px;background:linear-gradient(135deg,rgba(138,63,224,.12),rgba(224,67,184,.12));border:2px dashed rgba(138,63,224,.35)}
.zufallleiste span{font-weight:700;color:var(--soft)}
.big.zufallart{background:linear-gradient(135deg,#8A3FE0,#E043B8)!important;color:#fff!important;border-color:transparent!important;box-shadow:0 4px 0 #5E2399!important;padding:10px 16px}
.big.zufallart:hover .wuerfel{display:inline-block;animation:wuerfeln .6s ease-in-out}
.flusstabs{margin:6px 0}
.kinfo{margin:4px 0 8px;font-weight:700;color:var(--soft)}
.hero .ctas .big.zartikel{background:linear-gradient(135deg,#7B2FF7 0%,#B24BF3 45%,#F15BB5 100%)!important;color:#fff!important;border-color:transparent!important;box-shadow:0 5px 0 #4B1A99!important;text-shadow:0 1px 2px rgba(0,0,0,.25)}
.hero .ctas .big.zartikel:hover{filter:brightness(1.07)}
.hero .ctas .big.zartikel:hover .wuerfel{animation:wuerfeln .6s ease-in-out}
.hero .ctas .big.zartikel:active{transform:translateY(3px);box-shadow:0 2px 0 #4B1A99!important}
@media (min-width:761px){.hero .ctas .big{font-size:1rem!important;padding:18px 8px!important;gap:6px!important}.hero .ctas .cicon{font-size:1.4em!important}}
.kennzahlen.kz2{gap:14px!important;margin:12px 0 6px!important}
.kennzahlen.kz2 .kzk{background:var(--kzg)!important;border:0!important;color:#fff;overflow:visible;padding:14px 16px!important;border-radius:24px;box-shadow:0 7px 0 rgba(0,0,0,.18),0 18px 30px -16px rgba(61,90,254,.6)!important;isolation:isolate}
.kennzahlen.kz2 .kzk-themen{box-shadow:0 7px 0 rgba(0,0,0,.18),0 18px 30px -16px rgba(16,181,166,.6)!important}
.kennzahlen.kz2 .kzk::before{content:"";position:absolute;inset:0;border-radius:inherit;padding:0;background:linear-gradient(115deg,transparent 30%,rgba(255,255,255,.45) 48%,transparent 62%) no-repeat;background-size:250% 100%;-webkit-mask:none;mask:none;animation:kzglanz 5s ease-in-out infinite;z-index:-1}
.kennzahlen.kz2 .kzk-themen::before{animation-delay:-2.5s}
.kennzahlen.kz2 .kzk::after{content:"";position:absolute;inset:0;border-radius:inherit;background:radial-gradient(circle at 85% 15%,rgba(255,255,255,.28),transparent 40%);z-index:-1}
@keyframes kzglanz{0%,55%{background-position:120% 0}100%{background-position:-120% 0}}
.kennzahlen.kz2 .kzicon{background:rgba(255,255,255,.22)!important;border:2px solid rgba(255,255,255,.5);box-shadow:inset 0 2px 6px rgba(255,255,255,.35),0 6px 12px -6px rgba(0,0,0,.4)!important;animation:kzhuepf 3s ease-in-out infinite}
.kennzahlen.kz2 .kzk-themen .kzicon{animation-delay:-1.5s}
@keyframes kzhuepf{0%,100%{transform:translateY(0) rotate(-4deg)}50%{transform:translateY(-4px) rotate(4deg)}}
.kennzahlen.kz2 .kztext b{background:none!important;-webkit-background-clip:border-box!important;background-clip:border-box!important;color:#fff!important;-webkit-text-fill-color:#fff;text-shadow:0 3px 0 rgba(0,0,0,.15),0 0 18px rgba(255,255,255,.35)}
.kennzahlen.kz2 .kztext span{color:rgba(255,255,255,.95)!important;font-weight:800}
.kzchips{display:flex;align-items:center;justify-content:center;gap:3px;flex-wrap:wrap;margin-top:6px;font-style:normal;font-size:.78rem;font-weight:700;color:rgba(255,255,255,.92)}
.kzchips i{font-style:normal;width:24px;height:24px;display:grid;place-items:center;border-radius:50%;background:rgba(255,255,255,.25);font-size:.85rem;font-family:"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif}
@media (prefers-reduced-motion:reduce){.kennzahlen.kz2 .kzk::before,.kennzahlen.kz2 .kzicon{animation:none}}
@media (max-width:560px){.kennzahlen.kz2 .kztext b{font-size:2rem}.kzchips{font-size:.7rem}.kzchips i{width:20px;height:20px;font-size:.72rem}}
'''
for p in ['/mnt/user-data/outputs/lernspiel.html','/mnt/user-data/outputs/easyplay/index.html']: patch(p)
