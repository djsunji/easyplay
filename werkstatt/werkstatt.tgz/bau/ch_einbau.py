import json,re
exec(open('/home/claude/bau/ch_firmen.py').read())
d=json.load(open('/home/claude/logos_out/logos_ch.json'))
LEICHT={2,3,4,6,11,14,15,29,149,151,176,178,182,183,168,163,146,22,1,121}
logos={}
for k,src in d.items():
    nr=int(k)
    if nr in SCHLECHT or nr not in CH: continue
    n,desc=CH[nr]
    logos[nr]={'n':n,'d':desc,'src':src,'dk':1 if nr in DUNKEL else 0,'l':1 if nr in LEICHT else 2}
TITEL={'Nestlé':1,'Migros':2,'Coop':3,'Lindt & Sprüngli':4,'Emmi':5,'Ricola':6,'Rivella':15,'Kambly':17,'Cailler':19,'Läderach':28,'Zweifel':29,'Denner':11,'Manor':12,'Globus':13,'Volg':14,'UBS':31,'Raiffeisen':36,'PostFinance':37,'Zürcher Kantonalbank':38,'Zurich Insurance Group':47,'Swiss Re':48,'Die Mobiliar':51,'Swiss Life':52,'Roche':61,'Novartis':62,'Lonza':63,'Givaudan':81,'Sika':82,'Geberit':90,'ABB':91,'Holcim':92,'Schindler':94,'Stadler Rail':105,'Pilatus Aircraft':106,'Bühler':96,'Swatch Group':121,'Rolex':122,'Omega':127,'Victorinox':149,'Logitech':154,'Swisscom':151,'Sunrise':152,'Digitec Galaxus':163,'SRG SSR':168,'On':146,'Mammut':147,'Freitag':148,'Kühne + Nagel':188,'MSC':189,'Swiss':176,'Edelweiss Air':177,'Die Schweizerische Post':183,'AMAG':194,'Proton AG':161,'Climeworks':174}
alle_desc=sorted(set(v[1] for v in CH.values()))
JS='''/* CH-LOGOS-START */
const CH_LOGOS = %s;
const CH_FIRMA_NR = %s;
const CH_DESC = %s;
function chLogoHTML(nr, cls){ const o=CH_LOGOS[nr]; if(!o) return ""; return `<span class="logobox chlogo ${o.dk?"dunkel":""} ${cls||""}" role="img" aria-label="Logo"><img src="${o.src}" alt=""></span>`; }
const CH_LOGOFRAGEN = Object.entries(CH_LOGOS).map(([nr,o])=>({t:"logos",l:o.l,img:"c:"+nr,s:o.n,q:"Was bietet diese Schweizer Firma an?",
  a:[o.d[0].toUpperCase()+o.d.slice(1), ...pick3(CH_DESC.filter(x=>x!==o.d),o.d).map(x=>x[0].toUpperCase()+x.slice(1))],
  e:`Das ist das Logo von ${o.n}. Die Schweizer Firma steht für ${o.d}.`, m:`${o.n} ist eine Schweizer Firma für ${o.d}.`}));
LOGOFRAGEN.push(...CH_LOGOFRAGEN); FRAGEN.push(...CH_LOGOFRAGEN);
/* CH-LOGOS-END */''' % (json.dumps({str(k):v for k,v in logos.items()},ensure_ascii=False,separators=(',',':')),
      json.dumps(TITEL,ensure_ascii=False),json.dumps(alle_desc,ensure_ascii=False))
for p in ['/mnt/user-data/outputs/lernspiel.html','/mnt/user-data/outputs/easyplay/index.html']:
    h=open(p,encoding='utf-8').read()
    if '/* CH-LOGOS-START */' in h:
        h=re.sub(r'/\* CH-LOGOS-START \*/.*?/\* CH-LOGOS-END \*/',lambda m:JS,h,flags=re.S)
    else:
        a='FRAGEN.push(...LOGOFRAGEN);\n'; assert h.count(a)==1; h=h.replace(a,a+JS+'\n')
        def r(x,y):
            global h
            assert h.count(x)==1,(p,x[:60]); h=h.replace(x,y)
        r('  if(t==="l") return logoSvg(k,"qbig");','  if(t==="l") return logoSvg(k,"qbig");\n  if(t==="c") return chLogoHTML(k,"qbig");')
        r('logo:e.logo||null,','logo:e.logo||null, chlogo:CH_FIRMA_NR[e.titel]||null,')
        r('${s.logo?logoSvg(s.logo):`<span class="ebemo">${emo}</span>`}','${s.chlogo&&CH_LOGOS[s.chlogo]?chLogoHTML(s.chlogo):s.logo?logoSvg(s.logo):`<span class="ebemo">${emo}</span>`}')
        r('</style>','''.logobox.chlogo img{max-width:100%;max-height:100%;object-fit:contain;display:block}
.qimg .logobox.chlogo.qbig{width:min(300px,78vw);height:150px}
.ebild .logobox.chlogo{width:min(260px,70%);height:110px}
.bibimg .logobox.chlogo{width:110px!important}
</style>''')
    open(p,'w',encoding='utf-8').write(h)
print(len(logos),'Schweizer Logos eingebaut:',', '.join(v['n'] for v in logos.values()))
