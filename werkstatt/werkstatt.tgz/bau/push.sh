#!/bin/bash
cd /home/claude/easyplay && git pull -q && cp /mnt/user-data/outputs/easyplay/{index.html,config.js,lehrer.js,bibidx.js,hardcore.js} . 2>/dev/null; cp /mnt/user-data/outputs/easyplay/fragen-*.{json,csv} . && git add -A && git commit -qm "$1

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_015F4ypguKCiePf7SvTB76p6" && git push -q 2>&1 | tail -2; git log --oneline -1
