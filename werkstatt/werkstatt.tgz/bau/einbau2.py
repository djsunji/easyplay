import json,csv,subprocess,sys,re
d,files,const,kommentar=sys.argv[1],sys.argv[2].split(','),sys.argv[3],sys.argv[4]
O='/mnt/user-data/outputs/'
neu=[]
for r in files: neu+=json.load(open(f'{d}/{r}.json',encoding='utf-8'))
neu=[{k:f[k] for k in ["t","l","s","q","a","e","m"]} for f in neu]
bad=[f for f in neu if re.search('[ß–—]',json.dumps(f,ensure_ascii=False))]
assert not bad, bad[:2]
j=json.load(open(O+'easyplay/fragen.json',encoding='utf-8'))
alt={f['q'].strip().lower() for f in j}
vorher=len(neu); seen=set(); n2=[]
for f in neu:
    k=f['q'].strip().lower()
    if k in alt or k in seen: continue
    seen.add(k); n2.append(f)
neu=n2
json.dump(neu,open('/tmp/neu.json','w',encoding='utf-8'),ensure_ascii=False)
subprocess.run(["node","/tmp/nrnew.js"],check=True)
keys=open('/tmp/neu_keys.txt').read().split(',')
start=max(f['nr'] for f in j)+1
for i,f in enumerate(neu): j.append({"nr":start+i,**f})
open(O+'easyplay/fragen.json','w',encoding='utf-8').write("[\n"+",\n".join(json.dumps(x,ensure_ascii=False) for x in j)+"\n]\n")
with open(O+'easyplay/fragen.csv','a',encoding='utf-8',newline='') as fh:
    w=csv.writer(fh)
    for f in neu: w.writerow([f['t'],f['l'],f['q'],json.dumps(f['a'],ensure_ascii=False),f['e'],f['m'],f['s'],'','ok'])
arr=json.dumps(neu,ensure_ascii=False,separators=(',',':'))
for fn in ["lernspiel.html","easyplay/index.html"]:
    h=open(O+fn,encoding='utf-8').read()
    assert f'const {const} =' not in h
    a='FRAGEN.push(...FRAGEN_TIERE_PROFI);\n/* ENDE-NEUE-FRAGEN */'
    if a not in h:
        a0='FRAGEN.push(...FRAGEN_TIERE_PROFI);'; assert h.count(a0)==1
        h=h.replace(a0,a); 
    h=h.replace('/* ENDE-NEUE-FRAGEN */',f'/* {kommentar} (Nr. {start} bis {start+len(neu)-1}) */\nconst {const} = {arr};\nFRAGEN.push(...{const});\n/* ENDE-NEUE-FRAGEN */',1)
    i=h.index('const NR_KEYS="'); e=h.index('";',i)
    assert h[i:e].count(',')+1==start-1, (h[i:e].count(',')+1, start)
    h=h[:e]+','+','.join(keys)+h[e:]
    open(O+fn,'w',encoding='utf-8').write(h)
print('neu',len(neu),'von',vorher,'Nr',start,'bis',start+len(neu)-1,'total json',len(j))
