import sys
A='function rxTreffer(uniq,text,re,max,ok){ const {uniq:U,offs,big}=rxBlob(text);'
B=A+'''
  const P=window.EP_BIBIDX; if(P && P.n===FRAGEN.length){ const r=P.r[re.source+"/"+re.flags+"/"+max+"/"+(text===fTextM?"m":"t")+(ok?"/o":"")];
    if(r){ const b=rxBlob(text); if(!b.nrMap){ b.nrMap=new Map(); for(const f of U) if(f.nr!=null && !b.nrMap.has(f.nr)) b.nrMap.set(f.nr,f); } return r.map(x=>b.nrMap.get(x)).filter(Boolean); } }'''
for p,tag in [(sys.argv[1],'<script src="config.js"></script>\n'),(sys.argv[2],None)]:
    h=open(p,encoding='utf-8').read()
    if "EP_BIBIDX" not in h:
        assert A in h; h=h.replace(A,B,1)
        if tag: h=h.replace(tag,tag+'<script src="bibidx.js"></script>\n',1)
        else:
            i=h.index('<script src="daten-g01.js"></script>'); h=h[:i]+'<script src="bibidx.js"></script>\n'+h[i:]
    open(p,'w',encoding='utf-8').write(h); print(p,"ok")
