import sys
JS=r'''/* Qeels: dezenter Scrollbalken für Artikel */
function rlBalken(sc){
  if(!sc || sc.dataset.balken) return; const par=sc.parentElement; if(!par) return; sc.dataset.balken="1";
  const b=document.createElement("div"); b.className="rlbalken"; b.setAttribute("aria-hidden","true"); b.innerHTML="<i></i>"; par.appendChild(b);
  const i=b.firstChild;
  const neu=()=>{ const h=sc.clientHeight, H=sc.scrollHeight; if(!h || H<=h+4){ b.hidden=true; return; } b.hidden=false;
    b.style.top=(sc.offsetTop+10)+"px"; b.style.height=Math.max(20,h-20)+"px"; b.style.left=(sc.offsetLeft+sc.offsetWidth-7)+"px";
    const spur=Math.max(20,h-20), dh=Math.max(24, spur*h/H), dy=(spur-dh)*(sc.scrollTop/Math.max(1,H-h));
    i.style.height=dh+"px"; i.style.transform=`translateY(${dy}px)`;
    b.classList.toggle("ende", sc.scrollTop+h>=H-4); };
  sc.addEventListener("scroll", ()=>{ neu(); b.classList.add("aktiv"); clearTimeout(b._t); b._t=setTimeout(()=>b.classList.remove("aktiv"),900); }, {passive:true});
  try{ const ro=new ResizeObserver(neu); ro.observe(sc); if(sc.firstElementChild) ro.observe(sc.firstElementChild); }catch(e){}
  requestAnimationFrame(neu); setTimeout(neu,400);
}
'''
CSS='''
/* Qeels: dezenter Scrollbalken */
#reels .rakarte,#reels .rsinhalt{scrollbar-width:none}
#reels .rakarte::-webkit-scrollbar,#reels .rsinhalt::-webkit-scrollbar{display:none}
.rlbalken{position:absolute;width:3px;border-radius:3px;background:rgba(255,255,255,.18);pointer-events:none;z-index:5;transition:opacity .3s,width .2s}
.rlbalken i{display:block;width:100%;border-radius:3px;background:rgba(255,255,255,.75);box-shadow:0 0 6px rgba(0,0,0,.35)}
.rlbalken.aktiv{width:4px}
.rlbalken.ende{opacity:.45}
.rsheet .rlbalken{background:rgba(0,0,0,.1)}.rsheet .rlbalken i{background:color-mix(in srgb,var(--bf,#8A3FE0) 70%,#000);box-shadow:none}
'''
for p in sys.argv[1:]:
    h=open(p,encoding='utf-8').read(); n=[]
    if 'function rlBalken' not in h: k=h.index('function rlBinde('); h=h[:k]+JS+h[k:]; n.append("js")
    a='function rlBinde(sec, it){\n  let tapT=0;'
    if a in h: h=h.replace(a,'function rlBinde(sec, it){\n  let tapT=0; sec.querySelectorAll(".rakarte").forEach(rlBalken);',1); n.append("binde")
    a='''        ${inhalt}
      </article></div>'''
    i=h.find(a)
    if i>=0 and 'rlBalken($("#rsInhalt"))' not in h:
        j=h.index('`);',i)+3; h=h[:j]+' rlBalken($("#rsInhalt"));'+h[j:]; n.append("sheet")
    if '/* Qeels: dezenter Scrollbalken */' not in h: k=h.index('</style>'); h=h[:k]+CSS+h[k:]; n.append("css")
    open(p,'w',encoding='utf-8').write(h); print(p,n)
