import sys
def rep(s,a,b):
    assert s.count(a)==1,(s.count(a),a[:80]); return s.replace(a,b)
for fn in sys.argv[1:]:
    s=open(fn,encoding="utf-8").read()
    if "lkSupaIch" in s: continue
    s=rep(s,'async function likeZahl(id){','''// Mit Konto: das Zugangs-Token der Person mitschicken (Kommentare brauchen ein Konto)
async function lkSupaIch(){
  const sp=lkSupa(); if(!sp) return null;
  try{ const t=AUTH.sb && (await AUTH.sb.auth.getSession()).data?.session?.access_token; if(t) sp.h={...sp.h, Authorization:`Bearer ${t}`}; else sp.anon=true; }catch(e){ sp.anon=true; }
  return sp;
}
async function likeZahl(id){''')
    s=rep(s,'const sp=lkSupa(); if(sp){ const r=await fetch(`${sp.u}/rest/v1/rpc/like_aendern`','const sp=await lkSupaIch(); if(sp){ const r=await fetch(`${sp.u}/rest/v1/rpc/like_aendern`')
    s=rep(s,'const sp=lkSupa(); if(sp){ const r=await fetch(`${sp.u}/rest/v1/kommentare`,{method:"POST"',
      'const sp=await lkSupaIch(); if(sp){ if(sp.anon) throw new Error("Zum Kommentieren musst du angemeldet sein."); const r=await fetch(`${sp.u}/rest/v1/kommentare`,{method:"POST"')
    s=rep(s,'else { const sp=lkSupa(); if(sp) await fetch(`${sp.u}/rest/v1/rpc/kommentar_melden`','else { const sp=await lkSupaIch(); if(sp) await fetch(`${sp.u}/rest/v1/rpc/kommentar_melden`')
    open(fn,"w",encoding="utf-8").write(s); print(fn,"ok")
