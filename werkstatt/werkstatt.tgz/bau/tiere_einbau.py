import json,csv,subprocess,sys
reihen=sys.argv[1].split(','); kommentar=sys.argv[2]
O='/mnt/user-data/outputs/'
neu=[]
for r in reihen: neu+=json.load(open(f'/home/claude/mk/tiere/{r}.json',encoding='utf-8'))
neu=[{k:f[k] for k in ["t","l","s","q","a","e","m"]} for f in neu]
j=json.load(open(O+'easyplay/fragen.json',encoding='utf-8'))
alt={f['q'].strip().lower() for f in j}
vorher=len(neu); neu=[f for f in neu if f['q'].strip().lower() not in alt]
assert len({f['q'] for f in neu})==len(neu)
json.dump(neu,open('/tmp/neu.json','w',encoding='utf-8'),ensure_ascii=False)
subprocess.run(["node","/tmp/nrnew.js"],check=True)
keys=open('/tmp/neu_keys.txt').read().split(',')
start=max(f['nr'] for f in j)+1
for i,f in enumerate(neu): j.append({"nr":start+i,**f})
open(O+'easyplay/fragen.json','w',encoding='utf-8').write("[\n"+",\n".join(json.dumps(x,ensure_ascii=False) for x in j)+"\n]\n")
with open(O+'easyplay/fragen.csv','a',encoding='utf-8',newline='') as fh:
    w=csv.writer(fh)
    for f in neu: w.writerow([f['t'],f['l'],f['q'],json.dumps(f['a'],ensure_ascii=False),f['e'],f['m'],f['s'],'','ok'])
arr=json.dumps(neu,ensure_ascii=False,separators=(',',':'))
for fn in ["lernspiel.html","easyplay/index.html"]:
    h=open(O+fn,encoding='utf-8').read()
    a='FRAGEN.push(...FRAGEN_TIERE_PROFI);'
    assert h.count(a)==1
    h=h.replace(a,a+f'\n/* {kommentar} (Nr. {start} bis {start+len(neu)-1}) */\nFRAGEN_TIERE_PROFI.length=0; FRAGEN_TIERE_PROFI.push(...'+arr+');\nFRAGEN.push(...FRAGEN_TIERE_PROFI);',1) if False else h
    # einfacher: an das bestehende Array anhängen
    i=h.index('const FRAGEN_TIERE_PROFI = ['); e=h.index('];\nFRAGEN.push(...FRAGEN_TIERE_PROFI);',i)
    h=h[:e]+','+arr[1:-1]+h[e:]
    h=h.replace('/* Profi-Fragen Tiere:', f'/* {kommentar} (Nr. {start} bis {start+len(neu)-1}) */\n/* Profi-Fragen Tiere:',1)
    i=h.index('const NR_KEYS="'); e=h.index('";',i)
    assert h[i:e].count(',')+1==start-1, (h[i:e].count(',')+1, start)
    h=h[:e]+','+','.join(keys)+h[e:]
    open(O+fn,'w',encoding='utf-8').write(h)
print('neu',len(neu),'von',vorher,'Nr',start,'bis',start+len(neu)-1,'total json',len(j))
