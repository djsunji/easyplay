import sys
A=' : `<button class="navbtn" id="navLib" type="button" title="Zur Bibliothek">📖 <span class="tlab">Bibliothek</span></button>`)'
CSS='''
/* Kopfzeile: grosser Schriftzug, kleinere Knöpfe, ohne Bibliothek */
.topbar .wmimg{height:92px!important}
.nav .navbtn{min-height:42px!important;padding:5px 14px!important;font-size:.9rem!important;gap:6px!important}
@media (max-width:760px){.topbar .wmimg{height:62px!important}.nav{grid-template-columns:repeat(3,1fr)!important}.nav .navbtn{min-height:54px!important;font-size:1.25rem!important;padding:6px 4px!important;border-radius:16px!important}.nav .navbtn .tlab{font-size:.72rem}}
'''
for p in sys.argv[1:]:
    h=open(p,encoding='utf-8').read(); n=[]
    if A in h: h=h.replace(A,' : "")',1); n.append("lib")
    if "/* Kopfzeile: grosser Schriftzug" not in h:
        i=h.index("</style>"); h=h[:i]+CSS+h[i:]; n.append("css")
    open(p,'w',encoding='utf-8').write(h); print(p,n)
