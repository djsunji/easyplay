#!/bin/bash
# Einbau aller geprüften Queue-Blöcke, Test, Kopie ins Scratchpad. Ausgabe: Name der daten-Datei
cd /home/claude/mk/gross
L=$(python3 /home/claude/bau/welle.py 0 0 | grep ^EINBAU | cut -d' ' -f2)
[ -z "$L" ] && { echo "nichts"; exit 0; }
timeout 200 python3 /home/claude/bau/einbau3.py $L 2>&1 | tail -1 && echo $L | tr ',' '\n' >> eingebaut.txt
S=/tmp/claude-0/-home-claude-easyplay/3659680d-7d06-598e-9384-c9c658a65ab8/scratchpad; rm -f $S/re.py $S/json.py
D=$(ls -t /mnt/user-data/outputs/daten-g*.js | head -1); cp $D $S/; echo DATEI $(basename $D)
bash /tmp/claude-0/test.sh
