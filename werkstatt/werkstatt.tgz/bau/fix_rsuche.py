import sys
JS=r'''/* Qeels: Suche */
function rlNorm(s){ return String(s||"").toLowerCase().replace(/ß/g,"ss").normalize("NFD").replace(/[̀-ͯ]/g,""); }
function rlSucheBauen(term){
  const q=rlNorm(term).trim(); if(q.length<2) return null;
  const fr=alleFragen().filter(f=>THEMA[f.t] && f.q && Array.isArray(f.a) && f.a.length===4 && rlNorm(f.q+" "+f.a[0]+" "+(f.s||"")+" "+(f.e||"")).includes(q));
  fr.sort((a,b)=>((a.l===S.stufe)?0:1)-((b.l===S.stufe)?0:1) || Math.random()-.5);
  const pool=new Set(rlArtPool().map(w=>w.join("|"))), art=[];
  BUECHER.forEach(B=>{ try{ buchDaten(B.id).seiten.forEach(s=>{ if(pool.has(B.id+"|"+s.nr) && rlNorm(s.titel).includes(q)) art.push({typ:"a", b:B.id, nr:s.nr, t:rlNorm(s.titel)}); }); }catch(e){} });
  art.sort((a,b)=>(a.t===q?0:a.t.startsWith(q)?1:2)-(b.t===q?0:b.t.startsWith(q)?1:2));
  return {term:String(term).trim(), fragen:fr.slice(0,400).map(f=>({typ:"q", f})), artikel:art.slice(0,120), n:0};
}
function rlSucheNaechstes(){
  const R=RL.suche; if(!R) return null;
  const nimmArt = R.artikel.length && (R.n%3===0 || !R.fragen.length);
  R.n++;
  if(nimmArt) return R.artikel.shift();
  return R.fragen.shift() || R.artikel.shift() || null;
}
function rlSucheOeffnen(){
  const o=$("#reels"); if(!o) return; if($("#rsuchfeld")){ $("#rsuchfeld input").focus(); return; }
  const d=document.createElement("form"); d.id="rsuchfeld"; d.className="rsuchfeld"; d.setAttribute("role","search");
  d.innerHTML=`<span aria-hidden="true">🔍</span><label class="sr-only" for="rsInput">Qeels durchsuchen</label><input id="rsInput" type="search" placeholder="Begriff suchen, z. B. Katze, Römer, Alpen" autocomplete="off" value="${esc(RL.suche?.term||"")}"><button type="submit" class="rsgo">Suchen</button><button type="button" class="rsx" aria-label="Suche schliessen">✕</button>`;
  o.appendChild(d); const inp=d.querySelector("input"); setTimeout(()=>inp.focus(),30);
  d.querySelector(".rsx").onclick=()=>{ d.remove(); if(RL.tab==="suche"){ RL.suche=null; rlTab("mix"); } };
  d.onsubmit=e=>{ e.preventDefault(); const R=rlSucheBauen(inp.value); if(!R){ rlToast("Mindestens 2 Buchstaben eingeben"); return; }
    const anz=R.fragen.length+R.artikel.length; if(!anz){ rlToast(`Nichts gefunden für «${R.term}»`); return; }
    RL.suche=R; inp.blur(); d.classList.add("klein"); rlTab("suche"); rlToast(`${anz} Qeels zu «${R.term}»`); };
}
'''
CSS='''
/* Qeels: Suche */
#reels .rtabs button.rlupe{font-size:1.05rem;padding:6px 8px}
#reels .rsuchfeld{position:absolute;z-index:12;top:58px;left:50%;transform:translateX(-50%);width:min(94vw,520px);display:flex;align-items:center;gap:6px;padding:6px 6px 6px 14px;border-radius:999px;background:rgba(255,255,255,.96);box-shadow:0 10px 30px rgba(0,0,0,.4);color:#111}
#reels .rsuchfeld input{flex:1;min-width:0;border:0;background:none;font:inherit;font-size:1rem;padding:8px 4px;color:#111;outline:none}
#reels .rsuchfeld .rsgo{border:0;border-radius:999px;padding:9px 14px;font-weight:700;color:#fff;background:linear-gradient(135deg,#8A3FE0,#3D5AFE);cursor:pointer}
#reels .rsuchfeld .rsx{border:0;background:none;font-size:1.1rem;cursor:pointer;color:#555;padding:6px 8px}
#reels .rsuchfeld.klein{opacity:.92}
'''
for p in sys.argv[1:]:
    h=open(p,encoding='utf-8').read(); n=[]
    if 'function rlSucheBauen' not in h: k=h.index('function rlNaechstes('); h=h[:k]+JS+h[k:]; n.append("js")
    a='  const t=RL.tab; let it=null;\n  if(t==="quiz") it=rlNaechsteFrage();'
    if a in h: h=h.replace(a,'  const t=RL.tab; let it=null;\n  if(t==="suche"){ RL.n++; return rlSucheNaechstes(); }\n  if(t==="quiz") it=rlNaechsteFrage();',1); n.append("next")
    a='<div class="rtabs" role="tablist">${RL_TABS.map(([id,n])=>`<button type="button" role="tab" data-rtab="${id}" aria-selected="${id===(tab||RL.tab)}">${n}</button>`).join("")}</div>'
    if a in h: h=h.replace(a,'<div class="rtabs" role="tablist">${RL_TABS.map(([id,n])=>`<button type="button" role="tab" data-rtab="${id}" aria-selected="${id===(tab||RL.tab)}">${n}</button>`).join("")}<button type="button" class="rlupe" id="rLupe" role="tab" aria-selected="false" aria-label="Qeels durchsuchen" title="Suchen">🔍</button></div>',1); n.append("lupe")
    a='  o.querySelectorAll("[data-rtab]").forEach(b=>b.onclick=()=>rlTab(b.dataset.rtab));'
    if a in h: h=h.replace(a,'  o.querySelectorAll("[data-rtab]").forEach(b=>b.onclick=()=>{ $("#rsuchfeld")?.remove(); RL.suche=null; rlTab(b.dataset.rtab); });\n  $("#rLupe").onclick=rlSucheOeffnen;',1); n.append("bind")
    a='  document.querySelectorAll("#reels [data-rtab]").forEach(b=>b.setAttribute("aria-selected", b.dataset.rtab===t));'
    if a in h: h=h.replace(a,a+'\n  $("#rLupe")?.setAttribute("aria-selected", t==="suche");',1); n.append("sel")
    if '/* Qeels: Suche */\n#reels' not in h: k=h.index('</style>'); h=h[:k]+CSS+h[k:]; n.append("css")
    open(p,'w',encoding='utf-8').write(h); print(p,n)
