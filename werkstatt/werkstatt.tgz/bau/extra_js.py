import json,glob
E=[]
for f in sorted(glob.glob('/home/claude/mk/out_*.json')): E+=json.load(open(f))
ORD=["x_fluesse","x_seen","x_fahrzeuge","x_technik","x_energie","x_essen","x_sport","x_kultur"]
E.sort(key=lambda e:(ORD.index(e['kap']),e['titel']))
daten=json.dumps(E,ensure_ascii=False,separators=(',',':'))
JS = r'''
/* ---------- Bibliothek: neue Sachkapitel (Flüsse, Seen, Fahrzeuge, Technik, Energie, Essen, Sport, Kultur) ---------- */
const EXTRA_EINTRAEGE = __DATEN__;
const EXTRA_KAP = {
  x_fluesse:{titel:"Flüsse", emo:"🌊", buch:"welt"},
  x_seen:{titel:"Seen", emo:"🏞️", buch:"welt"},
  x_fahrzeuge:{titel:"Fahrzeuge & Verkehr", emo:"🚗", buch:"natur"},
  x_technik:{titel:"Technik & Erfindungen", emo:"💡", buch:"natur"},
  x_energie:{titel:"Energie", emo:"⚡", buch:"natur"},
  x_essen:{titel:"Essen & Trinken", emo:"🍽️", buch:"alltag"},
  x_sport:{titel:"Sport", emo:"⚽", buch:"alltag"},
  x_kultur:{titel:"Kultur & Musik", emo:"🎭", buch:"alltag"}
};
function istSonderKapitel(id){ return ["alpen","jura","ch_behoerden","ch_sicherheit","ch_betriebe"].includes(id) || String(id).startsWith("x_"); }
function extraKapitel(bid){
  const alle=[...FRAGEN,...S.extra]; const seen=new Set(); const uniq=alle.filter(f=>{ if(seen.has(f.q)) return false; seen.add(f.q); return true; });
  const text=f=>f.q+" "+(f.a?.[0]||"")+" "+f.e+" "+(f.s||"");
  const rx=t=>{ const w=t.replace(/\s*\(.*\)$/,"").trim(); if(w.length<4) return null; return new RegExp("(^|[^A-Za-zÄÖÜäöü])"+w.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+"(?![a-zäöü])"); };
  return Object.entries(EXTRA_KAP).filter(([,k])=>k.buch===bid).map(([id,k])=>({id, titel:k.titel, emo:k.emo,
    seiten:EXTRA_EINTRAEGE.filter(e=>e.kap===id).map(e=>{ const re=rx(e.titel); const eigene=e.fragen.map(f=>({...f, t:id, s:e.titel}));
      const weitere=re? uniq.filter(f=>re.test(text(f)) && !eigene.some(x=>x.q===f.q)).slice(0,13) : [];
      return {typ:"fr", titel:e.titel, wiki:e.wiki, emo:e.emo, geo:e.geo||null, fluss:id==="x_fluesse",
        steck:{art:id.slice(2), emo:e.emo, titel:id==="x_fluesse"?"Vom Anfang bis zum Ende":"Steckbrief", zeilen:e.steck},
        teile:{v:2, einleitung:e.einleitung, wichtigste:e.wichtigste||[], abschnitte:e.abschnitte||[], begriffe:[], gewusst:e.gewusst||[]},
        fragen:[...eigene, ...weitere]}; }).sort((a,b)=>a.titel.localeCompare(b.titel,"de"))}));
}
function zufallArtikel(){
  const pool=[];
  BUECHER.forEach(B=>buchDaten(B.id).seiten.forEach(s=>{ if(s.typ==="art" || (s.titel!=="Allgemeines" && (s.teile || s.fragen.length>=3 || S.texte[seiteKey(s)]))) pool.push([B.id,s.nr]); }));
  if(!pool.length) return;
  let w; do { w=pool[Math.floor(Math.random()*pool.length)]; } while(pool.length>1 && w[0]===LIB.buch && w[1]===LIB.seite);
  LIB.buch=w[0]; LIB.seite=w[1]; LIB.zufall=true;
  if(!S.libModus){ S.libModus=true; document.documentElement.dataset.mode="lib"; }
  go("libseite"); scrollTo(0,0);
}
function bibSeitenZahl(){ try{ return BUECHER.reduce((n,B)=>n+buchDaten(B.id).seiten.length,0); }catch(e){ return 0; } }
'''
open('/home/claude/bau/extra.js','w').write(JS.replace('__DATEN__',daten))
print(len(E), len(JS)+len(daten))
